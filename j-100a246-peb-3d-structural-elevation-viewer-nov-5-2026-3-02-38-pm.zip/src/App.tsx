/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Download,
  Eye,
  FileText,
  Grid,
  Layers,
  Maximize2,
  Ruler,
  Box,
} from 'lucide-react';
import {
  buildPebScene,
  PebLayerVisibility,
  InspectedMemberInfo,
  BuiltPebScene,
} from './structural/buildPebScene';
import { buildCompanySignboard } from './structural/buildCompanySignboard';
import { EngineeringBreakdownModal } from './components/EngineeringBreakdownModal';
import { generateStandaloneSingleFileHtml } from './structural/generateStandaloneHtml';

export type CameraPresetKey =
  | 'iso'
  | 'front'
  | 'back'
  | 'left'
  | 'right'
  | 'roof'
  | 'inside';

interface CameraPresetSpec {
  key: CameraPresetKey;
  label: string;
  shortLabel: string;
  position: [number, number, number];
  target: [number, number, number];
  elevationSubtitle: string;
}

const CAMERA_PRESETS: CameraPresetSpec[] = [
  {
    key: 'iso',
    label: 'Isometric 3D',
    shortLabel: 'Isometric 3D',
    position: [58, 30, 62],
    target: [0, 5.0, 2.0],
    elevationSubtitle: '3D Isometric Overview — 88.275m × 18.290m O/O + 6.10m FSW Canopy + 3.0m Endwall Canopies + Mezzanine (Grids 1–5)',
  },
  {
    key: 'front',
    label: 'Front Elevation (FSW)',
    shortLabel: 'Front Elevation',
    position: [0, 7.2, 92],
    target: [0, 5.5, 0],
    elevationSubtitle: 'SIDEWALL ELEVATION @ GL-C (FSW — Low Eave ±9,485 mm, 6,100 mm Canopy @ +5,308 mm Clear, 3,000 mm B/W, 11 Louvers)',
  },
  {
    key: 'back',
    label: 'Back Elevation (BSW)',
    shortLabel: 'Back Elevation',
    position: [0, 7.6, -90],
    target: [0, 5.8, 0],
    elevationSubtitle: 'SIDEWALL ELEVATION @ GL-A (BSW — High Eave ±11,315 mm, 3,000 mm B/W, 3×4.5×4.0m Framed Openings, 11 Louvers)',
  },
  {
    key: 'left',
    label: 'Left Endwall (LEW)',
    shortLabel: 'Left Endwall',
    position: [-78, 7.5, 2.5],
    target: [0, 5.5, 2.5],
    elevationSubtitle: 'ENDWALL ELEVATION @ GL-01 (LEW — 4.5×4.0m F.O., 3,000 mm Endwall Canopy, 2 Louvers, 3,000 mm B/W)',
  },
  {
    key: 'right',
    label: 'Right Endwall (REW)',
    shortLabel: 'Right Endwall',
    position: [78, 7.5, 2.5],
    target: [0, 5.5, 2.5],
    elevationSubtitle: 'ENDWALL ELEVATION @ GL-12 (REW — 4.5×4.5m F.O., 3,000 mm Endwall Canopy + Stitch Col, 2 Louvers, 3,000 mm B/W)',
  },
  {
    key: 'roof',
    label: 'Roof Plan',
    shortLabel: 'Roof Plan',
    position: [0, 96, 3.0],
    target: [0, 0, 2.8],
    elevationSubtitle: 'ROOF FRAMING & SHEETING PLAN (GA-01 / GA-02 — 22 FRP Skylights, 11 Ø600 Turbo Vents, 1:10 Slope)',
  },
  {
    key: 'inside',
    label: 'Inside Walkthrough',
    shortLabel: 'Inside Walkthrough',
    position: [-34, 3.4, 0],
    target: [18, 5.2, 0],
    elevationSubtitle: 'INTERNAL WALKTHROUGH — Mezzanine @ EL +5,374 mm (Grids 1–5), 3-Flight Staircase (Bay 3–4), 5.5m Portal Frames',
  },
];

const DEFAULT_INSPECTED: InspectedMemberInfo = {
  name: 'Main Mono-Slope Rigid Frame, Mezzanine (Grids 1–5) & Canopy System (J-100A246)',
  category: 'Click any 3D structural member, mezzanine beam, staircase, base plate, or canopy to inspect',
  spec: '87,285 C/C × 17,000 C/C + Mezzanine (32,285×17,000 mm @ EL +5.374m) + 6.1m FSW & 3.0m EW Canopies',
  gridLocation: 'Grids 1–12 × Grids A, B, C + Staircase Grid 3–3\' × C–D (3,235×5,750 mm)',
  drawingRef: 'AB-01 & GA-01 through GA-08 (Revised 9-Sheet Set)',
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const builtSceneRef = useRef<BuiltPebScene | null>(null);
  const requestRenderRef = useRef<() => void>(() => {});
  const targetCameraPosRef = useRef<THREE.Vector3 | null>(null);
  const targetControlLookRef = useRef<THREE.Vector3 | null>(null);

  const [activePreset, setActivePreset] = useState<CameraPresetKey>('iso');
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTab, setModalTab] = useState<'summary' | 'drawings' | 'singlefile'>('summary');
  const [inspectedMember, setInspectedMember] = useState<InspectedMemberInfo>(DEFAULT_INSPECTED);

  const [layers, setLayers] = useState<PebLayerVisibility>({
    cladding: true,
    roofSheeting: true,
    brickWall: true,
    openingsAndAccessories: true,
    mezzanineStructure: true,
    primarySteel: true,
    secondarySteel: true,
    bracingAndPortals: true,
    gridAndDimensions: true,
    wireframeMode: false,
  });

  const layersRef = useRef<PebLayerVisibility>(layers);
  layersRef.current = layers;

  // Toggle a single layer or preset
  const updateLayer = useCallback((key: keyof PebLayerVisibility, val: boolean) => {
    setLayers((prev) => {
      const next = { ...prev, [key]: val };
      if (builtSceneRef.current) {
        builtSceneRef.current.applyVisibility(next);
        requestRenderRef.current();
      }
      return next;
    });
  }, []);

  // Quick toggle between Full Exterior Envelope vs Internal Steel Frame Only
  const isSteelOnlyMode = !layers.cladding && !layers.roofSheeting;
  const handleToggleSteelFrameOnly = useCallback(() => {
    setLayers((prev) => {
      const turnOnEnvelope = !prev.cladding && !prev.roofSheeting;
      const next: PebLayerVisibility = {
        ...prev,
        cladding: turnOnEnvelope,
        roofSheeting: turnOnEnvelope,
        primarySteel: true,
        secondarySteel: true,
        bracingAndPortals: true,
      };
      if (builtSceneRef.current) {
        builtSceneRef.current.applyVisibility(next);
        requestRenderRef.current();
      }
      return next;
    });
  }, []);

  const handleSelectPreset = useCallback((presetKey: CameraPresetKey) => {
    const found = CAMERA_PRESETS.find((p) => p.key === presetKey);
    if (!found) return;
    setActivePreset(presetKey);
    targetCameraPosRef.current = new THREE.Vector3(...found.position);
    targetControlLookRef.current = new THREE.Vector3(...found.target);
    requestRenderRef.current();
  }, []);

  const handleDownloadStandaloneHtml = useCallback(() => {
    const html = generateStandaloneSingleFileHtml();
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'J-100A246_PEB_3D_Viewer.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, []);

  // Initialize Three.js WebGLRenderer & PEB Scene once
  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    // Detect Software WebGL (SwiftShader / llvmpipe) per Three.js skill directive
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(mountEl.clientWidth, mountEl.clientHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    mountEl.innerHTML = '';
    mountEl.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b111e);
    scene.fog = new THREE.FogExp2(0x0b111e, 0.0042);

    // Studio Environment Reflection (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envMap = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envMap;
    pmremGenerator.dispose();

    // Camera & OrbitControls
    const camera = new THREE.PerspectiveCamera(
      45,
      mountEl.clientWidth / mountEl.clientHeight,
      0.25,
      500,
    );
    camera.position.set(58, 30, 62);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.maxDistance = 240;
    controls.minDistance = 1.5;
    controls.maxPolarAngle = Math.PI / 2 - 0.01; // Keep above ground plane
    controls.target.set(0, 5.0, 2.0);
    controls.update();

    // 3-Point Warm/Cool Architectural Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 0.85);
    hemiLight.position.set(0, 60, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff7ed, 2.15);
    keyLight.position.set(55, 85, 50);
    keyLight.castShadow = !isSoftwareGl;
    if (!isSoftwareGl) {
      keyLight.shadow.mapSize.width = 2048;
      keyLight.shadow.mapSize.height = 2048;
      const d = 62;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
      keyLight.shadow.camera.near = 2;
      keyLight.shadow.camera.far = 220;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.75);
    rimLight.position.set(-55, 42, -48);
    scene.add(rimLight);

    // Outer Ground Terrain Plane (offset below -0.25m slab so zero Z-fighting)
    const groundGeo = new THREE.PlaneGeometry(420, 420);
    groundGeo.rotateX(-Math.PI / 2);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.95,
      metalness: 0.02,
    });
    const groundMesh = new THREE.Mesh(groundGeo, groundMat);
    groundMesh.position.y = -0.26;
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);

    // Build the exact 1:1 Project J-100A246 3D PEB Model
    const builtPeb = buildPebScene(renderer.capabilities.getMaxAnisotropy());
    builtPeb.applyVisibility(layersRef.current);
    scene.add(builtPeb.rootGroup);
    builtSceneRef.current = builtPeb;

    // Add the separate freestanding MEGH ENGINEERING CONSULTANTS company signboard in front of the building
    const companySignboard = buildCompanySignboard(
      renderer.capabilities.getMaxAnisotropy(),
      () => requestRenderRef.current(),
    );
    scene.add(companySignboard.group);
    const allInteractables = [...builtPeb.interactables, ...companySignboard.interactables];

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Pre-allocated scratch helpers for zero GC in render loop
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      if (!sync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const poll = () => {
        const state = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function requestRender() {
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame((now) => {
        renderDirty = false;
        const dt = Math.min(0.1, (now - lastTime) / 1000);
        lastTime = now;

        // Smooth camera preset transition damping
        let isTransitioning = false;
        if (targetCameraPosRef.current && targetControlLookRef.current) {
          const alpha = isSoftwareGl ? 1.0 : 1 - Math.exp(-8 * dt);
          camera.position.lerp(targetCameraPosRef.current, alpha);
          controls.target.lerp(targetControlLookRef.current, alpha);

          if (
            camera.position.distanceToSquared(targetCameraPosRef.current) < 0.01 &&
            controls.target.distanceToSquared(targetControlLookRef.current) < 0.01
          ) {
            camera.position.copy(targetCameraPosRef.current);
            controls.target.copy(targetControlLookRef.current);
            targetCameraPosRef.current = null;
            targetControlLookRef.current = null;
          } else {
            isTransitioning = true;
          }
        }

        // Subtle rotation of the 11 roof turbo ventilators
        builtPeb.turboVentDomes.forEach((dome) => {
          dome.rotation.y += 0.04;
        });

        controls.update();
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || isTransitioning) {
            requestRender();
          }
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    requestRenderRef.current = requestRender;
    requestRender();

    // Cancel scripted camera transition when user interacts manually
    const onControlStart = () => {
      targetCameraPosRef.current = null;
      targetControlLookRef.current = null;
    };
    const onControlChange = () => {
      requestRender();
    };
    controls.addEventListener('start', onControlStart);
    controls.addEventListener('change', onControlChange);

    // Raycasting for clicking any 3D structural member to inspect its exact GA spec
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let downX = 0;
    let downY = 0;

    const onPointerDown = (e: PointerEvent) => {
      downX = e.clientX;
      downY = e.clientY;
    };

    const onPointerUp = (e: PointerEvent) => {
      if (Math.hypot(e.clientX - downX, e.clientY - downY) > 6) return;
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      const hits = raycaster.intersectObjects(allInteractables, false);
      const visibleHit = hits.find((h) => {
        let cur: THREE.Object3D | null = h.object;
        while (cur) {
          if (!cur.visible) return false;
          cur = cur.parent;
        }
        return Boolean(h.object.userData?.memberInfo);
      });

      if (visibleHit && visibleHit.object.userData?.memberInfo) {
        setInspectedMember(visibleHit.object.userData.memberInfo as InspectedMemberInfo);
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);

    // Keyboard shortcuts (H to collapse/expand HUD, WASD/Arrows to pan camera)
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'h' || e.key === 'H') {
        setDockCollapsed((prev) => !prev);
      } else if (['w', 'a', 's', 'd', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        const step = 2.5;
        const forward = new THREE.Vector3();
        camera.getWorldDirection(forward);
        forward.y = 0;
        forward.normalize();
        const right = new THREE.Vector3().crossVectors(forward, camera.up).normalize();

        if (e.key === 'w' || e.key === 'ArrowUp') {
          camera.position.addScaledVector(forward, step);
          controls.target.addScaledVector(forward, step);
        } else if (e.key === 's' || e.key === 'ArrowDown') {
          camera.position.addScaledVector(forward, -step);
          controls.target.addScaledVector(forward, -step);
        } else if (e.key === 'a' || e.key === 'ArrowLeft') {
          camera.position.addScaledVector(right, -step);
          controls.target.addScaledVector(right, -step);
        } else if (e.key === 'd' || e.key === 'ArrowRight') {
          camera.position.addScaledVector(right, step);
          controls.target.addScaledVector(right, step);
        }
        requestRender();
      }
    };
    window.addEventListener('keydown', onKeyDown);

    const onResize = () => {
      if (!mountEl) return;
      camera.aspect = mountEl.clientWidth / mountEl.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mountEl.clientWidth, mountEl.clientHeight);
      requestRender();
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKeyDown);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointerup', onPointerUp);
      controls.dispose();
      builtPeb.dispose();
      companySignboard.dispose();
      groundGeo.dispose();
      groundMat.dispose();
      envMap.dispose();
      renderer.dispose();
    };
  }, []);

  const currentPresetSpec =
    CAMERA_PRESETS.find((p) => p.key === activePreset) || CAMERA_PRESETS[0];

  return (
    <div
      className="relative h-screen w-screen overflow-hidden bg-[#0b111e] text-slate-100 select-none"
      data-state={activePreset}
    >
      {/* Isolated WebGL Canvas Mount Container (100% Unobstructed Viewport) */}
      <div
        ref={canvasMountRef}
        data-testid="peb-3d-canvas-container"
        className="absolute inset-0 h-full w-full cursor-grab active:cursor-grabbing"
      />

      {/* Top Navigation Bar (Strict 3-Zone Contract, No Backdrop Blur over WebGL) */}
      <header className="relative z-10 flex items-center justify-between gap-8 border-b border-slate-800/90 bg-[#0f172a]/95 px-6 py-3">
        {/* Zone 1: Single-line Brand Title */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            handleSelectPreset('iso');
          }}
          className="font-display text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          J-100A246 · Elegance Furniture PEB
        </a>

        {/* Zone 2: Concise Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
          <button
            type="button"
            onClick={() => {
              setModalTab('summary');
              setModalOpen(true);
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Dimensional Breakdown
          </button>
          <button
            type="button"
            onClick={() => {
              setModalTab('drawings');
              setModalOpen(true);
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            9 PDF Drawings (AB-01 &amp; GA-01..08)
          </button>
          <button
            type="button"
            onClick={handleToggleSteelFrameOnly}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            {isSteelOnlyMode ? 'Show Full Cladding Envelope' : 'Inspect Internal Steel Frame'}
          </button>
          <button
            type="button"
            onClick={() => {
              setModalTab('singlefile');
              setModalOpen(true);
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Single-File HTML Source
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action Button */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleDownloadStandaloneHtml}
            className="flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-sky-500 transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" />
            Export Single-File HTML
          </button>
        </div>
      </header>

      {/* Top-Left Compact Structural Spec & Interactive Raycast Inspector Readout */}
      <div className="pointer-events-none absolute left-4 top-16 z-10 max-w-xl">
        <div className="pointer-events-auto rounded-lg border border-slate-800/90 bg-[#0f172a]/92 px-3.5 py-2.5 shadow-lg">
          <div className="flex items-center justify-between gap-4 text-[11px] text-slate-400">
            <span className="font-mono-num text-sky-400 font-semibold">
              {currentPresetSpec.shortLabel}
            </span>
            <span className="font-mono-num">Scale 1:1 (1m = 1,000mm)</span>
          </div>
          <div className="mt-1 text-xs font-semibold text-white truncate">
            {inspectedMember.name}
          </div>
          <div className="mt-0.5 font-mono-num text-[11px] text-amber-300/95 truncate">
            {inspectedMember.spec}
          </div>
          <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400">
            <span>{inspectedMember.gridLocation}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-num text-slate-300">{inspectedMember.drawingRef}</span>
          </div>
        </div>
      </div>

      {/* Unified Collapsible Bottom Control Dock (Zero Side-Panel Clutter) */}
      <div
        className={`fixed bottom-4 left-1/2 z-10 w-full max-w-[min(1040px,96vw)] -translate-x-1/2 transition-transform duration-200 ${
          dockCollapsed ? 'translate-y-[calc(100%-34px)]' : 'translate-y-0'
        }`}
      >
        {/* Collapse / Expand Handle */}
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setDockCollapsed((prev) => !prev)}
            aria-label={dockCollapsed ? 'Show 3D Viewer Controls' : 'Hide 3D Viewer Controls'}
            className="flex items-center gap-1.5 rounded-t-lg border border-b-0 border-slate-700/80 bg-[#0f172a]/95 px-3.5 py-1 text-[11px] font-medium text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="h-3.5 w-3.5 text-sky-400" />
                Show Controls (H)
              </>
            ) : (
              <>
                <ChevronDown className="h-3.5 w-3.5 text-sky-400" />
                Hide Controls (H)
              </>
            )}
          </button>
        </div>

        {/* Main Dock Panel */}
        <div className="rounded-xl border border-slate-700/80 bg-[#0f172a]/95 px-4 py-3 shadow-2xl space-y-2.5">
          {/* Row 1: 7 Camera Elevation & Walkthrough Presets */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
            <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Camera Elevation Presets">
              {CAMERA_PRESETS.map((preset) => {
                const isActive = activePreset === preset.key;
                return (
                  <button
                    key={preset.key}
                    type="button"
                    onClick={() => handleSelectPreset(preset.key)}
                    className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                      isActive
                        ? 'bg-sky-600 text-white shadow-sm'
                        : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    {preset.label}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => {
                setModalTab('summary');
                setModalOpen(true);
              }}
              className="flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2.5 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition-colors whitespace-nowrap shrink-0"
            >
              <Ruler className="h-3.5 w-3.5" />
              Full Spec &amp; PDFs
            </button>
          </div>

          {/* Row 2: Structural & Envelope Layer Checkboxes */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.cladding && layers.roofSheeting}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setLayers((prev) => {
                      const next = { ...prev, cladding: checked, roofSheeting: checked };
                      builtSceneRef.current?.applyVisibility(next);
                      requestRenderRef.current();
                      return next;
                    });
                  }}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>Cladding / Sheeting</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-teal-500/40 bg-teal-950/50 px-2.5 py-1 text-teal-200 cursor-pointer hover:border-teal-400 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.mezzanineStructure}
                  onChange={(e) => updateLayer('mezzanineStructure', e.target.checked)}
                  className="h-3.5 w-3.5 accent-teal-500 rounded"
                />
                <span>Mezzanine &amp; Staircase (+5.374m)</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.brickWall}
                  onChange={(e) => updateLayer('brickWall', e.target.checked)}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>Brick Wall (3.00m)</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.openingsAndAccessories}
                  onChange={(e) => updateLayer('openingsAndAccessories', e.target.checked)}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>Openings / Louvers / Vents</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.secondarySteel}
                  onChange={(e) => updateLayer('secondarySteel', e.target.checked)}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>Purlins &amp; Girts (250Z / 200Z)</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.bracingAndPortals}
                  onChange={(e) => updateLayer('bracingAndPortals', e.target.checked)}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>Portal (5.5m) &amp; Rod Bracing</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.gridAndDimensions}
                  onChange={(e) => updateLayer('gridAndDimensions', e.target.checked)}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>Grid Lines &amp; Dimensions</span>
              </label>

              <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-700/70 bg-slate-900/90 px-2.5 py-1 text-slate-200 cursor-pointer hover:border-slate-600 whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={layers.wireframeMode}
                  onChange={(e) => updateLayer('wireframeMode', e.target.checked)}
                  className="h-3.5 w-3.5 accent-sky-500 rounded"
                />
                <span>X-Ray / Wireframe Mode</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Engineering Breakdown, Original 9 PDFs & Single-File HTML Deliverable Modal */}
      <EngineeringBreakdownModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        initialTab={modalTab}
      />
    </div>
  );
}
