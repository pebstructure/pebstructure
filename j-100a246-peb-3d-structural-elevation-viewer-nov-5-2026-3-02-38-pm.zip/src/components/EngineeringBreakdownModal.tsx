import React, { useState } from 'react';
import { X, FileText, Download, Check, Copy, Layers, Ruler, ShieldCheck } from 'lucide-react';
import {
  PROJECT_METADATA,
  BUILDING_DIMENSIONS_MM,
  BASE_PLATE_DETAILS,
  STRUCTURAL_MEMBER_SCHEDULE,
  DRAWING_SHEETS,
  getLongitudinalGrids,
  getTotalAnchorBoltCount,
} from '../structural/pebModelData';
import { generateStandaloneSingleFileHtml } from '../structural/generateStandaloneHtml';

interface EngineeringBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'summary' | 'drawings' | 'singlefile';
}

export const EngineeringBreakdownModal: React.FC<EngineeringBreakdownModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'summary',
}) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'drawings' | 'singlefile'>(initialTab);
  const [selectedSheetIdx, setSelectedSheetIdx] = useState(0);
  const [copiedHtml, setCopiedHtml] = useState(false);

  if (!isOpen) return null;

  const gridsX = getLongitudinalGrids();
  const totalBolts = getTotalAnchorBoltCount();
  const standaloneHtml = generateStandaloneSingleFileHtml();

  const handleCopyHtml = () => {
    navigator.clipboard.writeText(standaloneHtml);
    setCopiedHtml(true);
    setTimeout(() => setCopiedHtml(false), 2000);
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([standaloneHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'J-100A246_PEB_3D_Viewer.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 md:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="flex h-[90vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl border border-slate-800 bg-slate-900 text-slate-100 shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
          <div>
            <h2 id="modal-title" className="font-display text-lg font-bold tracking-tight text-white">
              Project {PROJECT_METADATA.drawingNumber} — Complete Structural &amp; Dimensional Breakdown
            </h2>
            <p className="text-xs text-slate-400">
              {PROJECT_METADATA.projectName} · Customer: {PROJECT_METADATA.customerName} · Site: {PROJECT_METADATA.jobSiteLocation} · Consultant: {PROJECT_METADATA.consultant}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Segmented Tab Switcher */}
            <div className="flex items-center gap-1 rounded-lg bg-slate-950 p-1 border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveTab('summary')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'summary' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Ruler className="h-3.5 w-3.5" />
                Dimensional Summary
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('drawings')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'drawings' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="h-3.5 w-3.5" />
                9 Revised PDF Drawings (AB-01 &amp; GA-01..08)
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('singlefile')}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'singlefile' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                Single-File HTML Deliverable
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close Engineering Breakdown Modal"
              className="rounded-lg border border-slate-700 bg-slate-800 p-2 text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'summary' && (
            <div className="space-y-8">
              {/* Primary Dimensional Summary Grid */}
              <section>
                <h3 className="font-display text-base font-semibold text-white mb-3">
                  01. Master Geometry, Mezzanine, Elevations &amp; Roof Slope (AB-01 &amp; GA-01 to GA-08)
                </h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-4">
                    <div className="text-xs text-slate-400">Building Length &amp; Span</div>
                    <div className="mt-1 font-mono-num text-xl font-bold text-white">87,285 × 17,000 mm C/C</div>
                    <div className="mt-1 font-mono-num text-xs text-sky-400">
                      88,275 × 18,290 mm O/O Steel Line
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-4">
                    <div className="text-xs text-slate-400">Mezzanine Floor (Grids 1 to 5)</div>
                    <div className="mt-1 font-mono-num text-xl font-bold text-white">EL +5,374 mm T.O.S.</div>
                    <div className="mt-1 font-mono-num text-xs text-teal-400">
                      32,285×17,000 mm · +4,500 B.O.B. · 3-Flight Stair (3×1,791 mm)
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-4">
                    <div className="text-xs text-slate-400">Mono-Slope 1:10 Eave Heights</div>
                    <div className="mt-1 font-mono-num text-xl font-bold text-white">±11,315 / ±9,485 mm</div>
                    <div className="mt-1 font-mono-num text-xs text-amber-400">
                      High Eave @ GL-A · Low Eave @ GL-C · 5.5m Portal Bracing
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-4">
                    <div className="text-xs text-slate-400">Canopies, Openings &amp; Brickwork</div>
                    <div className="mt-1 font-mono-num text-xl font-bold text-white">6.1m FSW + 3.0m EW</div>
                    <div className="mt-1 font-mono-num text-xs text-emerald-400">
                      3,000 mm Brick Dado · 5 Framed Openings · 26 Louvers
                    </div>
                  </div>
                </div>
              </section>

              {/* Longitudinal Grid Coordinates Table */}
              <section>
                <h3 className="font-display text-base font-semibold text-white mb-3">
                  02. Exact Longitudinal Grid Coordinates (Grids 1 to 12 — AB-01 &amp; GA-01)
                </h3>
                <div className="overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-slate-800 bg-slate-950 text-slate-400">
                      <tr>
                        <th className="px-3 py-2.5">Grid Line</th>
                        {gridsX.map((g) => (
                          <th key={g.gridNumber} className="px-3 py-2.5 font-mono-num text-white">
                            GL-{g.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70 bg-slate-900/50 font-mono-num">
                      <tr>
                        <td className="px-3 py-2 text-slate-400 font-sans">Bay Spacing (mm)</td>
                        {gridsX.map((g, i) => (
                          <td
                            key={g.gridNumber}
                            className={`px-3 py-2 ${
                              g.baySpacingFromPrevMm === 7000
                                ? 'text-rose-400 font-semibold'
                                : g.baySpacingFromPrevMm === 8285
                                ? 'text-amber-300 font-semibold'
                                : 'text-slate-200'
                            }`}
                          >
                            {i === 0 ? '0 (LEW)' : `${g.baySpacingFromPrevMm}`}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="px-3 py-2 text-slate-400 font-sans">Cumulative X (mm)</td>
                        {gridsX.map((g) => (
                          <td key={g.gridNumber} className="px-3 py-2 text-sky-300">
                            {g.xCoordMm.toLocaleString()}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="px-3 py-2 text-slate-400 font-sans">Bracing / Frame Type</td>
                        {gridsX.map((g, i) => (
                          <td key={g.gridNumber} className="px-3 py-2 text-slate-300">
                            {i === 0 || i === 11
                              ? 'End Frame (A,B,C)'
                              : g.isBracedBayAfter
                              ? 'Brace + Portal →'
                              : 'Clear Span (A–C)'}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Anchor Bolt & Base Plate Schedule */}
              <section>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-display text-base font-semibold text-white">
                    03. Anchor Bolt &amp; Base Plate Schedule (J-100A246-AB-01)
                  </h3>
                  <span className="font-mono-num text-xs text-amber-400">
                    Verified Total: {totalBolts} Nos. M-24 J-Type Gr. 4.60 Anchor Bolts (748 mm length, 50 mm grout)
                  </span>
                </div>
                <div className="overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-slate-800 bg-slate-950 text-slate-400">
                      <tr>
                        <th className="px-4 py-2.5">Detail Mark</th>
                        <th className="px-4 py-2.5">Grid Locations</th>
                        <th className="px-4 py-2.5">Qty Reqd.</th>
                        <th className="px-4 py-2.5">Base Plate Size (mm)</th>
                        <th className="px-4 py-2.5">M-24 Bolts / Col</th>
                        <th className="px-4 py-2.5">Total Bolts</th>
                        <th className="px-4 py-2.5">Base Note</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70 bg-slate-900/50">
                      {BASE_PLATE_DETAILS.map((bp) => (
                        <tr key={bp.code}>
                          <td className="px-4 py-2.5 font-mono-num font-semibold text-sky-400">{bp.code}</td>
                          <td className="px-4 py-2.5 text-slate-200">{bp.locationSummary}</td>
                          <td className="px-4 py-2.5 font-mono-num text-white">{bp.quantityRequired} Nos.</td>
                          <td className="px-4 py-2.5 font-mono-num text-slate-300">
                            PLT. {bp.plateWidthMm}×{bp.plateLengthMm}×{bp.plateThicknessMm}
                          </td>
                          <td className="px-4 py-2.5 font-mono-num text-slate-300">
                            {bp.anchorBoltCountPerColumn} Nos. (Ø{bp.anchorBoltHoleDiaMm} hole)
                          </td>
                          <td className="px-4 py-2.5 font-mono-num font-semibold text-amber-300">
                            {bp.quantityRequired * bp.anchorBoltCountPerColumn}
                          </td>
                          <td className="px-4 py-2.5 text-slate-400">{bp.baseType}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Primary & Secondary Structural Member Schedule */}
              <section>
                <h3 className="font-display text-base font-semibold text-white mb-3">
                  04. Complete Structural Framing, Cladding &amp; Accessories Schedule (GA-01 to GA-06)
                </h3>
                <div className="overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b border-slate-800 bg-slate-950 text-slate-400">
                      <tr>
                        <th className="px-4 py-2.5">Subsystem</th>
                        <th className="px-4 py-2.5">Structural Member</th>
                        <th className="px-4 py-2.5">Exact Section / Material Specification</th>
                        <th className="px-4 py-2.5">Engineering Details &amp; Locations</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70 bg-slate-900/50">
                      {STRUCTURAL_MEMBER_SCHEDULE.map((row, idx) => (
                        <tr key={idx}>
                          <td className="px-4 py-2.5 font-medium text-slate-300">{row.category}</td>
                          <td className="px-4 py-2.5 font-semibold text-white">{row.member}</td>
                          <td className="px-4 py-2.5 font-mono-num text-sky-300">{row.profile}</td>
                          <td className="px-4 py-2.5 text-slate-400">{row.remarks}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'drawings' && (
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 h-full">
              <div className="lg:col-span-4 space-y-2">
                <div className="text-xs font-medium text-slate-400 mb-2">
                  Select Original Uploaded Sheet (J-100A246):
                </div>
                {DRAWING_SHEETS.map((sheet, idx) => (
                  <button
                    key={sheet.sheetNo}
                    type="button"
                    onClick={() => setSelectedSheetIdx(idx)}
                    className={`w-full text-left rounded-lg border p-3 transition-colors ${
                      selectedSheetIdx === idx
                        ? 'border-sky-500 bg-sky-950/40 text-white'
                        : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono-num font-bold text-sky-400">
                        J-100A246-{sheet.sheetNo}
                      </span>
                      <span className="font-mono-num text-xs text-slate-400">
                        Rev {sheet.rev} · {sheet.date}
                      </span>
                    </div>
                    <div className="mt-1 text-xs font-semibold text-white">{sheet.title}</div>
                  </button>
                ))}

                <div className="mt-4 rounded-lg border border-slate-800 bg-slate-950 p-4">
                  <div className="text-xs font-semibold text-amber-400 mb-2">
                    Extracted Sheet Notes ({DRAWING_SHEETS[selectedSheetIdx].sheetNo}):
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-300 list-disc pl-4">
                    {DRAWING_SHEETS[selectedSheetIdx].keyTakeaways.map((note, nIdx) => (
                      <li key={nIdx}>{note}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="lg:col-span-8 flex flex-col rounded-lg border border-slate-800 bg-slate-950 overflow-hidden min-h-[520px]">
                <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2.5 bg-slate-900">
                  <span className="font-mono-num text-xs font-semibold text-white">
                    {DRAWING_SHEETS[selectedSheetIdx].sheetNo} — {DRAWING_SHEETS[selectedSheetIdx].title}
                  </span>
                  <a
                    href={DRAWING_SHEETS[selectedSheetIdx].pdfPath}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-sky-400 hover:underline"
                  >
                    Open Full PDF in New Tab
                  </a>
                </div>
                <iframe
                  src={DRAWING_SHEETS[selectedSheetIdx].pdfPath}
                  title={`PDF Sheet ${DRAWING_SHEETS[selectedSheetIdx].sheetNo}`}
                  className="w-full flex-1 border-0 bg-white"
                />
              </div>
            </div>
          )}

          {activeTab === 'singlefile' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-slate-800 bg-slate-950 p-4">
                <div>
                  <h3 className="font-display text-sm font-semibold text-white">
                    Self-Contained Single-File HTML + Three.js Application (J-100A246_PEB_3D_Viewer.html)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Ready to save and open in any browser with zero build tools required (1 unit = 1 meter = 1,000 mm).
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyHtml}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-700 transition-colors"
                  >
                    {copiedHtml ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedHtml ? 'Copied HTML' : 'Copy Single-File HTML'}
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadHtml}
                    className="flex items-center gap-1.5 rounded-lg bg-sky-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-sky-500 transition-colors"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download .HTML File
                  </button>
                </div>
              </div>

              <pre className="max-h-[60vh] overflow-auto rounded-lg border border-slate-800 bg-slate-950 p-4 font-mono-num text-xs text-slate-300 leading-relaxed select-all">
                <code>{standaloneHtml}</code>
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
