/**
 * Complete Structural & Dimensional Engineering Data for Project J-100A246 (Revised 9-Sheet Set)
 * Extracted 1:1 from:
 * - J-100A246-AB-01 (Anchor Bolt Plan & Details — Rev 01)
 * - J-100A246-GA-01 (Roof Framing Plan)
 * - J-100A246-GA-02 (Roof Sheeting Plan & Material Specification)
 * - J-100A246-GA-03 (Rigid Frame Cross Sections @ GL-01, GL-02 to 11, GL-12 & Canopy Details)
 * - J-100A246-GA-04 (Endwall Framing & Sheeting Elevation @ GL-1 & GL-12)
 * - J-100A246-GA-05 (Sidewall Framing & Sheeting Elevation @ GL-A)
 * - J-100A246-GA-06 (Sidewall Framing & Sheeting Elevation @ GL-C)
 * - J-100A246-GA-07 (Mezzanine Framing & Decking Plan)
 * - J-100A246-GA-08 (Mezzanine Staircase Plan, Elevation & Handrail Details)
 *
 * Coordinate Convention in 3D Scene (1 unit = 1 meter = 1000 mm):
 * - X-axis: Longitudinal Building Axis from Grid 1 (X = -43.6425m, LEW) to Grid 12 (X = +43.6425m, REW)
 * - Y-axis: Vertical Elevation from Finished Floor Level (FFL ±0.00m at Y = 0)
 * - Z-axis: Transverse Building Axis from Grid A (Z = -8.50m) through Grid B (Z = 0.00m) to Grid C (Z = +8.50m)
 */

export interface GridLineX {
  gridNumber: number;
  label: string;
  baySpacingFromPrevMm: number;
  xCoordMm: number; // Relative to Grid 1 = 0 mm
  xWorldM: number;  // Centered world X coordinate in meters
  isBracedBayAfter: boolean; // Whether bay (i -> i+1) has X-bracing & portal frame
}

export interface GridLineZ {
  gridLetter: 'A' | 'B' | 'C';
  label: string;
  description: string;
  spacingFromPrevMm: number;
  zCoordMm: number; // Relative to Grid A = 0 mm
  zWorldM: number;  // Centered world Z coordinate in meters (Grid B = 0)
}

export interface BasePlateDetailSpec {
  code: 'D1' | 'D1X' | 'D2' | 'D2X' | 'D3' | 'D3X' | 'D4' | 'D5';
  locationSummary: string;
  quantityRequired: number;
  plateWidthMm: number;
  plateLengthMm: number;
  plateThicknessMm: number;
  anchorBoltDiameterMm: number;
  anchorBoltCountPerColumn: number;
  anchorBoltHoleDiaMm: number;
  anchorBoltGrade: string;
  baseType: 'FIXED BASE' | 'PIN BASE (U.N.O.)' | 'MEZZANINE / ANCHOR BOLT PLAN' | 'STAIRCASE COLUMN BASE (GA-08)';
}

export interface DrawingSheetInfo {
  sheetNo: string;
  title: string;
  rev: string;
  date: string;
  pdfPath: string;
  keyTakeaways: string[];
}

export const PROJECT_METADATA = {
  drawingNumber: 'J-100A246',
  projectName: 'ELEGANCE FURNITURE',
  customerName: 'MR. NITIN',
  jobSiteLocation: 'NAGPUR MH',
  consultant: 'MEGH ENGINEERING CONSULTANTS',
  consultantAddress: 'Plot No. 14/15, Jagat Society, Byramji Town, Nagpur–440013',
  scaleRule: '1 World Unit = 1.000 Meter (1,000 mm)',
  legend: {
    FSW: 'FRONT SIDE WALL (Grid C — Mezzanine Staircase Side)',
    BSW: 'BACK SIDE WALL (Grid A)',
    LEW: 'LEFT END WALL (Grid 1 — 3,000 mm Canopy & F.O. 4.5×4.0m)',
    REW: 'RIGHT END WALL (Grid 12 — 3,000 mm Canopy & F.O. 4.5×4.5m)',
  },
} as const;

export const BUILDING_DIMENSIONS_MM = {
  // Longitudinal (X) along Grids 1 to 12
  baySpacingsMm: [8285, 8000, 8000, 8000, 8000, 8000, 7000, 8000, 8000, 8000, 8000] as const,
  lengthColumnCCMm: 87285,         // 8285 + 5*8000 + 7000 + 4*8000 = 87,285 mm
  endwallOverhangLeftMm: 495,      // 495 mm (C/O) outside Grid 1
  endwallOverhangRightMm: 495,     // 495 mm (C/O) outside Grid 12
  lengthOutToOutSteelMm: 88275,    // 87285 + 495 + 495 = 88,275 mm

  // Transverse (Z) along Grids A, B, C
  spanABMm: 8500,                  // Grid A to Grid B = 8,500 mm (C/C)
  spanBCMm: 8500,                  // Grid B to Grid C = 8,500 mm (C/C)
  widthColumnCCMm: 17000,          // Grid A to Grid C = 17,000 mm (C/C of Steel Column)
  sidewallOffsetAMm: 645,          // 645 mm (C/O) from Grid A centerline to outer steel line
  sidewallOffsetCMm: 645,          // 645 mm (C/O) from Grid C centerline to outer steel line
  widthOutToOutSteelMm: 18290,     // 17000 + 645 + 645 = 18,290 mm (O/O of Steel Line)

  // Canopies (Sidewall 6,100 mm Canopy + Endwall 3,000 mm Canopies at GL-1 & GL-12)
  canopyWidthMm: 6100,             // 6,100 mm full-length sidewall canopy projection
  canopyClearHeightMm: 5308,       // 5,308 mm / 5,000 mm clear height under canopy
  canopyFasciaDropMm: 1500,        // 1,500 mm vertical fascia sheeting drop at canopy tip
  endwallCanopyWidthMm: 3000,      // 3,000 mm wide canopies at Left Endwall (GL-1) & Right Endwall (GL-12) between Grid A & B
  endwallCanopyClearHeightMm: 5000,// 5,000 mm clear height under endwall canopies (GA-03 & GA-04)

  // Vertical Elevations & Roof Slope
  fflMm: 0,                        // FFL ±0.00m (U/S of Base Plate)
  highEaveHeightMm: 11315,         // ±11,315 mm High Eave Height
  lowEaveHeightMm: 9485,           // ±9,485 mm Low Eave Height
  clearInternalHeightMm: 8600,     // 8,600 mm Clear Height under main frame knee
  roofSlopeRatio: 0.1,             // 1:10 Mono-Slope
  brickWallHeightMm: 3000,         // Revised to 3,000 mm (3.00m) Brick Wall all around ("3M B/W & ABOVE SHEETING" on AB-01, GA-03..06)
  brickWallThicknessMm: 230,       // 230 mm Brick Wall thickness
  dripTrimOverlapMm: 100,          // 100 mm sheeting overlap below top of brick wall with drip trim

  // Mezzanine Floor System (Grids 1 to 5, Full Width Grid A to C — GA-03, GA-07, GA-08)
  mezzanineStartGrid: 1,           // Starts at Grid 1 (GL-01)
  mezzanineEndGrid: 5,             // Ends at Grid 5 (GL-05) -> 8285 + 3*8000 = 32,285 mm C/C length
  mezzanineLengthCCMm: 32285,      // 32,285 mm C/C (Grids 1 to 5); Grids 5 to 12 marked "FUTURE MEZZANINE"
  mezzanineTopOfSlabMm: 5374,      // EL +5.374 M (5,374 mm) Top of Slab (GA-03, GA-07, GA-08)
  mezzanineClearHeightUnderBeamMm: 4500, // 4,500 mm Bottom of Mezzanine Main Beam (GA-03)
  mezzanineSlabThicknessMm: 150,   // 150 mm RCC composite slab over 0.6 mm thk decking sheet (GA-03, GA-07)
  mezzanineHandrailHeightMm: 1000, // 1,000 mm high tubular handrail (500 + 500 mm, 32 NB tube + 100×6 toe plate, GA-08)
  staircaseWidthXMm: 3235,         // 3,234 / 3,235 mm from Grid 3 to Grid 3' (AB-01, GA-08)
  staircaseLengthZMm: 5750,        // 5,750 mm from Grid C to Grid D (AB-01, GA-08)
  staircaseFlightRiseMm: 1791,     // 3 flights × 1,791 mm = 5,373 ~ 5,374 mm total rise (GA-08)

  // Bracing & Portal Frame Dimensions
  bracedBayIndices: [1, 5, 9] as const, // 0-indexed bays: Bay 2 (Grid 2-3), Bay 6 (Grid 6-7), Bay 10 (Grid 10-11)
  portalBeamHeightMm: 5500,        // Revised to 5,500 mm ("PORTAL BRACING UPTO 5.5M & ABOVE RODBRACING" on AB-01)
  portalColumnInsetMm: 350,        // 350 mm inset from main column centerline

  // Framed Openings (F.O.), Louvers, Purlins, Skylights, Turbo Vents & Drainage
  louverWidthMm: 2000,             // 2,000 mm wide × 1,000 mm high Louver (200C 2.0 frame, GA-04..06)
  louverHeightMm: 1000,            // 1,000 mm high Louver
  louverTotalCount: 26,            // 11 on GL-A + 11 on GL-C + 2 on GL-01 + 2 on GL-12 = 26 Nos.
  mainRoofPurlinLines: 14,         // 100 + 11@1500 + 1000 + BAL + 100 along 18.29m slope
  canopyPurlinLines: 4,            // 100 + 3@1500 + BAL + 100 along 6.10m canopy slope
  skylightWidthMm: 1000,           // 1,000 mm wide FRP Skylight sheet
  skylightLengthMm: 3200,          // 3,200 mm long FRP Skylight sheet
  skylightTotalCount: 22,          // 22 Nos.
  turboVentDiaMm: 600,             // 600 mm diameter Natural Turbo Ventilator
  turboVentTotalCount: 11,         // 11 Nos. (staggered across Bays 1 to 11 on GA-02)
  downspoutBoxSizeMm: 110,         // SQ. 110 BOX downspout at every grid
} as const;

/**
 * Compute exact longitudinal Grid Line coordinates (Grids 1 to 12)
 */
export function getLongitudinalGrids(): GridLineX[] {
  const halfLengthM = (BUILDING_DIMENSIONS_MM.lengthColumnCCMm / 1000) / 2; // 43.6425m
  const bracedSet = new Set<number>(BUILDING_DIMENSIONS_MM.bracedBayIndices);
  const grids: GridLineX[] = [];
  let accumMm = 0;

  for (let i = 0; i < 12; i++) {
    const spacing = i === 0 ? 0 : BUILDING_DIMENSIONS_MM.baySpacingsMm[i - 1];
    accumMm += spacing;
    grids.push({
      gridNumber: i + 1,
      label: `${i + 1}`,
      baySpacingFromPrevMm: spacing,
      xCoordMm: accumMm,
      xWorldM: accumMm / 1000 - halfLengthM,
      isBracedBayAfter: bracedSet.has(i),
    });
  }
  return grids;
}

/**
 * Compute exact transverse Grid Line coordinates (Grids A, B, C)
 */
export function getTransverseGrids(): GridLineZ[] {
  return [
    {
      gridLetter: 'A',
      label: 'A',
      description: 'Back Side Wall (BSW) — 3 Nos. F.O. (4.5×4.0m) in Bays 2–3, 7–8, 10–11 & 11 Louvers',
      spacingFromPrevMm: 0,
      zCoordMm: 0,
      zWorldM: -8.5,
    },
    {
      gridLetter: 'B',
      label: 'B',
      description: 'Centerline Grid — Mezzanine Columns (GL-1 to 5, W=400×5) & Endwall Wind Columns',
      spacingFromPrevMm: 8500,
      zCoordMm: 8500,
      zWorldM: 0,
    },
    {
      gridLetter: 'C',
      label: 'C',
      description: 'Front Side Wall (FSW) — 6.1m Canopy, Staircase at GL 3–3\' & 11 Louvers',
      spacingFromPrevMm: 8500,
      zCoordMm: 17000,
      zWorldM: 8.5,
    },
  ];
}

/**
 * Exact roof surface elevation (in meters) at any transverse world coordinate Z (in meters).
 */
export function getMainRoofElevationAtZ(zWorldM: number): number {
  const zHighEdge = -8.5 - 0.645; // -9.145 m
  const zLowEdge = 8.5 + 0.645;   // +9.145 m
  const t = (zWorldM - zHighEdge) / (zLowEdge - zHighEdge);
  return 11.315 - t * (11.315 - 9.485);
}

/**
 * Exact canopy roof elevation (in meters) for Z from +9.145 m (Grid C outer steel line)
 * to +15.245 m (+9.145 + 6.10 m canopy projection), sloping at 1:10.
 */
export function getCanopyRoofElevationAtZ(zWorldM: number): number {
  const zCanopyStart = 8.5 + 0.645; // +9.145 m
  const dz = Math.max(0, zWorldM - zCanopyStart);
  const topAtWallM = 5.308 + 0.70 + 0.25; // 6.258 m top of canopy sheeting at wall
  return topAtWallM - dz * 0.1; // 1:10 slope
}

export const BASE_PLATE_DETAILS: BasePlateDetailSpec[] = [
  {
    code: 'D1',
    locationSummary: 'Corner Columns at Grid A-1 & Grid C-12',
    quantityRequired: 2,
    plateWidthMm: 360,
    plateLengthMm: 750,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 10,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'FIXED BASE',
  },
  {
    code: 'D1X',
    locationSummary: 'Corner Columns (Opp. Hand) at Grid C-1 & Grid A-12',
    quantityRequired: 2,
    plateWidthMm: 360,
    plateLengthMm: 750,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 10,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'FIXED BASE',
  },
  {
    code: 'D2',
    locationSummary: 'Sidewall Columns along Grid A (Grids 2 to 11)',
    quantityRequired: 10,
    plateWidthMm: 360,
    plateLengthMm: 750,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 10,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'FIXED BASE',
  },
  {
    code: 'D2X',
    locationSummary: 'Sidewall Columns (Opp. Hand) along Grid C (Grids 2 to 11)',
    quantityRequired: 10,
    plateWidthMm: 360,
    plateLengthMm: 750,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 10,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'FIXED BASE',
  },
  {
    code: 'D3',
    locationSummary: 'Left Endwall Center Column at Grid B-1',
    quantityRequired: 1,
    plateWidthMm: 260,
    plateLengthMm: 450,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 4,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'PIN BASE (U.N.O.)',
  },
  {
    code: 'D3X',
    locationSummary: 'Right Endwall Center Column (Opp. Hand) at Grid B-12',
    quantityRequired: 1,
    plateWidthMm: 260,
    plateLengthMm: 450,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 4,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'PIN BASE (U.N.O.)',
  },
  {
    code: 'D4',
    locationSummary: 'Interior Grid B Mezzanine Columns (B-2 to B-5 Active Mezzanine; B-6 to B-11 Future Mezzanine)',
    quantityRequired: 10,
    plateWidthMm: 260,
    plateLengthMm: 450,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 4,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'MEZZANINE / ANCHOR BOLT PLAN',
  },
  {
    code: 'D5',
    locationSummary: 'Mezzanine Staircase Support Columns at Grids C-3\', D-3\', D-3 (Bay 3–4)',
    quantityRequired: 3,
    plateWidthMm: 240,
    plateLengthMm: 350,
    plateThicknessMm: 25,
    anchorBoltDiameterMm: 24,
    anchorBoltCountPerColumn: 4,
    anchorBoltHoleDiaMm: 30,
    anchorBoltGrade: "'J' TYPE GR. 4.60",
    baseType: 'STAIRCASE COLUMN BASE (GA-08)',
  },
];

/**
 * Main building anchor bolts specified on AB-01 table = 288 Nos. M-24
 * (Plus 3 × 4 = 12 Nos. M-24 bolts on Detail D5 staircase columns on GA-08)
 */
export function getTotalAnchorBoltCount(): number {
  return BASE_PLATE_DETAILS.filter((b) => b.code !== 'D5').reduce(
    (sum, item) => sum + item.quantityRequired * item.anchorBoltCountPerColumn,
    0,
  );
}

export const STRUCTURAL_MEMBER_SCHEDULE = [
  {
    category: 'Primary Main Frames (GL-01 to GL-12)',
    member: 'Sidewall Columns (Grid A & Grid C) & Main Rafter (1:10 Slope)',
    profile: 'Cols: W=500×5, 2F=180×10/12 | Rafter: W=700~500×5 / W=500×5 / W=500~600×5',
    remarks: 'High Eave ±11,315 mm, Low Eave ±9,485 mm, Clear Height 8,600 mm; Splices SP-1, SP-2, SP-3',
  },
  {
    category: 'Mezzanine Floor System (Grids 1 to 5, A to C — GA-03 & GA-07)',
    member: 'Mezzanine Main Beams, Support Columns & MJ-1 Joists',
    profile: 'Main Beam: W=700×8, 2F=275×12 | Col B: W=400×5, 2F=225×12 | Joist MJ-1: W=450×5, 2F=130×6',
    remarks: 'T.O. Slab EL +5.374m, B.O. Beam +4.500m, 150mm RCC Slab on 0.6mm Decking Sheet; Grids 5–12 Future Mezzanine',
  },
  {
    category: 'Mezzanine Staircase & Handrail (Bay 3–4, Grid C to D — GA-08)',
    member: '3-Flight Dog-Leg Staircase, D5 Columns & 1.0m Tubular Handrail',
    profile: 'Cols (3 Nos): W=300×5, 2F=180×8 (PLT 350×240×25) | Stringers: ISMC 250 | Rail: 32 NB Tube + 100×6 Toe Plt',
    remarks: 'Footprint 3,235 mm (GL 3–3\') × 5,750 mm (GL C–D); 3 rises of 1,791 mm = +5,374 mm; Treads 250×158 mm',
  },
  {
    category: 'Canopy Framing (6.1m Sidewall + 3.0m Endwall Canopies — GA-03 & GA-04)',
    member: 'Full-Length 6,100mm Sidewall Canopy + 3,000mm LEW & REW Canopies',
    profile: '6.1m Rafter: W=700~500×5 (NB100×100×2.9 tie) | 3.0m LEW/REW Rafter: W=600~300×5, 2F=150×6 (200Z1.5 purlins)',
    remarks: '3,000 mm wide Endwall Canopies at GL-01 (CANOPY GL-B) and GL-12 (CANOPY GL-A) with 5,000 mm clear height',
  },
  {
    category: 'Framed Openings (F.O.) & Rolling Shutters (AB-01, GA-04, GA-05)',
    member: '5 Nos. ISMC 200 Framed Openings for Rolling Shutters',
    profile: '3 Sidewall F.O.: 4.5m × 4.0m (Bays 2–3, 7–8, 10–11) | LEW F.O.: 4.5m × 4.0m | REW F.O.: 4.5m × 4.5m',
    remarks: 'Framed with ISMC 200 jambs & header channels (Details A, B, C, D on GA-04 & GA-05)',
  },
  {
    category: 'Wall Louvers (GA-03, GA-04, GA-05, GA-06)',
    member: '26 Nos. Industrial Cladding Louvers (1,000 × 2,000 mm)',
    profile: 'Subframe: 200C 2.0 Cold-Formed Channel | Size: 1.0m × 2.0m with insect screen & blades',
    remarks: '11 Nos. on GL-A (1/bay) + 11 Nos. on GL-C (1/bay) + 2 Nos. on GL-01 + 2 Nos. on GL-12',
  },
  {
    category: 'Sidewall Portal Bracing (Bays 2–3, 6–7, 10–11 — AB-01, GA-05, GA-06)',
    member: 'Revised 5.5m High Portal Columns & Beam (Detail-C)',
    profile: 'Portal Col: W=400×5, 2F=180×8 (H=5,500 mm) | Portal Beam: W=400×5, 2F=150×8 + 25mm Rod X-Bracing',
    remarks: 'Raised to 5.50m ("PORTAL BRACING UPTO 5.5M & ABOVE RODBRACING") to clear 4.0m shutters & 5.374m mezzanine',
  },
  {
    category: 'Envelope, 3.0m Brickwork, Turbo Vents & Drainage',
    member: '3,000 mm Brick Dado Wall, BG/PPGI Sheeting, 11 Turbo Vents & 24 Downspouts',
    profile: 'Brick Wall: 3,000 mm H × 230 mm Thk ("3M B/W & ABOVE SHEETING") | Roof: 0.47mm BG | Wall: 0.50mm PPGI',
    remarks: '11 Nos. Ø600mm Turbo Vents (staggered), 22 FRP Skylights, SQ.110 Downspouts at every grid, Cage Ladder @ A-12',
  },
] as const;

export const DRAWING_SHEETS: DrawingSheetInfo[] = [
  {
    sheetNo: 'AB-01',
    title: 'ANCHOR BOLT PLAN & DETAILS (REVISED)',
    rev: '01',
    date: '18.09.26',
    pdfPath: '/assets/aistudio/J-100A246-AB-01_45d4a8bf.pdf',
    keyTakeaways: [
      'Mezzanine Floor hatched across Grids 1 to 5 (Full 17,000 mm width A to C); Grids 5 to 12 labeled "FUTURE MEZZANINE"',
      'Mezzanine Staircase in Bay 3–4 (Grid 3 to 3\' = 3,234 mm, Grid C to D = 5,750 mm) with 3 Nos. D5 column bases',
      '5 Framed Openings (F.O.): 3 on Sidewall (4.5×4.0m in Bays 2–3, 7–8, 10–11), 1 on LEW GL-1 (4.5×4.0m), 1 on REW GL-12 (4.5×4.5m)',
      'New 3,000 mm wide Endwall Canopies on LEW (GL-1, A–B) and REW (GL-12, A–B) in addition to 6,100 mm Sidewall Canopy',
      'Brickwall updated to "3M B/W & ABOVE SHEETING" (3,000 mm high); Portal Bracing updated to "UPTO 5.5M & ABOVE RODBRACING"',
    ],
  },
  {
    sheetNo: 'GA-01',
    title: 'ROOF FRAMING PLAN',
    rev: '00',
    date: '17.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-01_4ff55f9b.pdf',
    keyTakeaways: [
      'Main Roof Purlins: END PURLIN 250Z2.0 (Bays 1–2 & 11–12), INT PURLIN 250Z1.75 (Bays 2–11) with 12mm Ø sag rods',
      'Sidewall 6.1m Canopy Purlins: 200Z1.8 with 12mm Ø sag rods and 25mm Ø Rod Bracing in Bays 2–3, 6–7, 10–11',
      'Endwall 3.0m Canopy Purlins at GL-1 & GL-12 (A–B): CANOPY PURLIN 200Z1.5 with 12mm Ø sag rods',
      'Main Roof 25mm Ø Rod X-Bracing in Bays 2–3, 6–7, 10–11 with STRUT 100×100×3.2 tubes along Grids A, B, C',
    ],
  },
  {
    sheetNo: 'GA-02',
    title: 'ROOF SHEETING PLAN & MATERIAL SPECIFICATION',
    rev: '00',
    date: '01.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-02_b0f2d93d.pdf',
    keyTakeaways: [
      'Roof Sheet: BG 1000 width, 0.47 mm thk; Wall & Canopy Panel: PPGI 1000 width, 0.50 mm thk',
      '11 Nos. 600 mm DIA. Natural Turbo Ventilators staggered across Bays 1 to 11',
      'Sheeting plans shown for full-length 6,100 mm Sidewall Canopy and both 3,000 mm Endwall Canopies (GL-1 & GL-12)',
      '0.5 mm Galvalume Eaves Gutter, 2.0 mm GI Valley Gutter, and SQ. 110 Box Downspouts at every grid line',
    ],
  },
  {
    sheetNo: 'GA-03',
    title: 'RIGID FRAME CROSS SECTION (WITH MEZZANINE)',
    rev: '00',
    date: '01.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-03_f8650f87.pdf',
    keyTakeaways: [
      'Cross Sections @ GL-01 and @ GL-02 to 11 show Mezzanine Floor: Top of Slab = 5,374 mm, Bottom of Beam = 4,500 mm, Slab Thickness = 150 mm',
      'Mezzanine Main Beam: W=700×8, 2F=275×12 supported on Grid B Mezzanine Column W=400×5, 2F=225×12 ("MEZZANINE ONLY IN FL. 2 TO 5 / IN FL. 6 TO 11 IN FUTURE")',
      'Brickwall height = 3,000 mm on both sidewalls with 100 mm sheeting overlap and Louvers (1 × 2M) at upper wall zone',
      'Details for CANOPY GL-B (3,000 mm wide, 5,000 mm clear ht, W=600~300×5) and CANOPY GL-A (3,000 mm wide with stitch column W=300×5)',
      'Expanded Splice Table SP-1 through SP-7 (including SP-4 M30×90, SP-5 M36×90, SP-6/SP-7 M24×90 for mezzanine beam connections)',
    ],
  },
  {
    sheetNo: 'GA-04',
    title: 'ENDWALL FRAMING & SHEETING ELEVATION @ GL-1 & 12',
    rev: '00',
    date: '18.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-04_3ebead9c.pdf',
    keyTakeaways: [
      'Endwall @ GL-01 & @ GL-12 show internal Mezzanine Beam at +4,500 mm / Slab at +5,374 mm and 3,000 mm Brick Wall',
      'Right Endwall (@GL-12) features F.O. 4.5m × 4.5m (2000 + 4500 + 2000 = 8500 mm between Grid A & B) framed with ISMC 200 jambs & header',
      'Both GL-01 and GL-12 include 2 Nos. Louvers (1 × 2M, 200C 2.0) in the upper cladding zone (1 in A–B, 1 in B–C)',
      'Includes Door Framing Connection Details A (Jamb Base), B (Z-Girt to Jamb), C (Header to Jamb), and D (Door Jamb to Z-Girt)',
    ],
  },
  {
    sheetNo: 'GA-05',
    title: 'SIDEWALL FRAMING & SHEETING ELEVATION @ GL-A',
    rev: '00',
    date: '18.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-05_fa35f515.pdf',
    keyTakeaways: [
      'Shows 3 Nos. Framed Openings F.O. 4.5m × 4.0m in Bay 2–3 (1750+4500+1750), Bay 7–8 (1250+4500+1250), and Bay 10–11 (1750+4500+1750) with ISMC 200 framing',
      'Shows Mezzanine Floor line across Grids 1 to 4/5 and 3,000 mm high Brick Wall (B/W) all along the elevation',
      '11 Nos. Louvers (1.0m × 2.0m, 200C 2.0) — 1 centered in every bay from Bay 1 to Bay 11 above the canopy line',
      'Detail-C Portal Bracing in Bays 2–3, 6–7, 10–11 raised to clear the 4.0m framed openings with 25mm Ø Rod Bracing above',
    ],
  },
  {
    sheetNo: 'GA-06',
    title: 'SIDEWALL FRAMING & SHEETING ELEVATION @ GL-C',
    rev: '00',
    date: '18.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-06_41ee1d76.pdf',
    keyTakeaways: [
      'Sidewall @ GL-C (High Eave ±11,315 mm) with 3,000 mm high Brick Wall and girt spacing 1050 + 1050 + 1500 + 1500 + 1500 + BAL',
      'Shows Mezzanine Floor line from Grid 1 to Grid 5 and Detail-C Portal Bracing in Bays 2–3, 6–7, 10–11',
      '11 Nos. Louvers (1.0m × 2.0m, 200C 2.0) — 1 centered in every bay across all 11 bays at upper wall zone',
    ],
  },
  {
    sheetNo: 'GA-07',
    title: 'MEZZANINE PLAN & DECKING DETAILS (NEW SHEET)',
    rev: '00',
    date: '18.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-07_3aec5172.pdf',
    keyTakeaways: [
      'Mezzanine Plan spanning Grids 1 to 5 (32,285 mm C/C) and Grids A to C (17,000 mm C/C); Grids 5 to 12 marked "FUTURE MEZZANINE"',
      'Part MJ-1 Mezzanine Joist Table: Flange = 130×6 THK., Web = 450×5 THK. (bolted to main beam with 4–M24 bolts & 16mm end plate)',
      'Composite Decking: EL +5.374M T.O. Slab, 150 mm thick RCC slab (by others) over 0.6 mm THK. profiled decking sheet fixed with staggered SDS-24×35 screws @ every valley & shear studs',
      'Edge Details (Section B-B & Section X-X): 150×150×2.0mm / 1.5mm thk sheeting angle, 50mm strap @ 700mm C/C, stitching screw @ 500mm C/C',
    ],
  },
  {
    sheetNo: 'GA-08',
    title: 'STAIRCASE PLAN & DETAILS (NEW SHEET)',
    rev: '00',
    date: '18.09.26',
    pdfPath: '/assets/aistudio/J-100A246-GA-08_48885fb9.pdf',
    keyTakeaways: [
      'Mezzanine Staircase located between Grid 3 & Grid 3\' (3,235 mm) and Grid C & Grid D (5,750 mm) rising from FFL ±0.00M to EL +5,374 mm',
      '3-Stage Multi-Flight Staircase with 2 Checkered Plate Mid-Landings at +1,791 mm and +3,582 mm (3 × 1,791 = 5,373 ~ 5,374 mm)',
      'Supported by 3 Nos. Staircase Columns (WEB 300×5, FLANGE 180×8) on Detail D5 Base Plates (PLT. 350×240×25 with 4 Nos. M-24 J-bolts)',
      'Stringers & Landing Beams: ISMC 250 with 250 mm × 158 mm treads (STRD1, 2–M12×40 bolts) and 1,000 mm high Handrail (32 NB tube posts & rails @ 500+500 mm + 100×6 toe plate)',
    ],
  },
];
