/**
 * Generates a 100% self-contained, single-file HTML + Three.js application
 * that renders the exact Revised Project J-100A246 PEB Building (9-Sheet Set: AB-01 & GA-01..08).
 * Scale: 1 unit = 1 meter = 1000 mm.
 */
export function generateStandaloneSingleFileHtml(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>J-100A246 PEB 3D Structural &amp; Mezzanine Viewer — Elegance Furniture (Nagpur MH)</title>
  <script type="importmap">
    {
      "imports": {
        "three": "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js",
        "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/"
      }
    }
  </script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      overflow: hidden;
      background: #0b111e;
      color: #f1f5f9;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      user-select: none;
    }
    #canvas-container { position: fixed; inset: 0; }
    .top-spec-bar {
      position: fixed;
      top: 14px;
      left: 16px;
      right: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 16px;
      background: rgba(15, 23, 42, 0.92);
      border: 1px solid rgba(148, 163, 184, 0.2);
      border-radius: 10px;
      pointer-events: auto;
      z-index: 10;
    }
    .brand-title { font-size: 14px; font-weight: 700; color: #f8fafc; letter-spacing: 0.01em; }
    .spec-meta { font-family: monospace; font-size: 12px; color: #94a3b8; }
    .bottom-dock {
      position: fixed;
      bottom: 18px;
      left: 50%;
      transform: translateX(-50%);
      max-width: min(1040px, 96vw);
      width: 100%;
      background: rgba(15, 23, 42, 0.94);
      border: 1px solid rgba(148, 163, 184, 0.24);
      border-radius: 12px;
      padding: 12px 16px;
      z-index: 10;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .row { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px; }
    .btn-group { display: flex; flex-wrap: wrap; gap: 6px; }
    button {
      background: #1e293b;
      color: #e2e8f0;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 6px 11px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s, border-color 0.15s;
    }
    button:hover { background: #334155; }
    button.active { background: #0284c7; border-color: #38bdf8; color: #fff; }
    label.toggle {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: #cbd5e1;
      cursor: pointer;
      padding: 4px 8px;
      background: rgba(30, 41, 59, 0.7);
      border-radius: 6px;
      border: 1px solid rgba(71, 85, 105, 0.5);
    }
  </style>
</head>
<body>
  <div id="canvas-container"></div>

  <header class="top-spec-bar">
    <div class="brand-title">J-100A246 — ELEGANCE FURNITURE PEB (REVISED 9-SHEET SET: AB-01 &amp; GA-01..08)</div>
    <div class="spec-meta">87,285×17,000 C/C · Mezzanine EL +5.374m (Grids 1–5) · FSW Shutters (Bays 2–3, 7–8, 10–11) · FSW Canopy (Grids 1–11) &amp; 3.0m EW Canopies</div>
  </header>

  <div class="bottom-dock">
    <div class="row">
      <div class="btn-group" id="preset-buttons">
        <button data-preset="iso" class="active">Isometric 3D</button>
        <button data-preset="front">Front Elevation (FSW)</button>
        <button data-preset="back">Back Elevation (BSW)</button>
        <button data-preset="left">Left Endwall (LEW)</button>
        <button data-preset="right">Right Endwall (REW)</button>
        <button data-preset="roof">Roof Plan</button>
        <button data-preset="inside">Inside Walkthrough (Mezzanine)</button>
      </div>
    </div>
    <div class="row">
      <div class="btn-group">
        <label class="toggle"><input type="checkbox" id="chk-cladding" checked /> Roof / Wall Cladding</label>
        <label class="toggle"><input type="checkbox" id="chk-mezzanine" checked /> Mezzanine &amp; Staircase (+5.374m)</label>
        <label class="toggle"><input type="checkbox" id="chk-brick" checked /> 3.00m Brick Wall</label>
        <label class="toggle"><input type="checkbox" id="chk-openings" checked /> Openings / Louvers / Vents</label>
        <label class="toggle"><input type="checkbox" id="chk-grid" checked /> Grid Lines &amp; Dimensions</label>
        <label class="toggle"><input type="checkbox" id="chk-wireframe" /> X-Ray / Wireframe</label>
      </div>
      <div class="spec-meta">Scale: 1 Unit = 1.000m (1,000mm) · 288+12 M-24 Bolts · FSW &amp; BSW 4.5m Shutters (Bays 2–3, 7–8, 10–11) · 26 Louvers</div>
    </div>
  </div>

  <script type="module">
    import * as THREE from 'three';
    import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
    import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

    const container = document.getElementById('canvas-container');
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b111e);
    scene.fog = new THREE.FogExp2(0x0b111e, 0.0045);

    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.2, 500);
    camera.position.set(58, 30, 62);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.target.set(0, 5.0, 2.0);

    // Lighting
    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 0.85);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff7ed, 2.2);
    sunLight.position.set(55, 85, 48);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(2048, 2048);
    const d = 60;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 220;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);

    // Exact J-100A246 Coordinates (1 unit = 1m = 1000mm)
    const baySpacings = [8.285, 8, 8, 8, 8, 8, 7, 8, 8, 8, 8]; // Total 87.285m C/C
    const halfLen = 87.285 / 2; // 43.6425m
    const gridsX = [0];
    baySpacings.forEach(s => gridsX.push(gridsX[gridsX.length - 1] + s));
    const worldX = gridsX.map(x => x - halfLen);

    const xOuterL = worldX[0] - 0.495;
    const xGrid11 = worldX[10]; // End of FSW Canopy (Bay 11-12 canopy removed)
    const xOuterR = worldX[11] + 0.495;
    const totalLenOO = xOuterR - xOuterL; // 88.275m

    // FSW Canopy spans from Left Outer Line (Grid 1) to Grid 11 only
    const fswCanopyLen = xGrid11 - xOuterL;
    const fswCanopyMidX = (xOuterL + xGrid11) / 2;

    const zGridA = -8.5, zGridB = 0, zGridC = 8.5;
    const zOuterA = -9.145, zOuterC = 9.145;
    const totalWidthOO = 18.29;
    const canopyWidth = 6.10;
    const zCanopyEdge = zOuterC + canopyWidth;
    const brickWallH = 3.00; // 3.00m Brick Dado Wall

    const roofY = (z) => 11.315 - ((z - zOuterA) / totalWidthOO) * (11.315 - 9.485);
    const canopyY = (z) => 6.258 - Math.max(0, z - zOuterC) * 0.1;

    const groups = {
      cladding: new THREE.Group(),
      mezzanine: new THREE.Group(),
      brick: new THREE.Group(),
      openings: new THREE.Group(),
      steel: new THREE.Group(),
      grid: new THREE.Group(),
    };
    Object.values(groups).forEach(g => scene.add(g));

    // Materials
    const matSlab = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.85 });
    const matRamp = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.78 });
    const matSteel = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.38, metalness: 0.7 });
    const matPortal = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.36, metalness: 0.7 });
    const matMezzSteel = new THREE.MeshStandardMaterial({ color: 0x0f766e, roughness: 0.35, metalness: 0.72 });
    const matMezzSlab = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.78, metalness: 0.15 });
    const matHandrail = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.32, metalness: 0.65 });
    const matPurlin = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.35, metalness: 0.75 });
    const matBrick = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.85 });
    const matClad = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.42, metalness: 0.45, side: THREE.DoubleSide });
    const matRoof = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, roughness: 0.28, metalness: 0.75, side: THREE.DoubleSide });
    const matTrim = new THREE.MeshStandardMaterial({ color: 0x1e40af, roughness: 0.35, metalness: 0.6, side: THREE.DoubleSide });
    const matShutter = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.45, metalness: 0.65 });
    const matLouver = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4, metalness: 0.75 });
    const matSkylight = new THREE.MeshStandardMaterial({ color: 0x7dd3fc, emissive: 0x0284c7, emissiveIntensity: 0.25, transparent: true, opacity: 0.62 });

    // Concrete Floor & FSW Canopy Apron (Grids 1 to 11 only; Bay 11-12 removed)
    const slab = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, 0.25, totalWidthOO), matSlab);
    slab.position.set(0, -0.125, 0);
    slab.receiveShadow = true;
    const apron = new THREE.Mesh(new THREE.BoxGeometry(fswCanopyLen, 0.2, canopyWidth), matSlab);
    apron.position.set(fswCanopyMidX, -0.1, zOuterC + canopyWidth / 2);
    groups.steel.add(slab, apron);

    // 12 Primary Frames + FSW Canopy Rafters (Grids 1 to 11 only; Bay 11-12 canopy removed)
    const slopeAngle = Math.atan(0.1);
    worldX.forEach((x, idx) => {
      const colA = new THREE.Mesh(new THREE.BoxGeometry(0.18, 10.9, 0.5), matSteel);
      colA.position.set(x, 5.45, zGridA);
      const colC = new THREE.Mesh(new THREE.BoxGeometry(0.18, 9.1, 0.5), matSteel);
      colC.position.set(x, 4.55, zGridC);
      groups.steel.add(colA, colC);

      if (idx === 0 || idx === 11) {
        const colB = new THREE.Mesh(new THREE.BoxGeometry(0.225, 10.0, 0.4), matSteel);
        colB.position.set(x, 5.0, zGridB);
        groups.steel.add(colB);
      }

      const rafter = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.55, Math.hypot(totalWidthOO, 1.83)), matSteel);
      rafter.position.set(x, (11.315 + 9.485) / 2 - 0.5, 0);
      rafter.rotation.x = slopeAngle;
      groups.steel.add(rafter);

      if (idx <= 10) {
        const cRafter = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.55, Math.hypot(canopyWidth, 0.61)), matSteel);
        cRafter.position.set(x, canopyY(zOuterC + canopyWidth / 2) - 0.4, zOuterC + canopyWidth / 2);
        cRafter.rotation.x = slopeAngle;
        groups.steel.add(cRafter);
      }
    });

    // 2 Fully-Clad 3,000mm Endwall Canopies at LEW (@GL-01) and REW (@GL-12) between Grid A and Grid B
    // Solid PPGI metal roof sheeting, vertical fascia drop, closed side cheeks, and Royal Blue trims
    {
      const ewZ1 = zOuterA, ewZ2 = zGridB + 0.18;
      const ewLenZ = ewZ2 - ewZ1, ewMidZ = (ewZ1 + ewZ2) / 2;
      const ewSlopeW = Math.hypot(3.0, 0.30);
      const yWallTop = 5.68, yTipTop = 5.38, yFasciaBot = 4.55;
      const fasciaH = yTipTop - yFasciaBot;

      [
        { xWall: xOuterL, dir: -1 },
        { xWall: xOuterR, dir: 1 },
      ].forEach(ew => {
        const midX = ew.xWall + ew.dir * 1.5;
        const tipX = ew.xWall + ew.dir * 3.0;

        // Top PPGI / Galvalume Roof Deck & Underside Soffit Liner (tilted downward away from wall via -ew.dir * slopeAngle)
        const ewRoof = new THREE.Mesh(new THREE.BoxGeometry(ewSlopeW, 0.055, ewLenZ), matRoof);
        ewRoof.position.set(midX, (yWallTop + yTipTop) / 2 + 0.03, ewMidZ);
        ewRoof.rotation.z = -ew.dir * slopeAngle;
        const ewSoffit = new THREE.Mesh(new THREE.BoxGeometry(ewSlopeW - 0.04, 0.03, ewLenZ - 0.04), matClad);
        ewSoffit.position.set(midX, (yWallTop + yTipTop) / 2 - 0.04, ewMidZ);
        ewSoffit.rotation.z = -ew.dir * slopeAngle;
        groups.cladding.add(ewRoof, ewSoffit);

        // Vertical Front Fascia Sheeting
        const ewFascia = new THREE.Mesh(new THREE.BoxGeometry(0.045, fasciaH, ewLenZ), matClad);
        ewFascia.position.set(tipX, yFasciaBot + fasciaH / 2, ewMidZ);
        groups.cladding.add(ewFascia);

        // Closed PPGI Side Cheek Panels & Blue Rake Trims at Grid A and Grid B
        [ewZ1 + 0.02, ewZ2 - 0.02].forEach(cz => {
          const verts = new Float32Array([
            ew.xWall, yFasciaBot, cz,
            tipX,     yFasciaBot, cz,
            tipX,     yTipTop,    cz,
            ew.xWall, yWallTop,   cz,
          ]);
          const cGeo = new THREE.BufferGeometry();
          cGeo.setAttribute('position', new THREE.BufferAttribute(verts, 3));
          cGeo.setIndex([0, 1, 2, 0, 2, 3]);
          cGeo.computeVertexNormals();
          groups.cladding.add(new THREE.Mesh(cGeo, matClad));

          const sideRake = new THREE.Mesh(new THREE.BoxGeometry(ewSlopeW + 0.12, 0.16, 0.14), matTrim);
          sideRake.position.set(midX, (yWallTop + yTipTop) / 2 + 0.03, cz);
          sideRake.rotation.z = -ew.dir * slopeAngle;
          const sideBot = new THREE.Mesh(new THREE.BoxGeometry(3.10, 0.12, 0.14), matTrim);
          sideBot.position.set(midX, yFasciaBot, cz);
          groups.cladding.add(sideRake, sideBot);
        });

        // Royal Blue Wall Flashing, Outer Eave & Bottom Fascia Trims
        const topFlash = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, ewLenZ + 0.12), matTrim);
        topFlash.position.set(ew.xWall + ew.dir * 0.05, yWallTop + 0.05, ewMidZ);
        const eaveTrim = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, ewLenZ + 0.14), matTrim);
        eaveTrim.position.set(tipX + ew.dir * 0.04, yTipTop, ewMidZ);
        const botTrim = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, ewLenZ + 0.14), matTrim);
        botTrim.position.set(tipX + ew.dir * 0.03, yFasciaBot, ewMidZ);
        groups.cladding.add(topFlash, eaveTrim, botTrim);

        // Internal Rafters below canopy roof
        [-8.5, -4.25, 0].forEach(zR => {
          const ewRafter = new THREE.Mesh(new THREE.BoxGeometry(2.9, 0.36, 0.15), matPortal);
          ewRafter.position.set(midX, 5.10, zR);
          ewRafter.rotation.z = -ew.dir * slopeAngle;
          groups.steel.add(ewRafter);
        });
      });
    }

    // Revised 5,500mm Portal Frames & Bracing in Bays 2-3 (idx 1), 6-7 (idx 5), 10-11 (idx 9)
    [1, 5, 9].forEach(bIdx => {
      const x1 = worldX[bIdx], x2 = worldX[bIdx + 1];
      [zGridA, zGridC].forEach(z => {
        const pBeam = new THREE.Mesh(new THREE.BoxGeometry(x2 - x1, 0.4, 0.15), matPortal);
        pBeam.position.set((x1 + x2) / 2, 5.5, z);
        const pCol1 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 5.5, 0.4), matPortal);
        pCol1.position.set(x1 + 0.35, 2.75, z);
        const pCol2 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 5.5, 0.4), matPortal);
        pCol2.position.set(x2 - 0.35, 2.75, z);
        groups.steel.add(pBeam, pCol1, pCol2);
      });
    });

    // MEZZANINE FLOOR SYSTEM (Grids 1 to 5, EL +5.374m T.O.S., +4.500m B.O.B., GA-03, GA-07, GA-08)
    {
      const xMezzStart = worldX[0], xMezzEnd = worldX[4];
      const xStairStart = worldX[2], xStairEnd = worldX[2] + 3.235;
      const zStairStart = zGridC - 5.75, zStairEnd = zGridC;
      const yTOS = 5.374, slabThk = 0.15, yBOB = 4.50;

      for (let g = 1; g <= 4; g++) {
        const mCol = new THREE.Mesh(new THREE.BoxGeometry(0.225, yBOB, 0.40), matMezzSteel);
        mCol.position.set(worldX[g], yBOB / 2, zGridB);
        groups.mezzanine.add(mCol);
      }
      for (let g = 0; g <= 4; g++) {
        const mBeam = new THREE.Mesh(new THREE.BoxGeometry(0.275, 0.70, 17.0), matMezzSteel);
        mBeam.position.set(worldX[g], yBOB + 0.35, 0);
        groups.mezzanine.add(mBeam);
      }
      for (let j = 0; j <= 10; j++) {
        const jz = zGridA + (j / 10) * 17.0;
        if (jz > zStairStart + 0.1) {
          const j1 = new THREE.Mesh(new THREE.BoxGeometry(xStairStart - xMezzStart, 0.45, 0.13), matPurlin);
          j1.position.set((xMezzStart + xStairStart) / 2, yTOS - slabThk - 0.225, jz);
          const j2 = new THREE.Mesh(new THREE.BoxGeometry(xMezzEnd - xStairEnd, 0.45, 0.13), matPurlin);
          j2.position.set((xStairEnd + xMezzEnd) / 2, yTOS - slabThk - 0.225, jz);
          groups.mezzanine.add(j1, j2);
        } else {
          const jFull = new THREE.Mesh(new THREE.BoxGeometry(xMezzEnd - xMezzStart, 0.45, 0.13), matPurlin);
          jFull.position.set((xMezzStart + xMezzEnd) / 2, yTOS - slabThk - 0.225, jz);
          groups.mezzanine.add(jFull);
        }
      }
      const sNorth = new THREE.Mesh(new THREE.BoxGeometry(xMezzEnd - xMezzStart, slabThk, zStairStart - zGridA), matMezzSlab);
      sNorth.position.set((xMezzStart + xMezzEnd) / 2, yTOS - slabThk / 2, (zGridA + zStairStart) / 2);
      const sWest = new THREE.Mesh(new THREE.BoxGeometry(xStairStart - xMezzStart, slabThk, zStairEnd - zStairStart), matMezzSlab);
      sWest.position.set((xMezzStart + xStairStart) / 2, yTOS - slabThk / 2, (zStairStart + zStairEnd) / 2);
      const sEast = new THREE.Mesh(new THREE.BoxGeometry(xMezzEnd - xStairEnd, slabThk, zStairEnd - zStairStart), matMezzSlab);
      sEast.position.set((xStairEnd + xMezzEnd) / 2, yTOS - slabThk / 2, (zStairStart + zStairEnd) / 2);
      groups.mezzanine.add(sNorth, sWest, sEast);

      [0.5, 1.0].forEach(ry => {
        const railG5 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 17.0), matHandrail);
        railG5.position.set(xMezzEnd, yTOS + ry, 0);
        groups.mezzanine.add(railG5);
      });

      const yL1 = 1.791, yL2 = 3.582;
      const l1 = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.12, 1.25), matMezzSteel);
      l1.position.set(xStairStart + 0.625, yL1, zStairStart + 0.625);
      const l2 = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.12, 1.25), matMezzSteel);
      l2.position.set(xStairEnd - 0.625, yL2, zStairStart + 0.625);
      groups.mezzanine.add(l1, l2);

      [
        { x: xStairStart + 0.625, z: zStairStart + 0.15, h: yL1 },
        { x: xStairEnd - 0.15, z: zStairStart + 0.15, h: yL2 },
        { x: xStairEnd - 0.15, z: zStairStart + 1.25, h: yL2 },
      ].forEach(sc => {
        const col = new THREE.Mesh(new THREE.BoxGeometry(0.18, sc.h, 0.30), matMezzSteel);
        col.position.set(sc.x, sc.h / 2, sc.z);
        groups.mezzanine.add(col);
      });
    }

    // 14 Roof Z-Purlins
    for (let i = 0; i < 14; i++) {
      const pz = zOuterA + 0.1 + (i / 13) * (totalWidthOO - 0.2);
      const pMesh = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, 0.25, 0.08), matPurlin);
      pMesh.position.set(0, roofY(pz) - 0.15, pz);
      pMesh.rotation.x = slopeAngle;
      groups.steel.add(pMesh);
    }

    // Shifted 4.5x4.5m Rolling Shutters & Concrete Ramps on Front Sidewall (FSW @GL-C) & Back Sidewall (BSW @GL-A)
    // Placed in Bays 2-3 (idx 1), 7-8 (idx 6), and 10-11 (idx 9)
    [1, 6, 9].forEach(bIdx => {
      const mx = (worldX[bIdx] + worldX[bIdx + 1]) / 2;
      // FSW 4.5x4.5m Rolling Shutter + Hood + Concrete Entry Ramp
      const fswCurtain = new THREE.Mesh(new THREE.BoxGeometry(4.5, 4.5, 0.14), matShutter);
      fswCurtain.position.set(mx, 2.25, zOuterC);
      const fswHood = new THREE.Mesh(new THREE.BoxGeometry(4.78, 0.34, 0.34), matTrim);
      fswHood.position.set(mx, 4.72, zOuterC);
      const fswRamp = new THREE.Mesh(new THREE.BoxGeometry(4.8, 0.16, 2.2), matRamp);
      fswRamp.position.set(mx, 0.02, zOuterC + 1.22);
      fswRamp.rotation.x = 0.045;
      groups.openings.add(fswCurtain, fswHood, fswRamp);

      // BSW 4.5x4.0m Rolling Shutter + Hood
      const bswCurtain = new THREE.Mesh(new THREE.BoxGeometry(4.5, 4.0, 0.14), matShutter);
      bswCurtain.position.set(mx, 2.0, zOuterA);
      const bswHood = new THREE.Mesh(new THREE.BoxGeometry(4.78, 0.34, 0.34), matTrim);
      bswHood.position.set(mx, 4.22, zOuterA);
      groups.openings.add(bswCurtain, bswHood);
    });

    // Revised 3.00m Brick Walls
    const bwA = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, brickWallH, 0.23), matBrick);
    bwA.position.set(0, brickWallH / 2, zOuterA + 0.115);
    const bwC = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, brickWallH, 0.23), matBrick);
    bwC.position.set(0, brickWallH / 2, zOuterC - 0.115);
    const bwL = new THREE.Mesh(new THREE.BoxGeometry(0.23, brickWallH, totalWidthOO), matBrick);
    bwL.position.set(xOuterL + 0.115, brickWallH / 2, 0);
    const bwR = new THREE.Mesh(new THREE.BoxGeometry(0.23, brickWallH, totalWidthOO), matBrick);
    bwR.position.set(xOuterR - 0.115, brickWallH / 2, 0);
    groups.brick.add(bwA, bwC, bwL, bwR);

    // Cladding & Roof Sheeting (FSW Canopy spans Grids 1 to 11 only; Bay 11-12 canopy removed)
    const cladA = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, 11.315 - brickWallH, 0.04), matClad);
    cladA.position.set(0, brickWallH + (11.315 - brickWallH) / 2, zOuterA);
    const cladC = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, 9.485 - brickWallH, 0.04), matClad);
    cladC.position.set(0, brickWallH + (9.485 - brickWallH) / 2, zOuterC);
    const mainRoof = new THREE.Mesh(new THREE.BoxGeometry(totalLenOO, 0.045, Math.hypot(totalWidthOO, 1.83)), matRoof);
    mainRoof.position.set(0, (11.315 + 9.485) / 2, 0);
    mainRoof.rotation.x = slopeAngle;

    const canopyRoof = new THREE.Mesh(new THREE.BoxGeometry(fswCanopyLen, 0.04, Math.hypot(canopyWidth, 0.61)), matRoof);
    canopyRoof.position.set(fswCanopyMidX, canopyY(zOuterC + canopyWidth / 2), zOuterC + canopyWidth / 2);
    canopyRoof.rotation.x = slopeAngle;
    const canopyFascia = new THREE.Mesh(new THREE.BoxGeometry(fswCanopyLen, 1.50, 0.04), matClad);
    canopyFascia.position.set(fswCanopyMidX, canopyY(zCanopyEdge) - 0.75, zCanopyEdge);
    groups.cladding.add(cladA, cladC, mainRoof, canopyRoof, canopyFascia);

    // 26 Wall Louvers (1.0m x 2.0m) + 22 Skylights + 11 Turbo Vents
    const vents = [];
    for (let b = 0; b < 11; b++) {
      const mx = (worldX[b] + worldX[b + 1]) / 2;
      const lvA = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.0, 0.12), matLouver);
      lvA.position.set(mx, 7.45, zOuterA);
      const lvC = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.0, 0.12), matLouver);
      lvC.position.set(mx, 7.45, zOuterC);
      groups.openings.add(lvA, lvC);

      [-4.25, 4.25].forEach(sz => {
        const sk = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.07, 3.2), matSkylight);
        sk.position.set(mx, roofY(sz) + 0.025, sz);
        sk.rotation.x = slopeAngle;
        groups.openings.add(sk);
      });
      const vent = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.45, 16), matPurlin);
      vent.position.set(mx, roofY(-6.8) + 0.25, -6.8);
      groups.openings.add(vent);
      vents.push(vent);
    }

    // Ground Grid Lines
    const lineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.6 });
    worldX.forEach(x => {
      const pts = [new THREE.Vector3(x, 0.03, -14), new THREE.Vector3(x, 0.03, 19)];
      groups.grid.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), lineMat));
    });
    [zGridA, zGridB, zGridC].forEach(z => {
      const pts = [new THREE.Vector3(-48, 0.03, z), new THREE.Vector3(48, 0.03, z)];
      groups.grid.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), lineMat));
    });

    // Separate Freestanding Company Signboard (MEGH ENGINEERING CONSULTANTS)
    {
      const signGroup = new THREE.Group();
      signGroup.position.set(-56.5, 0, 22.5);
      signGroup.rotation.y = Math.PI / 6;

      const sCanvas = document.createElement('canvas');
      sCanvas.width = 2048; sCanvas.height = 512;
      const sCtx = sCanvas.getContext('2d');
      sCtx.fillStyle = '#ffffff';
      sCtx.fillRect(0, 0, 2048, 512);
      sCtx.fillStyle = '#e31e24';
      [{x:105,y1:120,y2:390},{x:185,y1:155,y2:425},{x:265,y1:190,y2:460}].forEach((b,i) => {
        sCtx.beginPath();
        sCtx.moveTo(b.x, b.y1); sCtx.lineTo(b.x+115, b.y1-75); sCtx.lineTo(b.x+115, b.y1-22);
        sCtx.lineTo(b.x+42, b.y1+26); sCtx.lineTo(b.x+42, b.y2-(i===2?55:0));
        if(i===2){ sCtx.lineTo(b.x+115, b.y2-102); sCtx.lineTo(b.x+115, b.y2-48); }
        sCtx.lineTo(b.x, b.y2); sCtx.closePath(); sCtx.fill();
      });
      sCtx.fillStyle = '#1e2530';
      sCtx.textAlign = 'center'; sCtx.textBaseline = 'middle';
      sCtx.font = '800 132px sans-serif';
      sCtx.fillText('MEGH ENGINEERING', 1245, 195);
      sCtx.fillText('CONSULTANTS', 1245, 355);

      const signTex = new THREE.CanvasTexture(sCanvas);
      signTex.colorSpace = THREE.SRGBColorSpace;
      signTex.generateMipmaps = false;
      signTex.minFilter = THREE.LinearFilter;
      signTex.magFilter = THREE.LinearFilter;
      const logoImg = new Image();
      logoImg.crossOrigin = 'anonymous';
      logoImg.onload = () => {
        sCtx.fillStyle = '#ffffff'; sCtx.fillRect(0, 0, 2048, 512);
        sCtx.drawImage(logoImg, 56, 30, 1936, 452);
        signTex.needsUpdate = true;
      };
      logoImg.src = '/assets/aistudio/IMG_2863_8e2cdaec.jpeg';

      const matPost = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.32, metalness: 0.8 });
      const matFnd = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.82 });
      const matFace = new THREE.MeshBasicMaterial({ color: 0xf8fafc, map: signTex, toneMapped: false });

      [-4.6, 4.6].forEach(px => {
        const footing = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.26, 1.65), matFnd);
        footing.position.set(px, -0.13, 0);
        const ped = new THREE.Mesh(new THREE.BoxGeometry(1.12, 0.44, 1.12), matFnd);
        ped.position.set(px, 0.12, 0);
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.26, 5.2, 0.26), matPost);
        post.position.set(px, 0.48 + 5.2 / 2, 0);
        signGroup.add(footing, ped, post);
      });
      const boardCore = new THREE.Mesh(new THREE.BoxGeometry(14.2, 3.5, 0.28), matPost);
      boardCore.position.set(0, 3.6, 0.24);
      const boardFace = new THREE.Mesh(new THREE.PlaneGeometry(13.86, 3.16), matFace);
      boardFace.position.set(0, 3.6, 0.386);
      signGroup.add(boardCore, boardFace);
      scene.add(signGroup);
    }

    // Camera Presets
    const presets = {
      iso: { pos: [58, 30, 62], target: [0, 5, 2] },
      front: { pos: [0, 7, 74], target: [0, 5.5, 0] },
      back: { pos: [0, 7, -72], target: [0, 5.5, 0] },
      left: { pos: [-78, 8, 2], target: [0, 5.5, 2] },
      right: { pos: [78, 8, 2], target: [0, 5.5, 2] },
      roof: { pos: [0, 82, 3], target: [0, 0, 2] },
      inside: { pos: [-34, 3.4, 0], target: [18, 5.2, 0] },
    };

    document.querySelectorAll('#preset-buttons button').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#preset-buttons button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const p = presets[btn.dataset.preset];
        camera.position.set(...p.pos);
        controls.target.set(...p.target);
      });
    });

    document.getElementById('chk-cladding').addEventListener('change', e => groups.cladding.visible = e.target.checked);
    document.getElementById('chk-mezzanine').addEventListener('change', e => groups.mezzanine.visible = e.target.checked);
    document.getElementById('chk-brick').addEventListener('change', e => groups.brick.visible = e.target.checked);
    document.getElementById('chk-openings').addEventListener('change', e => groups.openings.visible = e.target.checked);
    document.getElementById('chk-grid').addEventListener('change', e => groups.grid.visible = e.target.checked);
    document.getElementById('chk-wireframe').addEventListener('change', e => {
      const wf = e.target.checked;
      [matClad, matRoof, matBrick, matSteel, matMezzSlab, matMezzSteel].forEach(m => m.wireframe = wf);
    });

    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    });

    function animate() {
      requestAnimationFrame(animate);
      controls.update();
      vents.forEach(v => v.rotation.y += 0.03);
      renderer.render(scene, camera);
    }
    animate();
  </script>
</body>
</html>`;
}
