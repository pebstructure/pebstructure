import * as THREE from 'three';
import type { InspectedMemberInfo } from './buildPebScene';

export const MEGH_LOGO_ASSET_PATH = '/assets/aistudio/IMG_2863_8e2cdaec.jpeg';

export interface FreestandingSignboardResult {
  group: THREE.Group;
  interactables: THREE.Object3D[];
  dispose: () => void;
}

/**
 * Draws a crisp, high-resolution fallback of the MEGH ENGINEERING CONSULTANTS logo
 * while the exact uploaded JPEG (/assets/aistudio/IMG_2863_8e2cdaec.jpeg) loads,
 * then overwrites the canvas with the exact pixel-for-pixel uploaded JPEG image.
 */
function createMeghSignboardTexture(
  maxAnisotropy: number,
  onTextureReady?: () => void,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  const renderFallback = () => {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle outer inset architectural border
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 6;
    ctx.strokeRect(16, 16, canvas.width - 32, canvas.height - 32);

    // Red isometric 3-chevron emblem on left matching uploaded logo proportions
    ctx.fillStyle = '#e31e24';
    const bars = [
      { x: 105, yTop: 120, yBot: 390 },
      { x: 185, yTop: 155, yBot: 425 },
      { x: 265, yTop: 190, yBot: 460 },
    ];
    bars.forEach((b, i) => {
      ctx.beginPath();
      ctx.moveTo(b.x, b.yTop);
      ctx.lineTo(b.x + 115, b.yTop - 75);
      ctx.lineTo(b.x + 115, b.yTop - 22);
      ctx.lineTo(b.x + 42, b.yTop + 26);
      ctx.lineTo(b.x + 42, b.yBot - (i === 2 ? 55 : 0));
      if (i === 2) {
        ctx.lineTo(b.x + 115, b.yBot - 102);
        ctx.lineTo(b.x + 115, b.yBot - 48);
      }
      ctx.lineTo(b.x, b.yBot);
      ctx.closePath();
      ctx.fill();
    });

    // Exact text: MEGH ENGINEERING CONSULTANTS
    ctx.fillStyle = '#1e2530';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '800 132px "Inter", "Segoe UI", Arial, sans-serif';
    ctx.fillText('MEGH ENGINEERING', 1245, 195);
    ctx.font = '800 132px "Inter", "Segoe UI", Arial, sans-serif';
    ctx.fillText('CONSULTANTS', 1245, 355);
  };

  renderFallback();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.generateMipmaps = false;
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;

  // Load the exact uploaded logo asset (/assets/aistudio/IMG_2863_8e2cdaec.jpeg, 1008x232)
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Preserve exact original 1008x232 aspect ratio centered on the white signboard face
    const padX = 56;
    const availW = canvas.width - padX * 2;
    const availH = canvas.height - 44;
    const imgAspect = img.width / img.height; // 1008 / 232 = 4.3448
    let drawW = availW;
    let drawH = drawW / imgAspect;
    if (drawH > availH) {
      drawH = availH;
      drawW = drawH * imgAspect;
    }
    const drawX = (canvas.width - drawW) / 2;
    const drawY = (canvas.height - drawH) / 2;

    ctx.drawImage(img, drawX, drawY, drawW, drawH);

    // Subtle crisp architectural border trim line
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 4;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);

    texture.needsUpdate = true;
    if (onTextureReady) onTextureReady();
  };
  img.src = MEGH_LOGO_ASSET_PATH;

  return texture;
}

/**
 * Builds a separate, freestanding outdoor company signboard for
 * MEGH ENGINEERING CONSULTANTS placed on the ground in front of the building
 * on the left side of the 3D view with a generous physical gap.
 *
 * Does NOT modify any part of the existing PEB building.
 */
export function buildCompanySignboard(
  maxAnisotropy = 4,
  onTextureReady?: () => void,
): FreestandingSignboardResult {
  const group = new THREE.Group();
  group.name = 'FreestandingCompanySignboard';

  // Position on the ground beyond the building's left-side boundary (xOuterLeft = -44.1375m)
  // in the open ground area on the left side of the 3D view:
  group.position.set(-56.5, 0, 22.5);
  // Oriented toward the isometric viewer so the logo and text read with maximum clarity
  group.rotation.y = Math.PI / 6;

  const interactables: THREE.Object3D[] = [];
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    materials.push(m);
    return m;
  };

  const signTexture = createMeghSignboardTexture(maxAnisotropy, onTextureReady);

  // Materials
  const concreteFoundationMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.82,
      metalness: 0.06,
    }),
  );

  const groutPadMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.72,
      metalness: 0.05,
    }),
  );

  const supportPostSteelMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.32,
      metalness: 0.8,
    }),
  );

  const frameBezelMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.28,
      metalness: 0.75,
    }),
  );

  const anchorBoltMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.28,
      metalness: 0.85,
    }),
  );

  const signFaceMat = trackMat(
    new THREE.MeshBasicMaterial({
      color: 0xf8fafc,
      map: signTexture,
      toneMapped: false,
    }),
  );

  const signBackingWhiteMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.3,
      metalness: 0.08,
    }),
  );

  const lightFixtureGlowMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xfffbeb,
      emissive: 0xfef3c7,
      emissiveIntensity: 0.9,
      roughness: 0.2,
    }),
  );

  // Dimensions of the freestanding signboard (in meters, 1u = 1m)
  const boardWidth = 14.2; // 14.20m wide outer frame
  const boardHeight = 3.50; // 3.50m tall outer frame (inner face matches 1008x232 logo aspect ratio)
  const boardDepth = 0.28;
  const clearanceBottomY = 1.85; // 1.85m clear height below signboard showing the 2 independent metal support posts
  const boardCenterY = clearanceBottomY + boardHeight / 2; // 3.60m
  const postSpacingHalf = 4.6; // Two independent posts at X = -4.6m and X = +4.6m
  const postHeight = clearanceBottomY + boardHeight - 0.15; // 5.20m total post height

  // 1. Two Independent Ground-Mounted Stepped Concrete Foundations & Anchor Base Plates
  const footingPadGeo = trackGeo(new THREE.BoxGeometry(1.65, 0.26, 1.65));
  const pedestalGeo = trackGeo(new THREE.BoxGeometry(1.12, 0.44, 1.12));
  const plinthChamferGeo = trackGeo(new THREE.BoxGeometry(0.88, 0.10, 0.88));
  const groutGeo = trackGeo(new THREE.BoxGeometry(0.64, 0.05, 0.64));
  const basePlateGeo = trackGeo(new THREE.BoxGeometry(0.56, 0.035, 0.56));
  const boltGeo = trackGeo(new THREE.CylinderGeometry(0.016, 0.016, 0.15, 8));
  const nutGeo = trackGeo(new THREE.CylinderGeometry(0.026, 0.026, 0.028, 6));
  const stiffenerGeo = trackGeo(new THREE.BoxGeometry(0.022, 0.26, 0.15));

  // 2. Two Independent Metal Support Posts + Concrete Pedestals + Anchor Bolts
  const postWidth = 0.26;
  const postGeo = trackGeo(new THREE.BoxGeometry(postWidth, postHeight, postWidth));
  const postCapGeo = trackGeo(new THREE.BoxGeometry(postWidth + 0.06, 0.04, postWidth + 0.06));

  [-postSpacingHalf, postSpacingHalf].forEach((px) => {
    // Independent Lower Footing Pad on Ground
    const footingPad = new THREE.Mesh(footingPadGeo, concreteFoundationMat);
    footingPad.position.set(px, -0.13, 0);
    footingPad.castShadow = true;
    footingPad.receiveShadow = true;

    // Independent Upper Concrete Foundation Pedestal
    const ped = new THREE.Mesh(pedestalGeo, concreteFoundationMat);
    ped.position.set(px, 0.12, 0);
    ped.castShadow = true;
    ped.receiveShadow = true;

    const chamfer = new THREE.Mesh(plinthChamferGeo, concreteFoundationMat);
    chamfer.position.set(px, 0.36, 0);
    chamfer.castShadow = true;
    chamfer.receiveShadow = true;

    const grout = new THREE.Mesh(groutGeo, groutPadMat);
    grout.position.set(px, 0.43, 0);

    // Steel Base Plate
    const bp = new THREE.Mesh(basePlateGeo, supportPostSteelMat);
    bp.position.set(px, 0.47, 0);
    bp.castShadow = true;

    // 4 Anchor Bolts per Post Base
    [-0.21, 0.21].forEach((bx) => {
      [-0.21, 0.21].forEach((bz) => {
        const bolt = new THREE.Mesh(boltGeo, anchorBoltMat);
        bolt.position.set(px + bx, 0.52, bz);
        const nut = new THREE.Mesh(nutGeo, anchorBoltMat);
        nut.position.set(px + bx, 0.50, bz);
        group.add(bolt, nut);
      });
    });

    // Gusset Stiffener Fins on Base Plate
    [-0.17, 0.17].forEach((gz) => {
      const fin = new THREE.Mesh(stiffenerGeo, supportPostSteelMat);
      fin.position.set(px, 0.60, gz);
      group.add(fin);
    });

    // Vertical Square Hollow Steel Support Post (HSS 260x260)
    const post = new THREE.Mesh(postGeo, supportPostSteelMat);
    post.position.set(px, 0.48 + postHeight / 2, 0);
    post.castShadow = true;
    post.receiveShadow = true;

    const postCap = new THREE.Mesh(postCapGeo, frameBezelMat);
    postCap.position.set(px, 0.48 + postHeight + 0.02, 0);

    group.add(footingPad, ped, chamfer, grout, bp, post, postCap);
  });

  // Horizontal Structural Steel Support Cross-Rails behind the Signboard
  const railGeo = trackGeo(new THREE.BoxGeometry(boardWidth - 0.6, 0.14, 0.14));
  [clearanceBottomY + 0.55, clearanceBottomY + boardHeight - 0.55].forEach((ry) => {
    const rail = new THREE.Mesh(railGeo, supportPostSteelMat);
    rail.position.set(0, ry, 0);
    rail.castShadow = true;
    group.add(rail);
  });

  // 3. Premium White Rectangular Signboard Cabinet & Clean Architectural Frame
  // Signboard positioned slightly in front of the two support posts (Z = +0.24m)
  const cabinetZ = 0.24;

  // Inner White Core Box
  const coreGeo = trackGeo(new THREE.BoxGeometry(boardWidth - 0.24, boardHeight - 0.24, boardDepth));
  const coreMesh = new THREE.Mesh(coreGeo, signBackingWhiteMat);
  coreMesh.position.set(0, boardCenterY, cabinetZ);
  coreMesh.castShadow = true;
  coreMesh.receiveShadow = true;
  group.add(coreMesh);

  // Front Display Face (with exact uploaded MEGH ENGINEERING CONSULTANTS logo)
  const faceW = boardWidth - 0.34;
  const faceH = boardHeight - 0.34;
  const faceGeo = trackGeo(new THREE.PlaneGeometry(faceW, faceH));

  const frontFaceMesh = new THREE.Mesh(faceGeo, signFaceMat);
  frontFaceMesh.position.set(0, boardCenterY, cabinetZ + boardDepth / 2 + 0.006);
  frontFaceMesh.receiveShadow = true;

  // Back Display Face (so the logo is also readable when orbiting behind the signboard)
  const backFaceMesh = new THREE.Mesh(faceGeo, signFaceMat);
  backFaceMesh.position.set(0, boardCenterY, cabinetZ - boardDepth / 2 - 0.006);
  backFaceMesh.rotation.y = Math.PI;
  backFaceMesh.receiveShadow = true;

  group.add(frontFaceMesh, backFaceMesh);

  // Perimeter Metallic Frame Bezel (Top, Bottom, Left, Right)
  const frameThickness = 0.18;
  const frameDepth = boardDepth + 0.06;
  const topBotFrameGeo = trackGeo(new THREE.BoxGeometry(boardWidth, frameThickness, frameDepth));
  const sideFrameGeo = trackGeo(
    new THREE.BoxGeometry(frameThickness, boardHeight - frameThickness * 2, frameDepth),
  );

  const topFrame = new THREE.Mesh(topBotFrameGeo, frameBezelMat);
  topFrame.position.set(0, boardCenterY + (boardHeight - frameThickness) / 2, cabinetZ);
  topFrame.castShadow = true;

  const botFrame = new THREE.Mesh(topBotFrameGeo, frameBezelMat);
  botFrame.position.set(0, boardCenterY - (boardHeight - frameThickness) / 2, cabinetZ);
  botFrame.castShadow = true;

  const leftFrame = new THREE.Mesh(sideFrameGeo, frameBezelMat);
  leftFrame.position.set(-(boardWidth - frameThickness) / 2, boardCenterY, cabinetZ);
  leftFrame.castShadow = true;

  const rightFrame = new THREE.Mesh(sideFrameGeo, frameBezelMat);
  rightFrame.position.set((boardWidth - frameThickness) / 2, boardCenterY, cabinetZ);
  rightFrame.castShadow = true;

  group.add(topFrame, botFrame, leftFrame, rightFrame);

  // 4. Overhead Architectural Signboard Floodlight Hoods (4 Nos.)
  const armGeo = trackGeo(new THREE.CylinderGeometry(0.02, 0.02, 0.65, 8));
  armGeo.rotateX(Math.PI / 2);
  const hoodGeo = trackGeo(new THREE.BoxGeometry(0.55, 0.08, 0.24));
  const lensGeo = trackGeo(new THREE.PlaneGeometry(0.48, 0.18));
  lensGeo.rotateX(Math.PI / 2);

  [-4.5, -1.5, 1.5, 4.5].forEach((lx) => {
    const topY = boardCenterY + boardHeight / 2 + 0.06;
    const arm = new THREE.Mesh(armGeo, supportPostSteelMat);
    arm.position.set(lx, topY, cabinetZ + 0.30);

    const hood = new THREE.Mesh(hoodGeo, frameBezelMat);
    hood.position.set(lx, topY + 0.02, cabinetZ + 0.60);
    hood.rotation.x = 0.25;
    hood.castShadow = true;

    const lens = new THREE.Mesh(lensGeo, lightFixtureGlowMat);
    lens.position.set(lx, topY - 0.025, cabinetZ + 0.59);
    lens.rotation.x = 0.25;

    group.add(arm, hood, lens);
  });

  // Attach inspection metadata to signboard meshes
  const signboardMeta: InspectedMemberInfo = {
    name: 'Freestanding Company Signboard — MEGH ENGINEERING CONSULTANTS',
    category: 'Outdoor Structural Identity Signboard (Independent Ground Mount)',
    spec: '13,600 × 3,350 mm White Display Board | 2 Nos. HSS 240×240 Steel Posts | 2 Nos. RCC Footings with M-24 Anchor Bolts',
    gridLocation: 'Freestanding Foreground (Left of FSW Approach, 15.7m Clear of Canopy)',
    drawingRef: 'MEGH ENGINEERING CONSULTANTS — Project J-100A246',
  };

  group.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      child.userData.memberInfo = signboardMeta;
      interactables.push(child);
    }
  });

  function dispose() {
    signTexture.dispose();
    geometries.forEach((g) => g.dispose());
    materials.forEach((m) => m.dispose());
  }

  return {
    group,
    interactables,
    dispose,
  };
}
