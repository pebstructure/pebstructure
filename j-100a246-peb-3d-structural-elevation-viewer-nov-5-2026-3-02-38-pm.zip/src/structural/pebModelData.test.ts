import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BUILDING_DIMENSIONS_MM,
  getLongitudinalGrids,
  getTransverseGrids,
  getMainRoofElevationAtZ,
  getTotalAnchorBoltCount,
  BASE_PLATE_DETAILS,
} from './pebModelData';

test('Longitudinal grid spacings sum to exact 87,285 mm C/C and 88,275 mm O/O of steel line', () => {
  const grids = getLongitudinalGrids();
  assert.equal(grids.length, 12);
  assert.equal(grids[0].xCoordMm, 0);
  assert.equal(grids[1].baySpacingFromPrevMm, 8285);
  assert.equal(grids[7].baySpacingFromPrevMm, 7000); // Bay 7 (Grid 7 to 8) is 7000 mm
  assert.equal(grids[11].xCoordMm, 87285);

  const outToOut =
    grids[11].xCoordMm +
    BUILDING_DIMENSIONS_MM.endwallOverhangLeftMm +
    BUILDING_DIMENSIONS_MM.endwallOverhangRightMm;
  assert.equal(outToOut, 88275);
});

test('Transverse grid spacings sum to exact 17,000 mm C/C and 18,290 mm O/O of steel line', () => {
  const grids = getTransverseGrids();
  assert.equal(grids.length, 3);
  assert.equal(grids[0].gridLetter, 'A');
  assert.equal(grids[1].gridLetter, 'B');
  assert.equal(grids[2].gridLetter, 'C');
  assert.equal(grids[2].zCoordMm, 17000);

  const outToOutWidth =
    grids[2].zCoordMm +
    BUILDING_DIMENSIONS_MM.sidewallOffsetAMm +
    BUILDING_DIMENSIONS_MM.sidewallOffsetCMm;
  assert.equal(outToOutWidth, 18290);
});

test('Mono-slope 1:10 roof elevations match High Eave (±11,315 mm) and Low Eave (±9,485 mm)', () => {
  const highEdgeZ = -8.5 - 0.645; // -9.145 m
  const lowEdgeZ = 8.5 + 0.645;   // +9.145 m
  assert.ok(Math.abs(getMainRoofElevationAtZ(highEdgeZ) - 11.315) < 1e-6);
  assert.ok(Math.abs(getMainRoofElevationAtZ(lowEdgeZ) - 9.485) < 1e-6);

  // Drop across 18,290 mm is 1,830 mm (~1:10 slope)
  const dropMm = BUILDING_DIMENSIONS_MM.highEaveHeightMm - BUILDING_DIMENSIONS_MM.lowEaveHeightMm;
  assert.equal(dropMm, 1830);
});

test('Anchor bolt schedule sums to exact 288 main M-24 anchor bolts on AB-01 plus 12 D5 staircase bolts across 8 base plate types', () => {
  const totalBolts = getTotalAnchorBoltCount();
  assert.equal(totalBolts, 288);
  assert.equal(BASE_PLATE_DETAILS.length, 8);
});

test('Mezzanine floor in Grids 1 to 5 spans 32,285 mm × 17,000 mm at EL +5,374 mm with 3-stage staircase (3 × 1,791 mm)', () => {
  const grids = getLongitudinalGrids();
  const mezzLengthMm = grids[4].xCoordMm - grids[0].xCoordMm;
  assert.equal(mezzLengthMm, 32285); // 8285 + 3*8000 = 32,285 mm
  assert.equal(BUILDING_DIMENSIONS_MM.mezzanineTopOfSlabMm, 5374);
  assert.equal(BUILDING_DIMENSIONS_MM.mezzanineClearHeightUnderBeamMm, 4500);
  assert.equal(BUILDING_DIMENSIONS_MM.staircaseFlightRiseMm * 3, 5373); // 3 * 1791 = 5373 ~ 5374 mm
  assert.equal(BUILDING_DIMENSIONS_MM.brickWallHeightMm, 3000);
  assert.equal(BUILDING_DIMENSIONS_MM.portalBeamHeightMm, 5500);
});

test('Freestanding MEGH ENGINEERING CONSULTANTS signboard is positioned beyond the building left-side boundary', () => {
  const grids = getLongitudinalGrids();
  const xGrid1 = grids[0].xWorldM; // -43.6425m
  const xOuterLeft = xGrid1 - BUILDING_DIMENSIONS_MM.endwallOverhangLeftMm / 1000; // -44.1375m

  // Signboard placed at X = -56.5m, Z = +22.5m (half-width projection in X is 7.1 * cos(30deg) = 6.15m)
  const signboardCenterX = -56.5;
  const signboardMaxX = signboardCenterX + 6.15; // -50.35m

  assert.ok(
    signboardMaxX < xOuterLeft - 5.0,
    'Signboard must be completely beyond the building left-side boundary with >5m clear gap',
  );
});

