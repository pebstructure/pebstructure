import * as THREE from 'three';
import {
  BUILDING_DIMENSIONS_MM,
  getLongitudinalGrids,
  getTransverseGrids,
  getMainRoofElevationAtZ,
  getCanopyRoofElevationAtZ,
} from './pebModelData';

export interface PebLayerVisibility {
  cladding: boolean;
  roofSheeting: boolean;
  brickWall: boolean;
  mezzanineStructure: boolean;
  openingsAndAccessories: boolean;
  primarySteel: boolean;
  secondarySteel: boolean;
  bracingAndPortals: boolean;
  gridAndDimensions: boolean;
  wireframeMode: boolean;
}

export interface InspectedMemberInfo {
  name: string;
  category: string;
  spec: string;
  gridLocation: string;
  drawingRef: string;
}

export interface BuiltPebScene {
  rootGroup: THREE.Group;
  groups: {
    cladding: THREE.Group;
    roofSheeting: THREE.Group;
    brickWall: THREE.Group;
    mezzanine: THREE.Group;
    openingsAndAccessories: THREE.Group;
    primarySteel: THREE.Group;
    secondarySteel: THREE.Group;
    bracingAndPortals: THREE.Group;
    gridAndDimensions: THREE.Group;
  };
  turboVentDomes: THREE.Object3D[];
  interactables: THREE.Object3D[];
  applyVisibility: (vis: PebLayerVisibility) => void;
  dispose: () => void;
}

/**
 * Create a high-contrast procedural text sprite for CAD grid bubbles and millimeter dimensions
 */
function createLabelSprite(
  text: string,
  options: {
    bgColor?: string;
    borderColor?: string;
    textColor?: string;
    isCircleBubble?: boolean;
    worldHeight?: number;
    fontSize?: number;
  } = {},
): THREE.Sprite {
  const {
    bgColor = 'rgba(11, 17, 30, 0.92)',
    borderColor = '#38bdf8',
    textColor = '#f8fafc',
    isCircleBubble = false,
    worldHeight = 1.15,
    fontSize = 44,
  } = options;

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;

  if (isCircleBubble) {
    canvas.width = 128;
    canvas.height = 128;
    ctx.clearRect(0, 0, 128, 128);

    ctx.beginPath();
    ctx.arc(64, 64, 54, 0, Math.PI * 2);
    ctx.fillStyle = bgColor;
    ctx.fill();
    ctx.lineWidth = 6;
    ctx.strokeStyle = borderColor;
    ctx.stroke();

    ctx.font = `700 ${fontSize}px "JetBrains Mono", monospace`;
    ctx.fillStyle = textColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, 64, 66);
  } else {
    ctx.font = `600 ${fontSize}px "JetBrains Mono", monospace`;
    const metrics = ctx.measureText(text);
    const padX = 28;
    const padY = 18;
    const w = Math.max(120, Math.ceil(metrics.width + padX * 2));
    const h = Math.ceil(fontSize + padY * 2);
    canvas.width = w;
    canvas.height = h;

    ctx.fillStyle = bgColor;
    ctx.strokeStyle = borderColor;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.roundRect(4, 4, w - 8, h - 8, 10);
    ctx.fill();
    ctx.stroke();

    ctx.font = `600 ${fontSize}px "JetBrains Mono", monospace`;
    ctx.fillStyle = textColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, w / 2, h / 2 + 1);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;

  const material = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: true,
    depthWrite: false,
  });
  const sprite = new THREE.Sprite(material);
  const aspect = canvas.width / canvas.height;
  sprite.scale.set(worldHeight * aspect, worldHeight, 1);
  return sprite;
}

/**
 * Generate procedural textures for Brick Masonry, Ribbed PPGI Cladding, Bare Galvalume Roof, and Rolling Shutters
 */
function createProceduralTextures(maxAnisotropy: number) {
  // 1. Running-bond clay brick masonry texture
  const brickCanvas = document.createElement('canvas');
  brickCanvas.width = 512;
  brickCanvas.height = 512;
  const bCtx = brickCanvas.getContext('2d')!;
  bCtx.fillStyle = '#c2beb6';
  bCtx.fillRect(0, 0, 512, 512);

  const brickRows = 16;
  const brickCols = 8;
  const rowH = 512 / brickRows;
  const colW = 512 / brickCols;
  const mortar = 3;

  for (let r = 0; r < brickRows; r++) {
    const offset = (r % 2) * (colW / 2);
    for (let c = -1; c <= brickCols; c++) {
      const x = c * colW + offset;
      const y = r * rowH;
      const shade = ((r * 17 + c * 31) % 24) - 12;
      const red = Math.min(220, Math.max(145, 178 + shade));
      const green = Math.min(110, Math.max(62, 82 + Math.floor(shade * 0.5)));
      const blue = Math.min(90, Math.max(48, 64 + Math.floor(shade * 0.4)));
      bCtx.fillStyle = `rgb(${red}, ${green}, ${blue})`;
      bCtx.fillRect(x + mortar, y + mortar, colW - mortar * 2, rowH - mortar * 2);
    }
  }
  const brickTex = new THREE.CanvasTexture(brickCanvas);
  brickTex.colorSpace = THREE.SRGBColorSpace;
  brickTex.wrapS = THREE.RepeatWrapping;
  brickTex.wrapT = THREE.RepeatWrapping;
  brickTex.anisotropy = maxAnisotropy;

  // 2. Ribbed PPGI 1000mm Wall Cladding Texture
  const claddingCanvas = document.createElement('canvas');
  claddingCanvas.width = 256;
  claddingCanvas.height = 256;
  const cCtx = claddingCanvas.getContext('2d')!;
  for (let x = 0; x < 256; x++) {
    const phase = (x / 256) * 5;
    const frac = phase - Math.floor(phase);
    let rib = 0;
    if (frac < 0.22) rib = 1;
    else if (frac < 0.28) rib = 1 - (frac - 0.22) / 0.06;
    else if (frac > 0.94) rib = (frac - 0.94) / 0.06;
    const v = Math.round(218 + rib * 28);
    cCtx.fillStyle = `rgb(${v - 4}, ${v}, ${v + 6})`;
    cCtx.fillRect(x, 0, 1, 256);
  }
  const claddingTex = new THREE.CanvasTexture(claddingCanvas);
  claddingTex.colorSpace = THREE.SRGBColorSpace;
  claddingTex.wrapS = THREE.RepeatWrapping;
  claddingTex.wrapT = THREE.RepeatWrapping;
  claddingTex.anisotropy = maxAnisotropy;

  // 3. Bare Galvalume Roof Sheet Texture (BG 1000mm width, 0.47mm thk)
  const roofCanvas = document.createElement('canvas');
  roofCanvas.width = 256;
  roofCanvas.height = 256;
  const rCtx = roofCanvas.getContext('2d')!;
  for (let y = 0; y < 256; y++) {
    const phase = (y / 256) * 5;
    const frac = phase - Math.floor(phase);
    const isCrest = frac < 0.18;
    const val = isCrest ? 238 : 206;
    rCtx.fillStyle = `rgb(${val}, ${val + 2}, ${val + 5})`;
    rCtx.fillRect(0, y, 256, 1);
  }
  const roofTex = new THREE.CanvasTexture(roofCanvas);
  roofTex.colorSpace = THREE.SRGBColorSpace;
  roofTex.wrapS = THREE.RepeatWrapping;
  roofTex.wrapT = THREE.RepeatWrapping;
  roofTex.anisotropy = maxAnisotropy;

  // 4. Corrugated Rolling Shutter Texture
  const shutterCanvas = document.createElement('canvas');
  shutterCanvas.width = 128;
  shutterCanvas.height = 256;
  const sCtx = shutterCanvas.getContext('2d')!;
  for (let y = 0; y < 256; y++) {
    const slat = Math.sin((y / 256) * Math.PI * 36);
    const v = Math.round(135 + slat * 32);
    sCtx.fillStyle = `rgb(${v}, ${v + 4}, ${v + 10})`;
    sCtx.fillRect(0, y, 128, 1);
  }
  const shutterTex = new THREE.CanvasTexture(shutterCanvas);
  shutterTex.colorSpace = THREE.SRGBColorSpace;
  shutterTex.wrapS = THREE.RepeatWrapping;
  shutterTex.wrapT = THREE.RepeatWrapping;
  shutterTex.anisotropy = maxAnisotropy;

  return { brickTex, claddingTex, roofTex, shutterTex };
}

/**
 * Helper to build a realistic I-Beam (Web + 2 Flanges) between two 3D points
 */
function createIBeamMember(
  start: THREE.Vector3,
  end: THREE.Vector3,
  webDepthM: number,
  flangeWidthM: number,
  flangeThickM: number,
  webThickM: number,
  material: THREE.Material,
  orientation: 'transverse' | 'longitudinal' | 'verticalColumn',
  meta?: InspectedMemberInfo,
  interactables?: THREE.Object3D[],
): THREE.Group {
  const group = new THREE.Group();
  const dir = new THREE.Vector3().subVectors(end, start);
  const length = dir.length();
  const mid = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);

  group.position.copy(mid);

  if (orientation === 'verticalColumn') {
    const webGeo = new THREE.BoxGeometry(webThickM, length, webDepthM - flangeThickM * 2);
    const flangeGeo = new THREE.BoxGeometry(flangeWidthM, length, flangeThickM);

    const webMesh = new THREE.Mesh(webGeo, material);
    const outerFlange = new THREE.Mesh(flangeGeo, material);
    outerFlange.position.z = (webDepthM - flangeThickM) / 2;
    const innerFlange = new THREE.Mesh(flangeGeo, material);
    innerFlange.position.z = -(webDepthM - flangeThickM) / 2;

    webMesh.castShadow = true;
    outerFlange.castShadow = true;
    innerFlange.castShadow = true;
    group.add(webMesh, outerFlange, innerFlange);
  } else if (orientation === 'transverse') {
    const angleX = Math.atan2(dir.y, dir.z);
    group.rotation.x = -angleX;

    const webGeo = new THREE.BoxGeometry(webThickM, webDepthM - flangeThickM * 2, length);
    const flangeGeo = new THREE.BoxGeometry(flangeWidthM, flangeThickM, length);

    const webMesh = new THREE.Mesh(webGeo, material);
    const topFlange = new THREE.Mesh(flangeGeo, material);
    topFlange.position.y = (webDepthM - flangeThickM) / 2;
    const botFlange = new THREE.Mesh(flangeGeo, material);
    botFlange.position.y = -(webDepthM - flangeThickM) / 2;

    webMesh.castShadow = true;
    topFlange.castShadow = true;
    botFlange.castShadow = true;
    group.add(webMesh, topFlange, botFlange);
  } else {
    const webGeo = new THREE.BoxGeometry(length, webDepthM - flangeThickM * 2, webThickM);
    const flangeGeo = new THREE.BoxGeometry(length, flangeThickM, flangeWidthM);

    const webMesh = new THREE.Mesh(webGeo, material);
    const topFlange = new THREE.Mesh(flangeGeo, material);
    topFlange.position.y = (webDepthM - flangeThickM) / 2;
    const botFlange = new THREE.Mesh(flangeGeo, material);
    botFlange.position.y = -(webDepthM - flangeThickM) / 2;

    group.add(webMesh, topFlange, botFlange);
  }

  if (meta) {
    group.userData.memberInfo = meta;
    group.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.userData.memberInfo = meta;
        if (interactables) interactables.push(child);
      }
    });
  }

  return group;
}

/**
 * Helper to create a cylinder rod or tube between two 3D points
 */
function createRodBetweenPoints(
  p1: THREE.Vector3,
  p2: THREE.Vector3,
  radiusM: number,
  material: THREE.Material,
  radialSegments = 8,
): THREE.Mesh {
  const diff = new THREE.Vector3().subVectors(p2, p1);
  const len = diff.length();
  const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
  const geo = new THREE.CylinderGeometry(radiusM, radiusM, len, radialSegments);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.copy(mid);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), diff.clone().normalize());
  return mesh;
}

/**
 * Helper to build a segmented longitudinal wall (along X at a fixed Z) with rectangular cutouts
 * so that framed openings (F.O.) and louvers have zero Z-fighting with brick or cladding.
 */
function buildSegmentedWallAlongX(
  xMin: number,
  xMax: number,
  yMin: number,
  yMax: number,
  zPos: number,
  thickness: number,
  openings: Array<{ x1: number; x2: number; y1: number; y2: number }>,
  material: THREE.Material,
  meta: InspectedMemberInfo,
  targetGroup: THREE.Group,
  interactables: THREE.Object3D[],
) {
  // Collect all unique X breakpoints within [xMin, xMax]
  const xPoints = new Set<number>([xMin, xMax]);
  openings.forEach((op) => {
    const ox1 = Math.max(xMin, Math.min(xMax, op.x1));
    const ox2 = Math.max(xMin, Math.min(xMax, op.x2));
    xPoints.add(ox1);
    xPoints.add(ox2);
  });
  const sortedX = Array.from(xPoints).sort((a, b) => a - b);

  for (let i = 0; i < sortedX.length - 1; i++) {
    const sx1 = sortedX[i];
    const sx2 = sortedX[i + 1];
    const segW = sx2 - sx1;
    if (segW < 0.01) continue;
    const midX = (sx1 + sx2) / 2;

    // Find openings overlapping this X strip and [yMin, yMax]
    const activeOps = openings
      .filter((op) => op.x1 < sx2 - 0.005 && op.x2 > sx1 + 0.005 && op.y1 < yMax && op.y2 > yMin)
      .map((op) => ({
        y1: Math.max(yMin, op.y1),
        y2: Math.min(yMax, op.y2),
      }))
      .sort((a, b) => a.y1 - b.y1);

    let curY = yMin;
    activeOps.forEach((op) => {
      if (op.y1 - curY > 0.01) {
        const h = op.y1 - curY;
        const m = new THREE.Mesh(new THREE.BoxGeometry(segW, h, thickness), material);
        m.position.set(midX, curY + h / 2, zPos);
        m.castShadow = true;
        m.receiveShadow = true;
        m.userData.memberInfo = meta;
        interactables.push(m);
        targetGroup.add(m);
      }
      curY = Math.max(curY, op.y2);
    });

    if (yMax - curY > 0.01) {
      const h = yMax - curY;
      const m = new THREE.Mesh(new THREE.BoxGeometry(segW, h, thickness), material);
      m.position.set(midX, curY + h / 2, zPos);
      m.castShadow = true;
      m.receiveShadow = true;
      m.userData.memberInfo = meta;
      interactables.push(m);
      targetGroup.add(m);
    }
  }
}

/**
 * Helper to build a segmented endwall (along Z at a fixed X) with rectangular cutouts
 */
function buildSegmentedEndwallAlongZ(
  zMin: number,
  zMax: number,
  yMin: number,
  yMaxAtZ: (z: number) => number,
  xPos: number,
  thickness: number,
  openings: Array<{ z1: number; z2: number; y1: number; y2: number }>,
  material: THREE.Material,
  meta: InspectedMemberInfo,
  targetGroup: THREE.Group,
  interactables: THREE.Object3D[],
) {
  const zPoints = new Set<number>([zMin, zMax]);
  openings.forEach((op) => {
    zPoints.add(Math.max(zMin, Math.min(zMax, op.z1)));
    zPoints.add(Math.max(zMin, Math.min(zMax, op.z2)));
  });
  // Also subdivide into 12 strips so sloped top edge is smooth
  for (let s = 1; s < 12; s++) {
    zPoints.add(zMin + ((zMax - zMin) * s) / 12);
  }
  const sortedZ = Array.from(zPoints).sort((a, b) => a - b);

  for (let i = 0; i < sortedZ.length - 1; i++) {
    const sz1 = sortedZ[i];
    const sz2 = sortedZ[i + 1];
    const segD = sz2 - sz1;
    if (segD < 0.01) continue;
    const midZ = (sz1 + sz2) / 2;
    const topY = yMaxAtZ(midZ);

    const activeOps = openings
      .filter((op) => op.z1 < sz2 - 0.005 && op.z2 > sz1 + 0.005 && op.y1 < topY && op.y2 > yMin)
      .map((op) => ({
        y1: Math.max(yMin, op.y1),
        y2: Math.min(topY, op.y2),
      }))
      .sort((a, b) => a.y1 - b.y1);

    let curY = yMin;
    activeOps.forEach((op) => {
      if (op.y1 - curY > 0.01) {
        const h = op.y1 - curY;
        const m = new THREE.Mesh(new THREE.BoxGeometry(thickness, h, segD), material);
        m.position.set(xPos, curY + h / 2, midZ);
        m.castShadow = true;
        m.receiveShadow = true;
        m.userData.memberInfo = meta;
        interactables.push(m);
        targetGroup.add(m);
      }
      curY = Math.max(curY, op.y2);
    });

    if (topY - curY > 0.01) {
      const h = topY - curY;
      const m = new THREE.Mesh(new THREE.BoxGeometry(thickness, h, segD), material);
      m.position.set(xPos, curY + h / 2, midZ);
      m.castShadow = true;
      m.receiveShadow = true;
      m.userData.memberInfo = meta;
      interactables.push(m);
      targetGroup.add(m);
    }
  }
}

/**
 * Build the complete 1:1 scale Project J-100A246 3D PEB Model (Revised 9-Sheet Set: AB-01 & GA-01 to GA-08)
 */
export function buildPebScene(maxAnisotropy = 4): BuiltPebScene {
  const rootGroup = new THREE.Group();

  const groups = {
    cladding: new THREE.Group(),
    roofSheeting: new THREE.Group(),
    brickWall: new THREE.Group(),
    mezzanine: new THREE.Group(),
    openingsAndAccessories: new THREE.Group(),
    primarySteel: new THREE.Group(),
    secondarySteel: new THREE.Group(),
    bracingAndPortals: new THREE.Group(),
    gridAndDimensions: new THREE.Group(),
  };

  Object.values(groups).forEach((g) => rootGroup.add(g));

  const turboVentDomes: THREE.Object3D[] = [];
  const interactables: THREE.Object3D[] = [];

  const textures = createProceduralTextures(maxAnisotropy);

  // Calibrated PBR Materials
  const materials = {
    concreteSlab: new THREE.MeshStandardMaterial({
      color: 0x64748b,
      roughness: 0.88,
      metalness: 0.05,
      polygonOffset: true,
      polygonOffsetFactor: 1,
      polygonOffsetUnits: 1,
    }),
    mezzanineConcreteSlab: new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.72,
      metalness: 0.08,
    }),
    mezzanineDeckSheet: new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.35,
      metalness: 0.78,
      side: THREE.DoubleSide,
    }),
    mezzanineBeamSteel: new THREE.MeshStandardMaterial({
      color: 0x2563eb, // Distinct structural cobalt blue for Mezzanine Main Beams & Columns
      roughness: 0.36,
      metalness: 0.7,
    }),
    mezzanineJoistSteel: new THREE.MeshStandardMaterial({
      color: 0x38bdf8, // Distinct structural sky-cyan for MJ-1 Mezzanine Joists (450x5, 130x6)
      roughness: 0.36,
      metalness: 0.68,
    }),
    staircaseSteel: new THREE.MeshStandardMaterial({
      color: 0x0f172a, // Dark anthracite steel for ISMC 250 Staircase Stringers & Treads
      roughness: 0.4,
      metalness: 0.75,
    }),
    handrailYellow: new THREE.MeshStandardMaterial({
      color: 0xfacc15, // High-visibility safety yellow for 32 NB Tubular Handrails & 100x6 Toe Plate
      roughness: 0.32,
      metalness: 0.68,
    }),
    pedestalConcrete: new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.78,
      metalness: 0.08,
    }),
    groutPad: new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.7,
      metalness: 0.05,
    }),
    basePlateSteel: new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.42,
      metalness: 0.78,
    }),
    anchorBoltSteel: new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.3,
      metalness: 0.85,
    }),
    primarySteel: new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      roughness: 0.38,
      metalness: 0.68,
    }),
    portalSteel: new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.36,
      metalness: 0.7,
    }),
    splicePlate: new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.35,
      metalness: 0.75,
    }),
    purlinGalv: new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.34,
      metalness: 0.78,
    }),
    bracingRod: new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: 0.3,
      metalness: 0.82,
    }),
    strutTube: new THREE.MeshStandardMaterial({
      color: 0xef4444,
      roughness: 0.4,
      metalness: 0.65,
    }),
    brickMasonry: new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: textures.brickTex,
      roughness: 0.86,
      metalness: 0.04,
    }),
    wallCladdingPpgi: new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      map: textures.claddingTex,
      roughness: 0.42,
      metalness: 0.45,
      side: THREE.DoubleSide,
    }),
    roofGalvalume: new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: textures.roofTex,
      roughness: 0.28,
      metalness: 0.72,
      side: THREE.DoubleSide,
    }),
    trimRoyalBlue: new THREE.MeshStandardMaterial({
      color: 0x1e40af,
      roughness: 0.35,
      metalness: 0.6,
      side: THREE.DoubleSide,
    }),
    gutterGalv: new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.3,
      metalness: 0.75,
    }),
    skylightFrp: new THREE.MeshStandardMaterial({
      color: 0x7dd3fc,
      emissive: 0x0284c7,
      emissiveIntensity: 0.22,
      roughness: 0.18,
      metalness: 0.1,
      transparent: true,
      opacity: 0.62,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
    turboVentChrome: new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.2,
      metalness: 0.88,
    }),
    rollingShutter: new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: textures.shutterTex,
      roughness: 0.45,
      metalness: 0.65,
    }),
    louverSlats: new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.38,
      metalness: 0.7,
    }),
    cageLadderYellow: new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      roughness: 0.35,
      metalness: 0.7,
    }),
  };

  const gridsX = getLongitudinalGrids();
  const gridsZ = getTransverseGrids();

  const xGrid1 = gridsX[0].xWorldM;   // -43.6425 m
  const xGrid5 = gridsX[4].xWorldM;   // -11.3575 m (End of Phase-1 Mezzanine Floor)
  const xGrid11 = gridsX[10].xWorldM; // +35.6425 m (End of FSW Canopy — Bay 11-12 has NO canopy)
  const xGrid12 = gridsX[11].xWorldM; // +43.6425 m
  const xOuterLeft = xGrid1 - 0.495;  // -44.1375 m (LEW O/O of steel line)
  const xOuterRight = xGrid12 + 0.495;// +44.1375 m (REW O/O of steel line)
  const totalLengthOO = xOuterRight - xOuterLeft; // 88.275 m

  // FSW Canopy spans from Left Outer Line (Grid 1) to Grid 11 only (Bay 11-12 canopy removed)
  const fswCanopyStartX = xOuterLeft;
  const fswCanopyEndX = xGrid11;
  const fswCanopyLength = fswCanopyEndX - fswCanopyStartX; // 79.780 m
  const fswCanopyCenterX = (fswCanopyStartX + fswCanopyEndX) / 2;

  const zGridA = gridsZ[0].zWorldM;   // -8.500 m
  const zGridB = gridsZ[1].zWorldM;   //  0.000 m (Centerline)
  const zGridC = gridsZ[2].zWorldM;   // +8.500 m
  const zOuterA = zGridA - 0.645;     // -9.145 m (BSW O/O of steel line)
  const zOuterC = zGridC + 0.645;     // +9.145 m (FSW O/O of steel line)
  const totalWidthOO = zOuterC - zOuterA; // 18.290 m
  const canopyWidthM = 6.100;         // 6,100 mm canopy width
  const zCanopyEdge = zOuterC + canopyWidthM; // +15.245 m
  const endwallCanopyWidthM = 3.000;  // 3,000 mm endwall canopies at GL-1 & GL-12 (between Grid A & B)

  const slopeAngle = Math.atan(0.1);

  // ============================================================================
  // 1. CONCRETE FLOOR SLAB, APRONS & ANCHOR BOLT FOUNDATIONS (AB-01)
  // ============================================================================
  const mainSlabGeo = new THREE.BoxGeometry(totalLengthOO, 0.25, totalWidthOO);
  const mainSlabMesh = new THREE.Mesh(mainSlabGeo, materials.concreteSlab);
  mainSlabMesh.position.set(0, -0.125, 0);
  mainSlabMesh.receiveShadow = true;
  groups.primarySteel.add(mainSlabMesh);

  // Canopy Concrete Apron under 6.1m Sidewall Canopy (Grids 1 to 11 only; Bay 11-12 removed)
  const apronGeo = new THREE.BoxGeometry(fswCanopyLength, 0.20, canopyWidthM + 0.4);
  const apronMesh = new THREE.Mesh(apronGeo, materials.concreteSlab);
  apronMesh.position.set(fswCanopyCenterX, -0.10, zOuterC + canopyWidthM / 2);
  apronMesh.receiveShadow = true;
  groups.primarySteel.add(apronMesh);

  // Concrete Aprons under the two 3.0m Endwall Canopies (LEW GL-1 & REW GL-12 between Grid A and Grid B)
  const endApronGeo = new THREE.BoxGeometry(endwallCanopyWidthM + 0.4, 0.20, 8.5 + 0.645);
  const lewApron = new THREE.Mesh(endApronGeo, materials.concreteSlab);
  lewApron.position.set(xOuterLeft - endwallCanopyWidthM / 2, -0.10, (zOuterA + zGridB) / 2);
  const rewApron = new THREE.Mesh(endApronGeo, materials.concreteSlab);
  rewApron.position.set(xOuterRight + endwallCanopyWidthM / 2, -0.10, (zOuterA + zGridB) / 2);
  groups.primarySteel.add(lewApron, rewApron);

  const boltGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.15, 8);
  const nutGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.024, 6);

  gridsX.forEach((gx, idx) => {
    const isEndGrid = idx === 0 || idx === 11;

    // Grid A & Grid C Base Plates (D1/D1X at corners, D2/D2X at interior sidewalls: PLT 360x750x25, 10 bolts)
    [
      { z: zGridA, code: isEndGrid ? (idx === 0 ? 'D1' : 'D1X') : 'D2', gridLabel: `A-${gx.label}` },
      { z: zGridC, code: isEndGrid ? (idx === 0 ? 'D1X' : 'D1') : 'D2X', gridLabel: `C-${gx.label}` },
    ].forEach(({ z, code, gridLabel }) => {
      const pedGroup = new THREE.Group();
      pedGroup.position.set(gx.xWorldM, 0, z);

      const pedMesh = new THREE.Mesh(new THREE.BoxGeometry(0.60, 0.45, 0.95), materials.pedestalConcrete);
      pedMesh.position.y = -0.20;
      pedGroup.add(pedMesh);

      const groutMesh = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.05, 0.80), materials.groutPad);
      groutMesh.position.y = 0.025;
      pedGroup.add(groutMesh);

      const bpMesh = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.025, 0.75), materials.basePlateSteel);
      bpMesh.position.y = 0.0625;
      bpMesh.userData.memberInfo = {
        name: `Base Plate Detail ${code} (${gridLabel})`,
        category: 'Foundation & Anchor Bolts (AB-01)',
        spec: 'PLT. 360×750×25 mm + 50mm Grout | 10 Nos. M-24 J-Bolts (Gr. 4.60, Fixed Base)',
        gridLocation: `Grid ${gridLabel} (FFL ±0.00m)`,
        drawingRef: 'J-100A246-AB-01',
      };
      interactables.push(bpMesh);
      pedGroup.add(bpMesh);

      const xOffsets = [-0.12, 0, 0.12];
      const zOffsets = [-0.315, -0.195, 0.195, 0.315];
      zOffsets.forEach((zo, zi) => {
        const cols = zi === 0 || zi === 3 ? xOffsets : [-0.12, 0.12];
        cols.forEach((xo) => {
          const bMesh = new THREE.Mesh(boltGeo, materials.anchorBoltSteel);
          bMesh.position.set(xo, 0.09, zo);
          const nMesh = new THREE.Mesh(nutGeo, materials.anchorBoltSteel);
          nMesh.position.set(xo, 0.088, zo);
          pedGroup.add(bMesh, nMesh);
        });
      });

      groups.primarySteel.add(pedGroup);
    });

    // Grid B Base Plates: D3 (B-1), D3X (B-12), and D4 (B-2 to B-5 Active Mezzanine Columns; B-6 to B-11 Future Mezzanine)
    const bCode = idx === 0 ? 'D3' : idx === 11 ? 'D3X' : 'D4';
    const isMezzActive = idx >= 1 && idx <= 4;
    const bPedGroup = new THREE.Group();
    bPedGroup.position.set(gx.xWorldM, 0, zGridB);

    const bPedMesh = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.45, 0.50), materials.pedestalConcrete);
    bPedMesh.position.y = -0.20;
    bPedGroup.add(bPedMesh);

    const bGroutMesh = new THREE.Mesh(new THREE.BoxGeometry(0.50, 0.05, 0.32), materials.groutPad);
    bGroutMesh.position.y = 0.025;
    bPedGroup.add(bGroutMesh);

    const bPlateMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.45, 0.025, 0.26),
      isEndGrid || isMezzActive ? materials.basePlateSteel : materials.splicePlate,
    );
    bPlateMesh.position.y = 0.0625;
    bPlateMesh.userData.memberInfo = {
      name: `Base Plate Detail ${bCode} (B-${gx.label})`,
      category: 'Foundation & Anchor Bolts (AB-01)',
      spec: isEndGrid
        ? 'PLT. 450×260×25 mm | 4 Nos. M-24 Anchor Bolts (Endwall Wind Column Base)'
        : isMezzActive
        ? 'PLT. 450×260×25 mm | 4 Nos. M-24 Anchor Bolts (Mezzanine Column W=400×5 Base)'
        : 'PLT. 450×260×25 mm | 4 Nos. M-24 Anchor Bolts (Future Mezzanine Foundation Pad)',
      gridLocation: `Grid B-${gx.label} (FFL ±0.00m)`,
      drawingRef: 'J-100A246-AB-01 & GA-03',
    };
    interactables.push(bPlateMesh);
    bPedGroup.add(bPlateMesh);

    [-0.06, 0.06].forEach((xo) => {
      [-0.06, 0.06].forEach((zo) => {
        const bMesh = new THREE.Mesh(boltGeo, materials.anchorBoltSteel);
        bMesh.position.set(xo, 0.09, zo);
        const nMesh = new THREE.Mesh(nutGeo, materials.anchorBoltSteel);
        nMesh.position.set(xo, 0.088, zo);
        bPedGroup.add(bMesh, nMesh);
      });
    });

    groups.primarySteel.add(bPedGroup);
  });

  // ============================================================================
  // 2. VISUAL CAD GRID SYSTEM & MILLIMETER DIMENSIONS ON GROUND (AB-01)
  // ============================================================================
  const gridLineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.65 });
  const dimLineMat = new THREE.LineBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.85 });
  const outerLineMat = new THREE.LineBasicMaterial({ color: 0xf43f5e, transparent: true, opacity: 0.65 });
  const gridY = 0.03;

  gridsX.forEach((gx, idx) => {
    const pts = [new THREE.Vector3(gx.xWorldM, gridY, -14.0), new THREE.Vector3(gx.xWorldM, gridY, 19.0)];
    const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), gridLineMat);
    groups.gridAndDimensions.add(line);

    const northBubble = createLabelSprite(gx.label, {
      isCircleBubble: true,
      borderColor: '#38bdf8',
      worldHeight: 1.5,
    });
    northBubble.position.set(gx.xWorldM, 0.9, -14.8);
    groups.gridAndDimensions.add(northBubble);

    const southBubble = createLabelSprite(gx.label, {
      isCircleBubble: true,
      borderColor: '#38bdf8',
      worldHeight: 1.5,
    });
    southBubble.position.set(gx.xWorldM, 0.9, 19.8);
    groups.gridAndDimensions.add(southBubble);

    if (idx > 0) {
      const prevX = gridsX[idx - 1].xWorldM;
      const midX = (prevX + gx.xWorldM) / 2;
      const is7000 = gx.baySpacingFromPrevMm === 7000;
      const is8285 = gx.baySpacingFromPrevMm === 8285;
      const dimSprite = createLabelSprite(`${gx.baySpacingFromPrevMm} (C/C)`, {
        borderColor: is7000 ? '#f43f5e' : is8285 ? '#f59e0b' : '#fbbf24',
        textColor: is7000 ? '#fecdd3' : '#fef08a',
        worldHeight: 0.95,
      });
      dimSprite.position.set(midX, 0.6, -11.6);
      groups.gridAndDimensions.add(dimSprite);

      if (gridsX[idx - 1].isBracedBayAfter) {
        const braceLabel = createLabelSprite('PORTAL 5.5M + ROD BRACE', {
          borderColor: '#22d3ee',
          textColor: '#a5f3fc',
          worldHeight: 0.8,
        });
        braceLabel.position.set(midX, 0.5, -10.3);
        groups.gridAndDimensions.add(braceLabel);
      }
    }
  });

  const dimZ1 = -11.6;
  const dimZ2 = -13.0;
  groups.gridAndDimensions.add(
    new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(xGrid1, gridY, dimZ1),
        new THREE.Vector3(xGrid12, gridY, dimZ1),
      ]),
      dimLineMat,
    ),
    new THREE.Line(
      new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(xOuterLeft, gridY, dimZ2),
        new THREE.Vector3(xOuterRight, gridY, dimZ2),
      ]),
      outerLineMat,
    ),
  );

  const totalCCSprite = createLabelSprite('87285 mm (C/C OF STEEL COLUMN) | 88275 mm (O/O OF STEEL LINE)', {
    borderColor: '#f59e0b',
    textColor: '#fde68a',
    worldHeight: 1.15,
  });
  totalCCSprite.position.set(0, 0.85, dimZ2);
  groups.gridAndDimensions.add(totalCCSprite);

  gridsZ.forEach((gz) => {
    const pts = [new THREE.Vector3(-48.5, gridY, gz.zWorldM), new THREE.Vector3(48.5, gridY, gz.zWorldM)];
    const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), gridLineMat);
    groups.gridAndDimensions.add(line);

    const leftBubble = createLabelSprite(gz.label, {
      isCircleBubble: true,
      borderColor: '#f59e0b',
      textColor: '#fde68a',
      worldHeight: 1.5,
    });
    leftBubble.position.set(-49.5, 0.9, gz.zWorldM);
    groups.gridAndDimensions.add(leftBubble);

    const rightBubble = createLabelSprite(gz.label, {
      isCircleBubble: true,
      borderColor: '#f59e0b',
      textColor: '#fde68a',
      worldHeight: 1.5,
    });
    rightBubble.position.set(49.5, 0.9, gz.zWorldM);
    groups.gridAndDimensions.add(rightBubble);
  });

  const spanABSprite = createLabelSprite('8500 mm (C/C)', { borderColor: '#fbbf24', worldHeight: 0.95 });
  spanABSprite.position.set(-46.5, 0.65, -4.25);
  const spanBCSprite = createLabelSprite('8500 mm (C/C)', { borderColor: '#fbbf24', worldHeight: 0.95 });
  spanBCSprite.position.set(-46.5, 0.65, 4.25);
  const spanTotalSprite = createLabelSprite('17000 C/C | 18290 O/O', {
    borderColor: '#f43f5e',
    textColor: '#fecdd3',
    worldHeight: 1.0,
  });
  spanTotalSprite.position.set(-47.2, 1.8, 0);
  const canopyDimSprite = createLabelSprite('6100 mm (CANOPY WIDE)', {
    borderColor: '#38bdf8',
    textColor: '#bae6fd',
    worldHeight: 0.95,
  });
  canopyDimSprite.position.set(-46.5, 0.65, zOuterC + canopyWidthM / 2);

  const fswBadge = createLabelSprite('FSW — FRONT SIDE WALL (LOW EAVE ±9485 + 6100 CANOPY)', {
    borderColor: '#38bdf8',
    worldHeight: 1.15,
  });
  fswBadge.position.set(0, 0.9, 21.8);

  const bswBadge = createLabelSprite('BSW — BACK SIDE WALL (HIGH EAVE ±11315 + 3 Nos. F.O. 4.5×4.0M)', {
    borderColor: '#38bdf8',
    worldHeight: 1.15,
  });
  bswBadge.position.set(0, 0.9, -16.8);

  const lewBadge = createLabelSprite('LEW — LEFT END WALL (@GL-01 · 3.0M CANOPY & F.O. 4.5×4.0M)', {
    borderColor: '#38bdf8',
    worldHeight: 1.1,
  });
  lewBadge.position.set(-51.8, 0.9, 0);

  const rewBadge = createLabelSprite('REW — RIGHT END WALL (@GL-12 · 3.0M CANOPY & F.O. 4.5×4.5M)', {
    borderColor: '#38bdf8',
    worldHeight: 1.1,
  });
  rewBadge.position.set(51.8, 0.9, 0);

  groups.gridAndDimensions.add(
    spanABSprite,
    spanBCSprite,
    spanTotalSprite,
    canopyDimSprite,
    fswBadge,
    bswBadge,
    lewBadge,
    rewBadge,
  );

  // ============================================================================
  // 3. PRIMARY PEB STEEL FRAMES (GL-01 TO GL-12) + SIDEWALL & ENDWALL CANOPY RAFTERS
  // ============================================================================
  gridsX.forEach((gx, idx) => {
    const isEndFrame = idx === 0 || idx === 11;
    const x = gx.xWorldM;
    const frameLabel = isEndFrame ? (idx === 0 ? 'End Frame @GL-01' : 'End Frame @GL-12') : `Rigid Frame @GL-${String(idx + 1).padStart(2, '0')}`;

    // 3A. High-Side Column at Grid A (W=500x5, 2F=180x10)
    const colATopY = getMainRoofElevationAtZ(zGridA) - 0.58;
    const colA = createIBeamMember(
      new THREE.Vector3(x, 0.075, zGridA),
      new THREE.Vector3(x, colATopY, zGridA),
      0.50,
      0.18,
      0.010,
      0.005,
      materials.primarySteel,
      'verticalColumn',
      {
        name: `Main Column Grid A-${gx.label}`,
        category: frameLabel,
        spec: 'Built-Up I-Section: Web 500×5 mm, Flanges 2F=180×10 mm (Eave ±11,315 mm)',
        gridLocation: `Grid A-${gx.label} (Z = -8,500 mm)`,
        drawingRef: 'J-100A246-GA-03',
      },
      interactables,
    );
    groups.primarySteel.add(colA);

    // 3B. Low-Side Column at Grid C (W=500x5, 2F=180x12)
    const colCTopY = getMainRoofElevationAtZ(zGridC) - 0.58;
    const colC = createIBeamMember(
      new THREE.Vector3(x, 0.075, zGridC),
      new THREE.Vector3(x, colCTopY, zGridC),
      0.50,
      0.18,
      0.012,
      0.005,
      materials.primarySteel,
      'verticalColumn',
      {
        name: `Main Column Grid C-${gx.label}`,
        category: frameLabel,
        spec: 'Built-Up I-Section: Web 500×5 mm, Flanges 2F=180×12 mm (Clear Height 8,600 mm, Eave ±9,485 mm)',
        gridLocation: `Grid C-${gx.label} (Z = +8,500 mm)`,
        drawingRef: 'J-100A246-GA-03',
      },
      interactables,
    );
    groups.primarySteel.add(colC);

    // 3C. Endwall Center Wind Column at Grid B (on End Frames GL-01 and GL-12)
    if (isEndFrame) {
      const colBTopY = getMainRoofElevationAtZ(zGridB) - 0.58;
      const colB = createIBeamMember(
        new THREE.Vector3(x, 0.075, zGridB),
        new THREE.Vector3(x, colBTopY, zGridB),
        0.40,
        0.225,
        0.012,
        0.005,
        materials.primarySteel,
        'verticalColumn',
        {
          name: `Endwall Gable Wind Column Grid B-${gx.label}`,
          category: frameLabel,
          spec: 'Built-Up I-Section: Web 400×5 mm, Flanges 2F=225×12 mm (Detail D3/D3X Pin Base)',
          gridLocation: `Grid B-${gx.label} (Z = 0 mm Centerline)`,
          drawingRef: 'J-100A246-GA-03 & GA-04',
        },
        interactables,
      );
      groups.primarySteel.add(colB);
    }

    // 3D. Mono-Slope Main Rafter (1:10 Slope from Z = zOuterA to Z = zOuterC)
    const zSeg1 = zOuterA + 3.0;
    const zSeg2 = zSeg1 + 12.0;
    const rafterOffsetFromSheet = 0.58;

    const pR0 = new THREE.Vector3(x, getMainRoofElevationAtZ(zOuterA + 0.15) - rafterOffsetFromSheet, zOuterA + 0.15);
    const pR1 = new THREE.Vector3(x, getMainRoofElevationAtZ(zSeg1) - rafterOffsetFromSheet, zSeg1);
    const pR2 = new THREE.Vector3(x, getMainRoofElevationAtZ(zSeg2) - rafterOffsetFromSheet, zSeg2);
    const pR3 = new THREE.Vector3(x, getMainRoofElevationAtZ(zOuterC - 0.15) - rafterOffsetFromSheet, zOuterC - 0.15);

    const rafterMeta: InspectedMemberInfo = {
      name: `Mono-Slope Main Rafter @ Grid ${gx.label}`,
      category: frameLabel,
      spec: '1:10 Slope | High 3m: W=600~500×5 (2F=150×8) | Mid 12m: W=500×5 (2F=150×6) | Low Haunch: W=500~700×5 (2F=150×8)',
      gridLocation: `Grid ${gx.label} (Span 17,000 mm C/C, 18,290 mm O/O)`,
      drawingRef: 'J-100A246-GA-03',
    };

    groups.primarySteel.add(
      createIBeamMember(pR0, pR1, 0.56, 0.15, 0.008, 0.005, materials.primarySteel, 'transverse', rafterMeta, interactables),
      createIBeamMember(pR1, pR2, 0.50, 0.15, 0.006, 0.005, materials.primarySteel, 'transverse', rafterMeta, interactables),
      createIBeamMember(pR2, pR3, 0.62, 0.15, 0.008, 0.005, materials.primarySteel, 'transverse', rafterMeta, interactables),
    );

    [pR1, pR2].forEach((spPt) => {
      const spMesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.54, 0.04), materials.splicePlate);
      spMesh.position.copy(spPt);
      groups.primarySteel.add(spMesh);
    });

    // 3E. 6,100 mm Wide Sidewall Canopy Rafter & Inclined Tie Strut (Grids 1 to 11 only; Bay 11-12 canopy removed)
    if (idx <= 10) {
      const canopyStart = new THREE.Vector3(x, getCanopyRoofElevationAtZ(zOuterC + 0.12) - 0.48, zOuterC + 0.12);
      const canopyEnd = new THREE.Vector3(x, getCanopyRoofElevationAtZ(zCanopyEdge - 0.12) - 0.42, zCanopyEdge - 0.12);

      const canopyRafter = createIBeamMember(
        canopyStart,
        canopyEnd,
        0.54,
        0.15,
        0.006,
        0.005,
        materials.primarySteel,
        'transverse',
        {
          name: `Sidewall Canopy Rafter @ Grid C-${gx.label}`,
          category: '6,100 mm Sidewall Canopy (Grids 1 to 11)',
          spec: 'Tapered Built-Up Rafter: W=700~500×5, 2F=150×6 + NB 100×100×2.9mm Tie Strut | 6,100 mm Projection, 1:10 Slope',
          gridLocation: `Grid C-${gx.label} (+9.145m to +15.245m)`,
          drawingRef: 'J-100A246-GA-02 & GA-03',
        },
        interactables,
      );
      groups.primarySteel.add(canopyRafter);

      const tieStart = new THREE.Vector3(x, 7.65, zOuterC);
      const tieEnd = new THREE.Vector3(x, getCanopyRoofElevationAtZ(zOuterC + 2.6) - 0.48, zOuterC + 2.6);
      const tieStrut = createRodBetweenPoints(tieStart, tieEnd, 0.05, materials.strutTube, 4);
      groups.primarySteel.add(tieStrut);
    }
  });

  // 3F. Endwall Canopies (3,000 mm Wide, 5,000 mm Clear Height) at LEW (@GL-01) and REW (@GL-12) between Grid A & Grid B
  [
    { xWall: xOuterLeft, dirSign: -1, label: 'LEW @GL-01 (CANOPY GL-B)', hasStitchCol: false },
    { xWall: xOuterRight, dirSign: 1, label: 'REW @GL-12 (CANOPY GL-A)', hasStitchCol: true },
  ].forEach(({ xWall, dirSign, label, hasStitchCol }) => {
    [zGridA, (zGridA + zGridB) / 2, zGridB].forEach((zCol, cIdx) => {
      const startPt = new THREE.Vector3(xWall, 5.26, zCol);
      const endPt = new THREE.Vector3(xWall + dirSign * (endwallCanopyWidthM - 0.08), 4.96, zCol);
      const ewCanRafter = createIBeamMember(
        startPt,
        endPt,
        0.38,
        0.15,
        0.006,
        0.005,
        materials.primarySteel,
        'longitudinal',
        {
          name: `3,000 mm Endwall Canopy Rafter — ${label} (${cIdx === 0 ? 'Grid A' : cIdx === 1 ? 'Mid Span' : 'Grid B'})`,
          category: 'Endwall Canopy System (GA-03 & GA-04)',
          spec: `Tapered Rafter: W=600~300×5, 2F=150×6 | 3,000 mm Projection, 5,000 mm Clear Height, 1:10 Slope${hasStitchCol ? ' + W=300×5 Stitch Column' : ''}`,
          gridLocation: `${label} — Span A to B`,
          drawingRef: 'J-100A246-GA-03 & GA-04',
        },
        interactables,
      );
      groups.primarySteel.add(ewCanRafter);

      // Stitch column W=300x5, 2F=150x6 on CANOPY GL-A detail
      if (hasStitchCol && cIdx !== 1) {
        const stitchCol = createIBeamMember(
          new THREE.Vector3(xWall + dirSign * 0.15, 0.075, zCol),
          new THREE.Vector3(xWall + dirSign * 0.15, 5.40, zCol),
          0.30,
          0.15,
          0.006,
          0.005,
          materials.portalSteel,
          'verticalColumn',
        );
        groups.primarySteel.add(stitchCol);
      }
    });
  });

  // ============================================================================
  // 4. COMPLETE MEZZANINE FLOOR SYSTEM & 3-FLIGHT STAIRCASE (GA-03, GA-07, GA-08)
  // ============================================================================
  {
    const mezzTopSlabY = 5.374; // EL +5.374 M (T.O. SLAB)
    const mezzSlabThk = 0.150;  // 150 mm thick RCC composite slab over 0.6mm decking sheet
    const mezzBeamBotY = 4.500; // 4,500 mm Bottom of Mezzanine Main Beam
    const mezzBeamDepth = 0.700;// W=700x8, 2F=275x12
    const mezzBeamCenterY = mezzBeamBotY + mezzBeamDepth / 2; // 4.850 m

    // Stairwell opening coordinates in Bay 3 (Grid 3 to Grid 3' = 3,235 mm; Grid C to Grid D = 5,750 mm)
    const xStairStart = gridsX[2].xWorldM;        // Grid 3 = -27.3575 m
    const xStairEnd = xStairStart + 3.235;        // Grid 3' = -24.1225 m
    const zStairFront = zGridC;                   // Grid C = +8.500 m
    const zStairBack = zGridC - 5.750;            // Grid D = +2.750 m

    // 4A. Mezzanine Support Columns along Grid B (GL-02 to GL-05: W=400x5, 2F=225x12)
    // (Note: GL-01 already has the Endwall Wind Column at Grid B-1)
    for (let i = 1; i <= 4; i++) {
      const gx = gridsX[i];
      const mezzCol = createIBeamMember(
        new THREE.Vector3(gx.xWorldM, 0.075, zGridB),
        new THREE.Vector3(gx.xWorldM, mezzBeamBotY, zGridB),
        0.40,
        0.225,
        0.012,
        0.005,
        materials.mezzanineBeamSteel,
        'verticalColumn',
        {
          name: `Mezzanine Center Support Column @ Grid B-${gx.label}`,
          category: 'Mezzanine Primary Structure (GA-03 & GA-07)',
          spec: 'Built-Up I-Section: Web 400×5 mm, Flanges 2F=225×12 mm | Base Detail D4 (PLT 450×260×25, 4–M24 Bolts)',
          gridLocation: `Grid B-${gx.label} (FFL ±0.00m to +4,500 mm B.O. Beam)`,
          drawingRef: 'J-100A246-GA-03 & GA-07',
        },
        interactables,
      );
      groups.mezzanine.add(mezzCol);
    }

    // 4B. Mezzanine Primary Transverse Beams (@GL-01 to @GL-05: W=700x8, 2F=275x12)
    for (let i = 0; i <= 4; i++) {
      const gx = gridsX[i];
      const x = gx.xWorldM;
      const beamMeta: InspectedMemberInfo = {
        name: `Mezzanine Main Transverse Beam @ Grid ${gx.label}`,
        category: 'Mezzanine Primary Structure (GA-03 & GA-07)',
        spec: 'Built-Up I-Section: Web 700×8 mm, Flanges 2F=275×12 mm | B.O. Beam +4,500 mm | Splices SP-4 (M30×90) & SP-5 (M36×90)',
        gridLocation: `Grid ${gx.label} (Spanning Grid A to Grid B to Grid C = 17,000 mm C/C)`,
        drawingRef: 'J-100A246-GA-03 & GA-07',
      };

      const beamAB = createIBeamMember(
        new THREE.Vector3(x, mezzBeamCenterY, zGridA + 0.25),
        new THREE.Vector3(x, mezzBeamCenterY, zGridB - 0.20),
        mezzBeamDepth,
        0.275,
        0.012,
        0.008,
        materials.mezzanineBeamSteel,
        'transverse',
        beamMeta,
        interactables,
      );
      const beamBC = createIBeamMember(
        new THREE.Vector3(x, mezzBeamCenterY, zGridB + 0.20),
        new THREE.Vector3(x, mezzBeamCenterY, zGridC - 0.25),
        mezzBeamDepth,
        0.275,
        0.012,
        0.008,
        materials.mezzanineBeamSteel,
        'transverse',
        beamMeta,
        interactables,
      );
      groups.mezzanine.add(beamAB, beamBC);

      // Splice plates SP-4 (at A & C) and SP-5 (at B)
      [zGridA + 0.28, zGridB - 0.22, zGridB + 0.22, zGridC - 0.28].forEach((sz) => {
        const sp = new THREE.Mesh(new THREE.BoxGeometry(0.30, 0.68, 0.03), materials.splicePlate);
        sp.position.set(x, mezzBeamCenterY, sz);
        groups.mezzanine.add(sp);
      });
    }

    // 4C. Mezzanine Secondary Longitudinal Joists (Part MJ-1 on GA-07: Web=450x5 THK, Flange=130x6 THK)
    // Top of joist aligns with underside of decking at Y = 5.224m -> Center of 450mm joist = 5.224 - 0.225 = 4.999m
    const joistCenterY = mezzTopSlabY - mezzSlabThk - 0.225;
    const joistZLines = [-8.3, -6.65, -5.0, -3.35, -1.7, 0.0, 1.65, 2.75, 4.65, 6.55, 8.3];

    joistZLines.forEach((jz, jIdx) => {
      const joistMeta: InspectedMemberInfo = {
        name: `Mezzanine Joist MJ-1 (Line #${jIdx + 1})`,
        category: 'Mezzanine Secondary Framing (GA-07 Table)',
        spec: 'Part Mk. MJ-1: Web 450×5 THK., Flange 130×6 THK. | Connected with 4–M24 Bolts & 16mm End Plate (Section C-C & E-E)',
        gridLocation: `Grids 1 to 5 (Z = ${Math.round((jz - zGridA) * 1000)} mm from Grid A)`,
        drawingRef: 'J-100A246-GA-07',
      };

      for (let b = 0; b < 4; b++) {
        const bx1 = gridsX[b].xWorldM;
        const bx2 = gridsX[b + 1].xWorldM;

        // In Bay 3 (b === 2, Grid 3 to 4), joists inside the stairwell zone (jz > zStairBack) start at Grid 3' (xStairEnd)
        if (b === 2 && jz > zStairBack + 0.1) {
          const trimmedJoist = createIBeamMember(
            new THREE.Vector3(xStairEnd, joistCenterY, jz),
            new THREE.Vector3(bx2, joistCenterY, jz),
            0.45,
            0.13,
            0.006,
            0.005,
            materials.mezzanineJoistSteel,
            'longitudinal',
            joistMeta,
            interactables,
          );
          groups.mezzanine.add(trimmedJoist);
        } else {
          const fullJoist = createIBeamMember(
            new THREE.Vector3(bx1, joistCenterY, jz),
            new THREE.Vector3(bx2, joistCenterY, jz),
            0.45,
            0.13,
            0.006,
            0.005,
            materials.mezzanineJoistSteel,
            'longitudinal',
            joistMeta,
            interactables,
          );
          groups.mezzanine.add(fullJoist);
        }
      }
    });

    // Transverse Stairwell Header Beam along Grid 3' (X = xStairEnd, from zStairBack to zGridC)
    const stairHeaderBeam = createIBeamMember(
      new THREE.Vector3(xStairEnd, joistCenterY, zStairBack),
      new THREE.Vector3(xStairEnd, joistCenterY, zGridC - 0.2),
      0.45,
      0.15,
      0.008,
      0.006,
      materials.mezzanineBeamSteel,
      'transverse',
      {
        name: "Stairwell Header Beam @ Grid 3' (GL C to D)",
        category: 'Mezzanine Stairwell Framing (GA-07 & GA-08)',
        spec: 'Built-Up Header Beam supporting MJ-1 Joists around 3,235 × 5,750 mm Stairwell Opening',
        gridLocation: "Grid 3' (3,235 mm from Grid 3, Z = +2.75m to +8.50m)",
        drawingRef: 'J-100A246-GA-07 & GA-08',
      },
      interactables,
    );
    groups.mezzanine.add(stairHeaderBeam);

    // 4D. 150 mm Composite R.C.C. Mezzanine Deck Slab + 0.6 mm Profiled Metal Decking Sheet (EL +5.374m)
    // Built in 3 non-overlapping rectangular regions around the Bay 3 stairwell opening (xStairStart..xStairEnd, zStairBack..zOuterC)
    const mezzXMin = xOuterLeft + 0.25;
    const mezzXMax = xGrid5;
    const mezzZMin = zOuterA + 0.25;
    const mezzZMax = zOuterC - 0.25;

    const slabRegions = [
      // Region 1: Full length (Grid 1 to 5), Rear/Mid Zone from Grid A (mezzZMin) to Grid D (zStairBack)
      { x1: mezzXMin, x2: mezzXMax, z1: mezzZMin, z2: zStairBack },
      // Region 2: Front Zone (zStairBack to mezzZMax), Left of Stairwell (Grid 1 to Grid 3)
      { x1: mezzXMin, x2: xStairStart, z1: zStairBack, z2: mezzZMax },
      // Region 3: Front Zone (zStairBack to mezzZMax), Right of Stairwell (Grid 3' to Grid 5)
      { x1: xStairEnd, x2: mezzXMax, z1: zStairBack, z2: mezzZMax },
    ];

    const slabMeta: InspectedMemberInfo = {
      name: 'Mezzanine Composite RCC Deck Slab (EL +5.374 M)',
      category: 'Mezzanine Floor System (GA-03 & GA-07)',
      spec: '150 mm Thk. RCC Slab over 0.6 mm Thk. Profiled Metal Decking Sheet | Staggered SDS-24×35 @ Every Valley + Shear Studs',
      gridLocation: 'Grids 1 to 5 (32,285 mm C/C) × Grids A to C (17,000 mm C/C)',
      drawingRef: 'J-100A246-GA-03 & GA-07',
    };

    slabRegions.forEach((reg) => {
      const rw = reg.x2 - reg.x1;
      const rd = reg.z2 - reg.z1;
      const rx = (reg.x1 + reg.x2) / 2;
      const rz = (reg.z1 + reg.z2) / 2;

      const rccMesh = new THREE.Mesh(
        new THREE.BoxGeometry(rw, mezzSlabThk, rd),
        materials.mezzanineConcreteSlab,
      );
      rccMesh.position.set(rx, mezzTopSlabY - mezzSlabThk / 2, rz);
      rccMesh.castShadow = true;
      rccMesh.receiveShadow = true;
      rccMesh.userData.memberInfo = slabMeta;
      interactables.push(rccMesh);

      const deckSheetMesh = new THREE.Mesh(
        new THREE.BoxGeometry(rw, 0.018, rd),
        materials.mezzanineDeckSheet,
      );
      deckSheetMesh.position.set(rx, mezzTopSlabY - mezzSlabThk - 0.01, rz);
      deckSheetMesh.userData.memberInfo = slabMeta;
      interactables.push(deckSheetMesh);

      groups.mezzanine.add(rccMesh, deckSheetMesh);
    });

    // 4E. 3-Stage Multi-Flight Dog-Leg Staircase & 3 Nos. Detail D5 Columns (GA-08)
    // Located between Grid 3 (xStairStart) & Grid 3' (xStairEnd, width = 3.235m)
    // and between Grid C (zStairFront = +8.50m) & Grid D (zStairBack = +2.75m, length = 5.750m)
    // 3 Nos. D5 Columns (WEB 300x5, FLANGE 180x8 on PLT 350x240x25 with 4-M24 bolts)
    const d5Locations = [
      { x: xStairEnd, z: zStairFront - 0.35, h: mezzTopSlabY, label: "Grid C-3'" },
      { x: xStairEnd, z: zStairBack, h: mezzTopSlabY, label: "Grid D-3'" },
      { x: xStairStart, z: zStairBack, h: mezzTopSlabY, label: 'Grid D-3' },
    ];

    d5Locations.forEach((d5) => {
      // Detail D5 Base Plate (PLT 350x240x25)
      const bpD5 = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.025, 0.24), materials.basePlateSteel);
      bpD5.position.set(d5.x, 0.0625, d5.z);
      const colD5 = createIBeamMember(
        new THREE.Vector3(d5.x, 0.075, d5.z),
        new THREE.Vector3(d5.x, d5.h, d5.z),
        0.30,
        0.18,
        0.008,
        0.005,
        materials.mezzanineBeamSteel,
        'verticalColumn',
        {
          name: `Staircase Support Column & Base D5 (${d5.label})`,
          category: 'Mezzanine Staircase Structure (GA-08)',
          spec: 'Column: WEB 300×5, FLANGE 180×8 | Base Detail D5: PLT. 350×240×25 mm with 4 Nos. M-24 Anchor Bolts (3 Nos. Reqd.)',
          gridLocation: `${d5.label} (Bay 3–4 Stairwell)`,
          drawingRef: 'J-100A246-GA-08 & AB-01',
        },
        interactables,
      );
      groups.mezzanine.add(bpD5, colD5);
    });

    // Two Intermediate Checkered-Plate Mid-Landings at Y1 = +1.791m and Y2 = +3.582m (GA-08: 1791 + 1791 + 1791 = 5373~5374mm)
    const yLand1 = 1.791;
    const yLand2 = 3.582;
    const landingDepth = 1.15;
    const stairFlightWidth = 1.35;

    const landingMeta: InspectedMemberInfo = {
      name: 'Mezzanine Staircase (ISMC 250 Stringers, Checkered Landings & STRD1 Treads)',
      category: 'Mezzanine Access Staircase (GA-08)',
      spec: 'Footprint 3,235 × 5,750 mm | 3 Stages × 1,791 mm = +5,374 mm | Stringers: ISMC 250 | Treads: 250×158 mm (2–M12×40 Bolts)',
      gridLocation: "Bay 3–4 (Grid 3 to 3', Grid C to D)",
      drawingRef: 'J-100A246-GA-08',
    };

    // Landing 1 (+1.791m) at Grid D end (zStairBack to zStairBack + 1.25m, spanning full 3.235m width from xStairStart to xStairEnd)
    const land1Mesh = new THREE.Mesh(
      new THREE.BoxGeometry(3.235, 0.12, landingDepth),
      materials.staircaseSteel,
    );
    land1Mesh.position.set((xStairStart + xStairEnd) / 2, yLand1, zStairBack + landingDepth / 2);
    land1Mesh.castShadow = true;
    land1Mesh.userData.memberInfo = landingMeta;
    interactables.push(land1Mesh);
    groups.mezzanine.add(land1Mesh);

    // Landing 2 (+3.582m) at Grid C end (zStairFront - 0.35m - landingDepth to zStairFront - 0.35m)
    const land2Mesh = new THREE.Mesh(
      new THREE.BoxGeometry(3.235, 0.12, landingDepth),
      materials.staircaseSteel,
    );
    land2Mesh.position.set(
      (xStairStart + xStairEnd) / 2,
      yLand2,
      zStairFront - 0.35 - landingDepth / 2,
    );
    land2Mesh.castShadow = true;
    land2Mesh.userData.memberInfo = landingMeta;
    interactables.push(land2Mesh);
    groups.mezzanine.add(land2Mesh);

    // Helper to build a Stair Flight with two ISMC 250 channel stringers, 11 STRD1 treads (250x158mm), and sloped handrail
    const buildStairFlight = (
      xCenter: number,
      zStart: number,
      zEnd: number,
      yStart: number,
      yEnd: number,
    ) => {
      const fGroup = new THREE.Group();
      const halfW = stairFlightWidth / 2;

      // Two ISMC 250 Stringers
      [-halfW, halfW].forEach((ox) => {
        const sBeam = createRodBetweenPoints(
          new THREE.Vector3(xCenter + ox, yStart, zStart),
          new THREE.Vector3(xCenter + ox, yEnd, zEnd),
          0.065,
          materials.staircaseSteel,
          4,
        );
        sBeam.userData.memberInfo = landingMeta;
        interactables.push(sBeam);
        fGroup.add(sBeam);

        // Sloped 1,000mm High Tubular Handrail (32 NB Tube: Top Rail @ +1.0m, Mid Rail @ +0.5m)
        const topRail = createRodBetweenPoints(
          new THREE.Vector3(xCenter + ox, yStart + 1.0, zStart),
          new THREE.Vector3(xCenter + ox, yEnd + 1.0, zEnd),
          0.02,
          materials.handrailYellow,
          8,
        );
        const midRail = createRodBetweenPoints(
          new THREE.Vector3(xCenter + ox, yStart + 0.5, zStart),
          new THREE.Vector3(xCenter + ox, yEnd + 0.5, zEnd),
          0.016,
          materials.handrailYellow,
          8,
        );
        fGroup.add(topRail, midRail);

        for (let p = 0; p <= 3; p++) {
          const t = p / 3;
          const px = xCenter + ox;
          const py = yStart + (yEnd - yStart) * t;
          const pz = zStart + (zEnd - zStart) * t;
          const post = createRodBetweenPoints(
            new THREE.Vector3(px, py, pz),
            new THREE.Vector3(px, py + 1.0, pz),
            0.02,
            materials.handrailYellow,
            8,
          );
          fGroup.add(post);
        }
      });

      // 11 Checkered Plate Treads (STRD1: 250mm deep x 158mm rise)
      const steps = 11;
      const treadGeo = new THREE.BoxGeometry(stairFlightWidth - 0.08, 0.035, 0.25);
      for (let s = 1; s <= steps; s++) {
        const t = s / (steps + 1);
        const ty = yStart + (yEnd - yStart) * t;
        const tz = zStart + (zEnd - zStart) * t;
        const tread = new THREE.Mesh(treadGeo, materials.staircaseSteel);
        tread.position.set(xCenter, ty, tz);
        tread.castShadow = true;
        tread.userData.memberInfo = landingMeta;
        interactables.push(tread);
        fGroup.add(tread);
      }

      groups.mezzanine.add(fGroup);
    };

    const xFlightRight = xStairEnd - stairFlightWidth / 2 - 0.12;
    const xFlightLeft = xStairStart + stairFlightWidth / 2 + 0.12;
    const zFlightFront = zStairFront - 0.35 - landingDepth;
    const zFlightBack = zStairBack + landingDepth;

    // Flight 1: FFL ±0.00m (Front-Right) up to Landing 1 (+1.791m at Back)
    buildStairFlight(xFlightRight, zFlightFront, zFlightBack, 0.05, yLand1);
    // Flight 2: Landing 1 (+1.791m at Back-Left) up to Landing 2 (+3.582m at Front-Left)
    buildStairFlight(xFlightLeft, zFlightBack, zFlightFront, yLand1, yLand2);
    // Flight 3: Landing 2 (+3.582m at Front-Right) up to Mezzanine Deck (+5.374m at Back-Right / Grid D)
    buildStairFlight(xFlightRight, zFlightFront, zFlightBack, yLand2, mezzTopSlabY);

    // 4F. 1,000 mm High Mezzanine Edge Safety Handrail (32 NB Tube @ +500/+1000mm + 100x6 Toe Plate — GA-08)
    const buildHandrailSegment = (pStart: THREE.Vector3, pEnd: THREE.Vector3) => {
      const hrGroup = new THREE.Group();
      const dist = pStart.distanceTo(pEnd);
      const postCount = Math.max(2, Math.ceil(dist / 1.8));

      // Top rail (+1.00m) & Mid rail (+0.50m)
      hrGroup.add(
        createRodBetweenPoints(
          pStart.clone().add(new THREE.Vector3(0, 1.0, 0)),
          pEnd.clone().add(new THREE.Vector3(0, 1.0, 0)),
          0.022,
          materials.handrailYellow,
          8,
        ),
        createRodBetweenPoints(
          pStart.clone().add(new THREE.Vector3(0, 0.5, 0)),
          pEnd.clone().add(new THREE.Vector3(0, 0.5, 0)),
          0.018,
          materials.handrailYellow,
          8,
        ),
        // 100 x 6 THK. Toe Plate at base of handrail
        createRodBetweenPoints(
          pStart.clone().add(new THREE.Vector3(0, 0.06, 0)),
          pEnd.clone().add(new THREE.Vector3(0, 0.06, 0)),
          0.035,
          materials.handrailYellow,
          4,
        ),
      );

      for (let i = 0; i <= postCount; i++) {
        const pt = new THREE.Vector3().lerpVectors(pStart, pEnd, i / postCount);
        hrGroup.add(
          createRodBetweenPoints(
            pt,
            pt.clone().add(new THREE.Vector3(0, 1.0, 0)),
            0.022,
            materials.handrailYellow,
            8,
          ),
        );
      }

      const hrMeta: InspectedMemberInfo = {
        name: 'Mezzanine Tubular Safety Handrail (1,000 mm High)',
        category: 'Mezzanine Edge & Stair Guardrail (GA-08)',
        spec: '32 NB (M) Tube Posts & Rails @ +500 mm / +1,000 mm + 100×6 THK. Toe Plate (TYP. DETAIL OF HANDRAIL)',
        gridLocation: 'Mezzanine Open Edge @ Grid 5 & Stairwell Perimeter',
        drawingRef: 'J-100A246-GA-08',
      };
      hrGroup.traverse((c) => {
        if ((c as THREE.Mesh).isMesh) {
          c.userData.memberInfo = hrMeta;
          interactables.push(c);
        }
      });
      groups.mezzanine.add(hrGroup);
    };

    // Handrail along open Mezzanine edge at Grid 5 (X = xGrid5, from Grid A to Grid C)
    buildHandrailSegment(
      new THREE.Vector3(xGrid5 - 0.08, mezzTopSlabY, mezzZMin),
      new THREE.Vector3(xGrid5 - 0.08, mezzTopSlabY, mezzZMax),
    );
    // Handrail around Stairwell Perimeter on Mezzanine Deck (Left edge @ Grid 3 & Right edge @ Grid 3')
    buildHandrailSegment(
      new THREE.Vector3(xStairStart - 0.08, mezzTopSlabY, zStairBack),
      new THREE.Vector3(xStairStart - 0.08, mezzTopSlabY, mezzZMax),
    );
    buildHandrailSegment(
      new THREE.Vector3(xStairEnd + 0.08, mezzTopSlabY, zStairBack),
      new THREE.Vector3(xStairEnd + 0.08, mezzTopSlabY, mezzZMax),
    );

    // Floating Label Badges on Mezzanine Deck & Future Mezzanine Zone
    const mezzBadge = createLabelSprite('MEZZANINE FLOOR (GRIDS 1–5 · EL +5.374M · 150MM SLAB)', {
      borderColor: '#38bdf8',
      textColor: '#e0f2fe',
      worldHeight: 1.05,
    });
    mezzBadge.position.set((xGrid1 + xGrid5) / 2, mezzTopSlabY + 1.35, -2.5);
    groups.mezzanine.add(mezzBadge);

    const futureMezzBadge = createLabelSprite('FUTURE MEZZANINE ZONE (GRIDS 5 TO 12)', {
      borderColor: '#f59e0b',
      textColor: '#fef08a',
      worldHeight: 1.05,
    });
    futureMezzBadge.position.set((xGrid5 + xGrid12) / 2, 0.75, 4.2);
    groups.gridAndDimensions.add(futureMezzBadge);
  }

  // ============================================================================
  // 5. PORTAL BRACING FRAMES (5.50M HIGH, DETAIL-C) & ROD X-BRACING + STRUTS
  // ============================================================================
  BUILDING_DIMENSIONS_MM.bracedBayIndices.forEach((bayIdx) => {
    const x1 = gridsX[bayIdx].xWorldM;
    const x2 = gridsX[bayIdx + 1].xWorldM;
    const bayLabel = `Bay ${bayIdx + 1} (Grid ${bayIdx + 1} to ${bayIdx + 2})`;

    [
      { z: zGridA, wallName: 'GL-A (BSW)', topY: 10.65 },
      { z: zGridC, wallName: 'GL-C (FSW)', topY: 8.85 },
    ].forEach(({ z, wallName, topY }) => {
      const px1 = x1 + 0.35;
      const px2 = x2 - 0.35;
      const portalY = 5.50; // Revised to 5,500 mm ("PORTAL BRACING UPTO 5.5M & ABOVE RODBRACING" on AB-01)

      const portalMeta: InspectedMemberInfo = {
        name: `5.50m Portal Bracing Frame (Detail-C) — ${bayLabel}`,
        category: `Sidewall Wind Bracing @ ${wallName}`,
        spec: 'Portal Cols: W=400×5, 2F=180×8 (H=5,500 mm, 350 mm inset) | Portal Beam: W=400×5, 2F=150×8 + 25mm Ø Rod X-Bracing Above',
        gridLocation: `${bayLabel} along ${wallName}`,
        drawingRef: 'J-100A246-AB-01, GA-05 & GA-06 (DETAIL-C)',
      };

      const pCol1 = createIBeamMember(
        new THREE.Vector3(px1, 0.075, z),
        new THREE.Vector3(px1, portalY, z),
        0.40,
        0.18,
        0.008,
        0.005,
        materials.portalSteel,
        'verticalColumn',
        portalMeta,
        interactables,
      );
      const pCol2 = createIBeamMember(
        new THREE.Vector3(px2, 0.075, z),
        new THREE.Vector3(px2, portalY, z),
        0.40,
        0.18,
        0.008,
        0.005,
        materials.portalSteel,
        'verticalColumn',
        portalMeta,
        interactables,
      );
      const pBeam = createIBeamMember(
        new THREE.Vector3(x1, portalY, z),
        new THREE.Vector3(x2, portalY, z),
        0.40,
        0.15,
        0.008,
        0.005,
        materials.portalSteel,
        'longitudinal',
        portalMeta,
        interactables,
      );
      groups.bracingAndPortals.add(pCol1, pCol2, pBeam);

      const r1 = createRodBetweenPoints(
        new THREE.Vector3(x1, portalY + 0.1, z),
        new THREE.Vector3(x2, topY, z),
        0.016,
        materials.bracingRod,
      );
      const r2 = createRodBetweenPoints(
        new THREE.Vector3(x2, portalY + 0.1, z),
        new THREE.Vector3(x1, topY, z),
        0.016,
        materials.bracingRod,
      );
      groups.bracingAndPortals.add(r1, r2);
    });

    // Roof Strut Tubes (STRUT 100x100x3.2)
    [zGridA, zGridB, zGridC].forEach((zStrut, sIdx) => {
      const yStrut = getMainRoofElevationAtZ(zStrut) - 0.52;
      const strut = createRodBetweenPoints(
        new THREE.Vector3(x1, yStrut, zStrut),
        new THREE.Vector3(x2, yStrut, zStrut),
        0.055,
        materials.strutTube,
        4,
      );
      strut.userData.memberInfo = {
        name: `Roof Compression Strut Tube (${['Grid A', 'Grid B', 'Grid C'][sIdx]})`,
        category: 'Roof Bracing System (GA-01)',
        spec: 'STRUT TUBE 100×100×3.2 THK with 12mm End Plate & 4–M20 Bolts (Gr. 8.8)',
        gridLocation: `${bayLabel}`,
        drawingRef: 'J-100A246-GA-01 (CONN DETAIL-A)',
      };
      interactables.push(strut);
      groups.bracingAndPortals.add(strut);
    });

    // Roof 25mm DIA Rod X-Bracing (Main Roof + Canopy Roof Bracing per GA-01)
    [
      [zGridA, zGridB],
      [zGridB, zGridC],
    ].forEach(([za, zb]) => {
      const ya = getMainRoofElevationAtZ(za) - 0.48;
      const yb = getMainRoofElevationAtZ(zb) - 0.48;
      groups.bracingAndPortals.add(
        createRodBetweenPoints(new THREE.Vector3(x1, ya, za), new THREE.Vector3(x2, yb, zb), 0.016, materials.bracingRod),
        createRodBetweenPoints(new THREE.Vector3(x2, ya, za), new THREE.Vector3(x1, yb, zb), 0.016, materials.bracingRod),
      );
    });

    // Canopy Roof 25mm DIA Rod X-Bracing in Bays 2-3, 6-7, 10-11 (shown on GA-01!)
    {
      const zc1 = zOuterC + 0.3;
      const zc2 = zCanopyEdge - 0.3;
      const yc1 = getCanopyRoofElevationAtZ(zc1) - 0.25;
      const yc2 = getCanopyRoofElevationAtZ(zc2) - 0.25;
      groups.bracingAndPortals.add(
        createRodBetweenPoints(new THREE.Vector3(x1, yc1, zc1), new THREE.Vector3(x2, yc2, zc2), 0.014, materials.bracingRod),
        createRodBetweenPoints(new THREE.Vector3(x2, yc1, zc1), new THREE.Vector3(x1, yc2, zc2), 0.014, materials.bracingRod),
      );
    }
  });

  // ============================================================================
  // 6. SECONDARY FRAMING: ROOF Z-PURLINS, CANOPY PURLINS, WALL Z-GIRTS & SAG RODS
  // ============================================================================
  const purlinZCoords: number[] = [];
  let curPurlinZ = zOuterA + 0.15;
  purlinZCoords.push(curPurlinZ);
  for (let i = 0; i < 11; i++) {
    curPurlinZ += 1.50;
    purlinZCoords.push(curPurlinZ);
  }
  curPurlinZ += 1.00;
  purlinZCoords.push(curPurlinZ);
  purlinZCoords.push(zOuterC - 0.15);

  const purlinGeo = new THREE.BoxGeometry(totalLengthOO - 0.1, 0.25, 0.075);

  purlinZCoords.forEach((pz, pIdx) => {
    const py = getMainRoofElevationAtZ(pz) - 0.18;
    const purlinMesh = new THREE.Mesh(purlinGeo, materials.purlinGalv);
    purlinMesh.position.set(0, py, pz);
    purlinMesh.rotation.x = slopeAngle;
    purlinMesh.userData.memberInfo = {
      name: `Main Roof Z-Purlin Line #${pIdx + 1}`,
      category: 'Secondary Roof Framing (GA-01)',
      spec: 'End Bays: END PURLIN 250Z2.0 | Interior Bays: INT PURLIN 250Z1.75 (700 mm overlap @ supports)',
      gridLocation: `Z = ${Math.round((pz - zGridA) * 1000)} mm from Grid A`,
      drawingRef: 'J-100A246-GA-01 & GA-03',
    };
    interactables.push(purlinMesh);
    groups.secondarySteel.add(purlinMesh);
  });

  // Sidewall 6.1m Canopy Z-Purlins (200Z1.8 per GA-01 — Grids 1 to 11 only, Bay 11-12 removed)
  const fswCanopyPurlinGeo = new THREE.BoxGeometry(fswCanopyLength - 0.1, 0.20, 0.075);
  const canopyPurlinZ = [
    zOuterC + 0.18,
    zOuterC + 1.68,
    zOuterC + 3.18,
    zOuterC + 4.68,
    zCanopyEdge - 0.15,
  ];
  canopyPurlinZ.forEach((cpz, cIdx) => {
    const cpy = getCanopyRoofElevationAtZ(cpz) - 0.17;
    const cpMesh = new THREE.Mesh(fswCanopyPurlinGeo, materials.purlinGalv);
    cpMesh.position.set(fswCanopyCenterX, cpy, cpz);
    cpMesh.rotation.x = slopeAngle;
    cpMesh.userData.memberInfo = {
      name: `Sidewall Canopy Z-Purlin Line #${cIdx + 1}`,
      category: 'Canopy Secondary Framing (GA-01)',
      spec: 'CANOPY PURLIN 200Z1.8 + 12mm DIA Sag Rods',
      gridLocation: 'Sidewall 6.1m Canopy (Grids 1 to 11)',
      drawingRef: 'J-100A246-GA-01',
    };
    interactables.push(cpMesh);
    groups.secondarySteel.add(cpMesh);
  });

  // Endwall 3.0m Canopy Z-Purlins (CANOPY PURLIN 200Z1.5 on GL-1 & GL-12 between Grid A & B per GA-01)
  const ewPurlinGeo = new THREE.BoxGeometry(0.065, 0.18, 8.5 + 0.645 - 0.08);
  [-1, 1].forEach((dirSign) => {
    const baseX = dirSign < 0 ? xOuterLeft : xOuterRight;
    [0.25, 1.50, 2.75].forEach((offX) => {
      const px = baseX + dirSign * offX;
      const py = 5.46 - offX * 0.1; // Below the 5.65 -> 5.35 sloped roof sheet
      const epm = new THREE.Mesh(ewPurlinGeo, materials.purlinGalv);
      epm.position.set(px, py, (zOuterA + zGridB) / 2);
      groups.secondarySteel.add(epm);
    });
  });

  // 2 Rows of 12mm DIA Sag Rods per Bay across Roof Purlins
  for (let b = 0; b < 11; b++) {
    const bx1 = gridsX[b].xWorldM;
    const bx2 = gridsX[b + 1].xWorldM;
    const third = (bx2 - bx1) / 3;
    [bx1 + third, bx1 + third * 2].forEach((sx) => {
      const sagStart = new THREE.Vector3(sx, getMainRoofElevationAtZ(zOuterA + 0.15) - 0.18, zOuterA + 0.15);
      const sagEnd = new THREE.Vector3(sx, getMainRoofElevationAtZ(zOuterC - 0.15) - 0.18, zOuterC - 0.15);
      groups.secondarySteel.add(createRodBetweenPoints(sagStart, sagEnd, 0.008, materials.purlinGalv, 6));
    });
  }

  // Sidewall Z-Girts above 3,000 mm Brick Wall (100 + 1050 + 1050 + 1500 + 1500 + 1500 + BAL per GA-03..06)
  const girtGeoSide = new THREE.BoxGeometry(totalLengthOO - 0.1, 0.075, 0.20);
  [3.10, 4.15, 5.20, 6.70, 8.20, 9.70, 11.05].forEach((gy) => {
    const gm = new THREE.Mesh(girtGeoSide, materials.purlinGalv);
    gm.position.set(0, gy, zOuterA + 0.14);
    groups.secondarySteel.add(gm);
  });

  [3.10, 4.15, 5.20, 6.70, 8.20, 9.25].forEach((gy) => {
    const gm = new THREE.Mesh(girtGeoSide, materials.purlinGalv);
    gm.position.set(0, gy, zOuterC - 0.14);
    groups.secondarySteel.add(gm);
  });

  [xOuterLeft + 0.14, xOuterRight - 0.14].forEach((ex) => {
    [3.10, 4.15, 5.20, 6.70, 8.20, 9.30].forEach((gy) => {
      const egGeo = new THREE.BoxGeometry(0.20, 0.075, totalWidthOO - 0.1);
      const egMesh = new THREE.Mesh(egGeo, materials.purlinGalv);
      egMesh.position.set(ex, gy, 0);
      groups.secondarySteel.add(egMesh);
    });
  });

  // ============================================================================
  // 7. EXACT REVISED OPENINGS DEFINITIONS (FSW & BSW SHUTTERS + ENDWALL F.O. + 26 LOUVERS)
  // ============================================================================
  // 7A. 3 Back Sidewall Framed Openings (F.O. 4.5m x 4.0m) in Bays 2-3 (idx 1), 7-8 (idx 6), and 10-11 (idx 9) (AB-01 & GA-05)
  const sidewallFoBays = [
    { bayIdx: 1, w: 4.5, h: 4.0, label: 'BSW F.O. #1 (Bay 2–3: 4.5M × 4.0M)' },
    { bayIdx: 6, w: 4.5, h: 4.0, label: 'BSW F.O. #2 (Bay 7–8: 4.5M × 4.0M)' },
    { bayIdx: 9, w: 4.5, h: 4.0, label: 'BSW F.O. #3 (Bay 10–11: 4.5M × 4.0M)' },
  ];

  // Shifted Front Sidewall (FSW @GL-C) 4.5m x 4.5m Rolling Shutters & Ramps in Bays 2-3 (idx 1), 7-8 (idx 6), and 10-11 (idx 9)
  // (Old bays 1-2, 4-5, 8-9, and 11-12 are completely removed and patched with continuous brick dado & PPGI sheeting)
  const fswShutterBays = [
    { bayIdx: 1, w: 4.5, h: 4.5, label: 'FSW Rolling Shutter RS-01 (Bay 2–3: 4.5M × 4.5M)' },
    { bayIdx: 6, w: 4.5, h: 4.5, label: 'FSW Rolling Shutter RS-02 (Bay 7–8: 4.5M × 4.5M)' },
    { bayIdx: 9, w: 4.5, h: 4.5, label: 'FSW Rolling Shutter RS-03 (Bay 10–11: 4.5M × 4.5M)' },
  ];

  // Collect cutout rectangles for Back Sidewall (GL-A), Front Sidewall (GL-C), Left Endwall (GL-01), Right Endwall (GL-12)
  const cutoutsGLA: Array<{ x1: number; x2: number; y1: number; y2: number }> = [];
  const cutoutsGLC: Array<{ x1: number; x2: number; y1: number; y2: number }> = [];
  const cutoutsLEW: Array<{ z1: number; z2: number; y1: number; y2: number }> = [];
  const cutoutsREW: Array<{ z1: number; z2: number; y1: number; y2: number }> = [];

  // Helper to place an ISMC 200 Framed Opening + Corrugated Rolling Shutter + Concrete Entry Ramp
  const addFramedOpeningShutter = (
    x: number,
    yHeight: number,
    z: number,
    width: number,
    rotY: number,
    label: string,
    gridLoc: string,
    drawingRef: string,
    rampOutwardDirZ = 0, // +1 for FSW (+Z), -1 for BSW (-Z), 0 if endwall ramp handled separately
    rampOutwardDirX = 0, // -1 for LEW (-X), +1 for REW (+X)
  ) => {
    const foGroup = new THREE.Group();
    foGroup.position.set(x, 0, z);
    foGroup.rotation.y = rotY;

    // ISMC 200 Steel Door Jambs (Left & Right) + ISMC 200 Header Channel (GA-04 & GA-05 Details A, B, C, D)
    const jambGeo = new THREE.BoxGeometry(0.14, yHeight + 0.1, 0.24);
    const jambL = new THREE.Mesh(jambGeo, materials.portalSteel);
    jambL.position.set(-width / 2 - 0.07, yHeight / 2, 0);
    const jambR = new THREE.Mesh(jambGeo, materials.portalSteel);
    jambR.position.set(width / 2 + 0.07, yHeight / 2, 0);

    const headerGeo = new THREE.BoxGeometry(width + 0.36, 0.20, 0.26);
    const header = new THREE.Mesh(headerGeo, materials.portalSteel);
    header.position.set(0, yHeight + 0.10, 0);

    // Corrugated Rolling Shutter Curtain & Hood
    const curtain = new THREE.Mesh(
      new THREE.BoxGeometry(width, yHeight, 0.10),
      materials.rollingShutter,
    );
    curtain.position.set(0, yHeight / 2, 0);

    const hood = new THREE.Mesh(
      new THREE.BoxGeometry(width + 0.28, 0.34, 0.34),
      materials.trimRoyalBlue,
    );
    hood.position.set(0, yHeight + 0.22, 0);

    foGroup.add(jambL, jambR, header, curtain, hood);

    // Concrete Entry Ramp in front of the Rolling Shutter Opening
    if (rampOutwardDirZ !== 0 || rampOutwardDirX !== 0) {
      const rampLen = 2.20;
      const rampW = width + 0.30;
      const rampGeo = new THREE.BoxGeometry(rampW, 0.16, rampLen);
      const rampMesh = new THREE.Mesh(rampGeo, materials.pedestalConcrete);
      // In local foGroup space, local +Z points outward when rotY = 0 (FSW) or rotY = Math.PI/2 (REW)
      const localZSign = rampOutwardDirZ !== 0 ? rampOutwardDirZ : rampOutwardDirX;
      rampMesh.position.set(0, 0.02, localZSign * (rampLen / 2 + 0.12));
      rampMesh.rotation.x = localZSign * 0.045;
      rampMesh.receiveShadow = true;
      foGroup.add(rampMesh);

      // Yellow safety curb strips on both edges of the concrete entry ramp
      [-rampW / 2 + 0.06, rampW / 2 - 0.06].forEach((cx) => {
        const curbMesh = new THREE.Mesh(
          new THREE.BoxGeometry(0.10, 0.18, rampLen),
          materials.handrailYellow,
        );
        curbMesh.position.set(cx, 0.03, localZSign * (rampLen / 2 + 0.12));
        curbMesh.rotation.x = localZSign * 0.045;
        foGroup.add(curbMesh);
      });
    }

    const foMeta: InspectedMemberInfo = {
      name: `Framed Opening ${label}`,
      category: 'ISMC 200 Framed Opening, Rolling Shutter & Ramp',
      spec: `Size: ${Math.round(width * 1000)} × ${Math.round(yHeight * 1000)} mm | Jambs & Header: ISMC 200 + Sloped Concrete Entry Ramp`,
      gridLocation: gridLoc,
      drawingRef,
    };
    foGroup.traverse((c) => {
      if ((c as THREE.Mesh).isMesh) {
        c.userData.memberInfo = foMeta;
        interactables.push(c);
      }
    });
    groups.openingsAndAccessories.add(foGroup);
  };

  // Place 3 Back Sidewall F.O. (4.5m x 4.0m) in Bays 2-3, 7-8, 10-11 along GL-A
  sidewallFoBays.forEach(({ bayIdx, w, h, label }) => {
    const midX = (gridsX[bayIdx].xWorldM + gridsX[bayIdx + 1].xWorldM) / 2;
    cutoutsGLA.push({ x1: midX - w / 2, x2: midX + w / 2, y1: 0, y2: h });
    addFramedOpeningShutter(
      midX,
      h,
      zOuterA,
      w,
      0,
      label,
      `Sidewall GL-A — Bay ${bayIdx + 1} (Grid ${bayIdx + 1} to ${bayIdx + 2})`,
      'J-100A246-AB-01 & GA-05',
      -1,
      0,
    );
  });

  // Place 3 Shifted FSW 4.5m x 4.5m Rolling Shutters & Concrete Ramps in Bays 2-3, 7-8, 10-11 along GL-C
  fswShutterBays.forEach(({ bayIdx, w, h, label }) => {
    const midX = (gridsX[bayIdx].xWorldM + gridsX[bayIdx + 1].xWorldM) / 2;
    cutoutsGLC.push({ x1: midX - w / 2, x2: midX + w / 2, y1: 0, y2: h });
    addFramedOpeningShutter(
      midX,
      h,
      zOuterC,
      w,
      0,
      label,
      `Front Sidewall GL-C — Bay ${bayIdx + 1} (Grid ${bayIdx + 1} to ${bayIdx + 2})`,
      'J-100A246-GA-06',
      1,
      0,
    );
  });

  // Place Left Endwall (@GL-01) F.O. 4.5m x 4.0m centered between Grid A (-8.5m) & Grid B (0m) -> Z = -4.25m
  cutoutsLEW.push({ z1: -4.25 - 2.25, z2: -4.25 + 2.25, y1: 0, y2: 4.0 });
  addFramedOpeningShutter(
    xOuterLeft,
    4.0,
    -4.25,
    4.5,
    Math.PI / 2,
    'LEW @GL-01 (F.O. 4.5M × 4.0M under 3.0m Canopy)',
    'Left Endwall @GL-01 (Centered between Grid A & Grid B: 2000+4500+2000 = 8500 mm)',
    'J-100A246-AB-01 & GA-04',
    0,
    -1,
  );

  // Place Right Endwall (@GL-12) F.O. 4.5m x 4.5m centered between Grid A (-8.5m) & Grid B (0m) -> Z = -4.25m
  cutoutsREW.push({ z1: -4.25 - 2.25, z2: -4.25 + 2.25, y1: 0, y2: 4.5 });
  addFramedOpeningShutter(
    xOuterRight,
    4.5,
    -4.25,
    4.5,
    Math.PI / 2,
    'REW @GL-12 (F.O. 4.5M × 4.5M under 3.0m Canopy)',
    'Right Endwall @GL-12 (Centered between Grid A & Grid B: 2000+4500+2000 = 8500 mm)',
    'J-100A246-AB-01 & GA-04',
    0,
    1,
  );

  // 7B. 26 Nos. Industrial Wall Louvers (1,000 mm H × 2,000 mm W, 200C 2.0 Frame — GA-03, GA-04, GA-05, GA-06)
  const louverW = 2.0; // 2,000 mm wide
  const louverH = 1.0; // 1,000 mm high
  const louverYCenter = 7.45; // Upper wall zone between girts at +6.70m and +8.20m

  const createLouverAssembly = (
    x: number,
    y: number,
    z: number,
    rotY: number,
    wallLabel: string,
    locDesc: string,
  ) => {
    const lGroup = new THREE.Group();
    lGroup.position.set(x, y, z);
    lGroup.rotation.y = rotY;

    // 200C 2.0 Outer Frame
    const frameMesh = new THREE.Mesh(
      new THREE.BoxGeometry(louverW + 0.12, louverH + 0.12, 0.16),
      materials.trimRoyalBlue,
    );
    const coreMesh = new THREE.Mesh(
      new THREE.BoxGeometry(louverW - 0.04, louverH - 0.04, 0.18),
      materials.louverSlats,
    );
    lGroup.add(frameMesh, coreMesh);

    // 6 Angled Louver Blades + Center Mullion (matching LOUVER ELEVATION 1000 x 2000mm on GA-05 & GA-06)
    const bladeGeo = new THREE.BoxGeometry(louverW - 0.08, 0.03, 0.22);
    bladeGeo.rotateX(0.35);
    for (let b = -2; b <= 2; b++) {
      const blade = new THREE.Mesh(bladeGeo, materials.purlinGalv);
      blade.position.y = b * 0.18;
      lGroup.add(blade);
    }
    const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.05, louverH, 0.21), materials.trimRoyalBlue);
    lGroup.add(mullion);

    const lMeta: InspectedMemberInfo = {
      name: `Industrial Wall Louver (1.0m × 2.0m) — ${wallLabel}`,
      category: 'Wall Ventilation Louvers (GA-03 to GA-06)',
      spec: 'Size: 1,000 × 2,000 mm | Subframe: 200C 2.0 Cold-Formed Channel + Insect Screen (Total 26 Nos.)',
      gridLocation: locDesc,
      drawingRef: 'J-100A246-GA-04, GA-05 & GA-06',
    };
    lGroup.traverse((c) => {
      if ((c as THREE.Mesh).isMesh) {
        c.userData.memberInfo = lMeta;
        interactables.push(c);
      }
    });
    groups.openingsAndAccessories.add(lGroup);
  };

  // 11 Louvers on Sidewall GL-A + 11 Louvers on Sidewall GL-C (1 centered in each bay 1..11)
  for (let b = 0; b < 11; b++) {
    const midX = (gridsX[b].xWorldM + gridsX[b + 1].xWorldM) / 2;
    cutoutsGLA.push({
      x1: midX - louverW / 2,
      x2: midX + louverW / 2,
      y1: louverYCenter - louverH / 2,
      y2: louverYCenter + louverH / 2,
    });
    createLouverAssembly(
      midX,
      louverYCenter,
      zOuterA,
      0,
      `GL-A Bay ${b + 1}`,
      `Sidewall @GL-A — Bay ${b + 1} (Grid ${b + 1}–${b + 2})`,
    );

    cutoutsGLC.push({
      x1: midX - louverW / 2,
      x2: midX + louverW / 2,
      y1: louverYCenter - louverH / 2,
      y2: louverYCenter + louverH / 2,
    });
    createLouverAssembly(
      midX,
      louverYCenter,
      zOuterC,
      0,
      `GL-C Bay ${b + 1}`,
      `Sidewall @GL-C — Bay ${b + 1} (Grid ${b + 1}–${b + 2})`,
    );
  }

  // 2 Louvers on Left Endwall (@GL-01) + 2 Louvers on Right Endwall (@GL-12) at Z = -4.25m (A-B) & Z = +4.25m (B-C)
  [-4.25, 4.25].forEach((lz, lIdx) => {
    const spanName = lIdx === 0 ? 'Span A–B' : 'Span B–C';
    cutoutsLEW.push({
      z1: lz - louverW / 2,
      z2: lz + louverW / 2,
      y1: louverYCenter - louverH / 2,
      y2: louverYCenter + louverH / 2,
    });
    createLouverAssembly(
      xOuterLeft,
      louverYCenter,
      lz,
      Math.PI / 2,
      `LEW @GL-01 (${spanName})`,
      `Left Endwall @GL-01 — ${spanName}`,
    );

    cutoutsREW.push({
      z1: lz - louverW / 2,
      z2: lz + louverW / 2,
      y1: louverYCenter - louverH / 2,
      y2: louverYCenter + louverH / 2,
    });
    createLouverAssembly(
      xOuterRight,
      louverYCenter,
      lz,
      Math.PI / 2,
      `REW @GL-12 (${spanName})`,
      `Right Endwall @GL-12 — ${spanName}`,
    );
  });

  // 7C. Steel Cage Ladder at Grid A-12 (BSW / REW Corner — AB-01 & GA-02)
  {
    const ladderGroup = new THREE.Group();
    const lx = xGrid12 - 0.85;
    const lz = zOuterA - 0.38;
    const ladderH = 11.85;

    const stileGeo = new THREE.CylinderGeometry(0.025, 0.025, ladderH, 8);
    const stileL = new THREE.Mesh(stileGeo, materials.cageLadderYellow);
    stileL.position.set(lx - 0.25, ladderH / 2, lz);
    const stileR = new THREE.Mesh(stileGeo, materials.cageLadderYellow);
    stileR.position.set(lx + 0.25, ladderH / 2, lz);
    ladderGroup.add(stileL, stileR);

    const rungGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.50, 6);
    rungGeo.rotateZ(Math.PI / 2);
    for (let ry = 0.3; ry <= ladderH - 0.2; ry += 0.35) {
      const rung = new THREE.Mesh(rungGeo, materials.cageLadderYellow);
      rung.position.set(lx, ry, lz);
      ladderGroup.add(rung);
    }

    const hoopGeo = new THREE.TorusGeometry(0.38, 0.018, 6, 18, Math.PI * 1.3);
    hoopGeo.rotateX(Math.PI / 2);
    hoopGeo.rotateY(Math.PI * 0.85);
    for (let hy = 2.5; hy <= ladderH; hy += 0.95) {
      const hoop = new THREE.Mesh(hoopGeo, materials.cageLadderYellow);
      hoop.position.set(lx, hy, lz - 0.32);
      ladderGroup.add(hoop);
    }

    ladderGroup.traverse((c) => {
      if ((c as THREE.Mesh).isMesh) {
        c.userData.memberInfo = {
          name: 'Roof Access Steel Cage Ladder (@Grid A-12)',
          category: 'Roof Access & Safety (AB-01 & GA-02)',
          spec: 'Safety Yellow Steel Cage Ladder from FFL ±0.00m to +11,315 mm',
          gridLocation: 'Grid A-12 (BSW / REW Corner)',
          drawingRef: 'J-100A246-AB-01 & GA-02',
        };
        interactables.push(c);
      }
    });
    groups.openingsAndAccessories.add(ladderGroup);
  }

  // ============================================================================
  // 8. REVISED 3,000 MM BRICK MASONRY DADO WALL WITH EXACT CUTOUTS (AB-01, GA-03..06)
  // ============================================================================
  const brickH = 3.00; // Revised to 3,000 mm ("3M B/W & ABOVE SHEETING")
  const brickThk = 0.23;
  textures.brickTex.repeat.set(8, 2.5);

  buildSegmentedWallAlongX(
    xOuterLeft,
    xOuterRight,
    0,
    brickH,
    zOuterA + brickThk / 2,
    brickThk,
    cutoutsGLA,
    materials.brickMasonry,
    {
      name: 'Sidewall @GL-A 3.00m Brick Dado Wall ("3M B/W & ABOVE SHEETING")',
      category: 'Masonry Perimeter Wall (AB-01 & GA-05)',
      spec: '230 mm Thk. Brick Masonry Wall up to +3,000 mm from FFL ±0.00m with Cutouts for 3 Nos. 4.5×4.0m Framed Openings',
      gridLocation: 'Grid A (Grids 1 to 12, Length 88,275 mm)',
      drawingRef: 'J-100A246-AB-01 & GA-05',
    },
    groups.brickWall,
    interactables,
  );

  buildSegmentedWallAlongX(
    xOuterLeft,
    xOuterRight,
    0,
    brickH,
    zOuterC - brickThk / 2,
    brickThk,
    cutoutsGLC,
    materials.brickMasonry,
    {
      name: 'Sidewall @GL-C 3.00m Brick Dado Wall ("3M B/W & ABOVE SHEETING")',
      category: 'Masonry Perimeter Wall (AB-01 & GA-06)',
      spec: '230 mm Thk. Brick Masonry Wall up to +3,000 mm from FFL ±0.00m + 100 mm PEB Drip Trim Overlap',
      gridLocation: 'Grid C (Grids 1 to 12, Length 88,275 mm)',
      drawingRef: 'J-100A246-AB-01 & GA-06',
    },
    groups.brickWall,
    interactables,
  );

  buildSegmentedEndwallAlongZ(
    zOuterA,
    zOuterC,
    0,
    () => brickH,
    xOuterLeft + brickThk / 2,
    brickThk,
    cutoutsLEW,
    materials.brickMasonry,
    {
      name: 'Left Endwall (@GL-01) 3.00m Brick Dado Wall',
      category: 'Masonry Perimeter Wall (AB-01 & GA-04)',
      spec: '230 mm Thk. Brick Masonry Wall up to +3,000 mm with Cutout for 4.5×4.0m Framed Opening',
      gridLocation: 'Left Endwall @GL-01 (Span 18,290 mm O/O)',
      drawingRef: 'J-100A246-AB-01 & GA-04',
    },
    groups.brickWall,
    interactables,
  );

  buildSegmentedEndwallAlongZ(
    zOuterA,
    zOuterC,
    0,
    () => brickH,
    xOuterRight - brickThk / 2,
    brickThk,
    cutoutsREW,
    materials.brickMasonry,
    {
      name: 'Right Endwall (@GL-12) 3.00m Brick Dado Wall',
      category: 'Masonry Perimeter Wall (AB-01 & GA-04)',
      spec: '230 mm Thk. Brick Masonry Wall up to +3,000 mm with Cutout for 4.5×4.5m Framed Opening',
      gridLocation: 'Right Endwall @GL-12 (Span 18,290 mm O/O)',
      drawingRef: 'J-100A246-AB-01 & GA-04',
    },
    groups.brickWall,
    interactables,
  );

  // ============================================================================
  // 9. PPGI METAL WALL CLADDING (WITH CUTOUTS), CANOPY SHEETING, TRIMS & DOWNSPOUTS
  // ============================================================================
  const claddingBottomY = 2.90; // Overlaps 3,000mm brick wall by 100mm per Section B (GA-04, GA-05, GA-06)
  textures.claddingTex.repeat.set(12, 1);

  buildSegmentedWallAlongX(
    xOuterLeft,
    xOuterRight,
    claddingBottomY,
    11.315,
    zOuterA - 0.02,
    0.04,
    cutoutsGLA,
    materials.wallCladdingPpgi,
    {
      name: 'Sidewall PPGI Cladding (@GL-A)',
      category: 'Wall Cladding Envelope (GA-05)',
      spec: 'PPGI 1000 mm Width, 0.50 mm Thk. from +2,900 mm (100 mm Drip Trim overlap over 3.0m B/W) to +11,315 mm with Cutouts for F.O. & 11 Louvers',
      gridLocation: 'Grid A (Full 88,275 mm Length)',
      drawingRef: 'J-100A246-GA-05',
    },
    groups.cladding,
    interactables,
  );

  buildSegmentedWallAlongX(
    xOuterLeft,
    xOuterRight,
    claddingBottomY,
    9.485,
    zOuterC + 0.02,
    0.04,
    cutoutsGLC,
    materials.wallCladdingPpgi,
    {
      name: 'Sidewall PPGI Cladding (@GL-C)',
      category: 'Wall Cladding Envelope (GA-06)',
      spec: 'PPGI 1000 mm Width, 0.50 mm Thk. from +2,900 mm to +9,485 mm with Cutouts for Shutters & 11 Louvers',
      gridLocation: 'Grid C (Full 88,275 mm Length)',
      drawingRef: 'J-100A246-GA-06',
    },
    groups.cladding,
    interactables,
  );

  buildSegmentedEndwallAlongZ(
    zOuterA,
    zOuterC,
    claddingBottomY,
    (z) => getMainRoofElevationAtZ(z),
    xOuterLeft - 0.02,
    0.04,
    cutoutsLEW,
    materials.wallCladdingPpgi,
    {
      name: 'Left Endwall PPGI Cladding (@GL-01)',
      category: 'Endwall Cladding Envelope (GA-04)',
      spec: 'PPGI 1000 mm Width, 0.50 mm Thk. with Cutouts for 4.5×4.0m Framed Opening & 2 Louvers (1.0×2.0m)',
      gridLocation: 'Grid 1 (LEW)',
      drawingRef: 'J-100A246-GA-04',
    },
    groups.cladding,
    interactables,
  );

  buildSegmentedEndwallAlongZ(
    zOuterA,
    zOuterC,
    claddingBottomY,
    (z) => getMainRoofElevationAtZ(z),
    xOuterRight + 0.02,
    0.04,
    cutoutsREW,
    materials.wallCladdingPpgi,
    {
      name: 'Right Endwall PPGI Cladding (@GL-12)',
      category: 'Endwall Cladding Envelope (GA-04)',
      spec: 'PPGI 1000 mm Width, 0.50 mm Thk. with Cutouts for 4.5×4.5m Framed Opening & 2 Louvers (1.0×2.0m)',
      gridLocation: 'Grid 12 (REW)',
      drawingRef: 'J-100A246-GA-04',
    },
    groups.cladding,
    interactables,
  );

  // Sidewall 6.1m Canopy Vertical Fascia Cladding (1,500 mm drop) & End Cheeks (Grids 1 to 11 only; Bay 11-12 removed)
  const canopyTipY = getCanopyRoofElevationAtZ(zCanopyEdge);
  const canopyFasciaH = 1.50;
  const canopyFasciaMesh = new THREE.Mesh(
    new THREE.BoxGeometry(fswCanopyLength, canopyFasciaH, 0.04),
    materials.wallCladdingPpgi,
  );
  canopyFasciaMesh.position.set(fswCanopyCenterX, canopyTipY - canopyFasciaH / 2, zCanopyEdge);
  groups.cladding.add(canopyFasciaMesh);

  // Bottom Royal Blue fascia trim along FSW Canopy (Grids 1 to 11)
  const fswFasciaBotTrim = new THREE.Mesh(
    new THREE.BoxGeometry(fswCanopyLength + 0.08, 0.14, 0.12),
    materials.trimRoyalBlue,
  );
  fswFasciaBotTrim.position.set(fswCanopyCenterX, canopyTipY - canopyFasciaH, zCanopyEdge + 0.02);
  groups.cladding.add(fswFasciaBotTrim);

  [xOuterLeft - 0.02, xGrid11 + 0.02].forEach((cx) => {
    const yWallTop = getCanopyRoofElevationAtZ(zOuterC);
    const yWallBot = canopyTipY - canopyFasciaH;
    const cVerts = new Float32Array([
      cx, yWallBot, zOuterC,
      cx, yWallBot, zCanopyEdge,
      cx, canopyTipY, zCanopyEdge,
      cx, yWallTop, zOuterC,
    ]);
    const cGeo = new THREE.BufferGeometry();
    cGeo.setAttribute('position', new THREE.BufferAttribute(cVerts, 3));
    cGeo.setIndex([0, 1, 2, 0, 2, 3]);
    cGeo.computeVertexNormals();
    const cMesh = new THREE.Mesh(cGeo, materials.wallCladdingPpgi);
    groups.cladding.add(cMesh);

    // Royal blue rake & bottom cheek trim on FSW canopy ends (at Grid 1 and Grid 11)
    const cheekRakeLen = Math.hypot(canopyWidthM, yWallTop - canopyTipY);
    const cheekRake = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.16, cheekRakeLen + 0.1),
      materials.trimRoyalBlue,
    );
    cheekRake.position.set(cx, (yWallTop + canopyTipY) / 2 + 0.02, zOuterC + canopyWidthM / 2);
    cheekRake.rotation.x = slopeAngle;
    const cheekBot = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.12, canopyWidthM + 0.1),
      materials.trimRoyalBlue,
    );
    cheekBot.position.set(cx, yWallBot, zOuterC + canopyWidthM / 2);
    groups.cladding.add(cheekRake, cheekBot);
  });

  // Outside Corner Trims, Rake Trims, and Continuous Drip Trim at Y = 2.95m (for 3.00m Brick Wall)
  [
    [xOuterLeft, zOuterA, 11.315],
    [xOuterRight, zOuterA, 11.315],
    [xOuterLeft, zOuterC, 9.485],
    [xOuterRight, zOuterC, 9.485],
  ].forEach(([cx, cz, topY]) => {
    const trimH = topY - claddingBottomY;
    const cornerTrim = new THREE.Mesh(new THREE.BoxGeometry(0.32, trimH, 0.32), materials.trimRoyalBlue);
    cornerTrim.position.set(cx, claddingBottomY + trimH / 2, cz);
    groups.cladding.add(cornerTrim);
  });

  [xOuterLeft, xOuterRight].forEach((rx) => {
    const rakeGeo = new THREE.BoxGeometry(0.34, 0.24, Math.hypot(totalWidthOO, 1.83) + 0.2);
    const rakeMesh = new THREE.Mesh(rakeGeo, materials.trimRoyalBlue);
    rakeMesh.position.set(rx, (11.315 + 9.485) / 2 + 0.02, 0);
    rakeMesh.rotation.x = slopeAngle;
    groups.cladding.add(rakeMesh);
  });

  const dripSideGeo = new THREE.BoxGeometry(totalLengthOO + 0.1, 0.12, 0.12);
  const dripA = new THREE.Mesh(dripSideGeo, materials.trimRoyalBlue);
  dripA.position.set(0, 2.95, zOuterA - 0.04);
  const dripC = new THREE.Mesh(dripSideGeo, materials.trimRoyalBlue);
  dripC.position.set(0, 2.95, zOuterC + 0.04);
  groups.cladding.add(dripA, dripC);

  // Eaves Gutters & Downspouts (FSW Canopy Gutter spans Grids 1 to 11 only)
  const gutterGeo = new THREE.BoxGeometry(totalLengthOO + 0.2, 0.22, 0.22);
  const mainGutter = new THREE.Mesh(gutterGeo, materials.trimRoyalBlue);
  mainGutter.position.set(0, 9.485, zOuterC + 0.14);
  const canopyGutterGeo = new THREE.BoxGeometry(fswCanopyLength + 0.15, 0.22, 0.22);
  const canopyGutter = new THREE.Mesh(canopyGutterGeo, materials.trimRoyalBlue);
  canopyGutter.position.set(fswCanopyCenterX, canopyTipY - 0.05, zCanopyEdge + 0.12);
  groups.cladding.add(mainGutter, canopyGutter);

  gridsX.forEach((gx, idx) => {
    const dsMainH = 9.485;
    const dsMain = new THREE.Mesh(new THREE.BoxGeometry(0.11, dsMainH, 0.11), materials.gutterGalv);
    dsMain.position.set(gx.xWorldM, dsMainH / 2, zOuterC + 0.14);
    dsMain.userData.memberInfo = {
      name: `Main Eave Downspout @ Grid C-${gx.label}`,
      category: 'Roof Drainage System (GA-02)',
      spec: 'SQ. 110 BOX Downspout (At Every Grid 1 to 12) + 0.5mm Galvalume Eaves Gutter',
      gridLocation: `Grid C-${gx.label}`,
      drawingRef: 'J-100A246-GA-02',
    };
    interactables.push(dsMain);
    groups.cladding.add(dsMain);

    if (idx <= 10) {
      const dsCanopyH = canopyTipY;
      const dsCanopy = new THREE.Mesh(new THREE.BoxGeometry(0.11, dsCanopyH, 0.11), materials.gutterGalv);
      dsCanopy.position.set(gx.xWorldM, dsCanopyH / 2, zCanopyEdge + 0.12);
      groups.cladding.add(dsCanopy);
    }
  });

  // ============================================================================
  // 10. ROOF SHEETING (MAIN + 6.1M CANOPY [GRIDS 1-11] + TWO 3.0M ENDWALL CANOPIES), SKYLIGHTS & 11 TURBO VENTS
  // ============================================================================
  const slopeLen = Math.hypot(totalWidthOO, 11.315 - 9.485);
  textures.roofTex.repeat.set(60, 12);

  const mainRoofGeo = new THREE.BoxGeometry(totalLengthOO, 0.045, slopeLen);
  const mainRoofMesh = new THREE.Mesh(mainRoofGeo, materials.roofGalvalume);
  mainRoofMesh.position.set(0, (11.315 + 9.485) / 2 + 0.04, 0);
  mainRoofMesh.rotation.x = slopeAngle;
  mainRoofMesh.castShadow = true;
  mainRoofMesh.receiveShadow = true;
  mainRoofMesh.userData.memberInfo = {
    name: 'Main Mono-Slope Roof Sheeting (BG 1000 Width, 0.47mm Thk.)',
    category: 'Roof Sheeting Plan (GA-02)',
    spec: 'Bare Galvalume 0.47 mm Thk., 1000 mm Width | 1:10 Slope from +11,315 mm to +9,485 mm',
    gridLocation: 'Full Main Roof (88,275 mm × 18,290 mm)',
    drawingRef: 'J-100A246-GA-02',
  };
  interactables.push(mainRoofMesh);
  groups.roofSheeting.add(mainRoofMesh);

  // 6,100 mm Sidewall Canopy Roof Sheeting (Grids 1 to 11 only; Bay 11-12 removed)
  const canopySlopeLen = Math.hypot(canopyWidthM, canopyWidthM * 0.1);
  const canopyRoofGeo = new THREE.BoxGeometry(fswCanopyLength, 0.04, canopySlopeLen);
  const canopyRoofMesh = new THREE.Mesh(canopyRoofGeo, materials.roofGalvalume);
  const canopyMidZ = zOuterC + canopyWidthM / 2;
  canopyRoofMesh.position.set(fswCanopyCenterX, getCanopyRoofElevationAtZ(canopyMidZ) + 0.03, canopyMidZ);
  canopyRoofMesh.rotation.x = slopeAngle;
  canopyRoofMesh.castShadow = true;
  canopyRoofMesh.receiveShadow = true;
  canopyRoofMesh.userData.memberInfo = {
    name: 'Sidewall Canopy Roof Sheeting (6,100 mm Wide — Grids 1 to 11)',
    category: 'Roof Sheeting Plan (GA-02)',
    spec: '0.47 mm Galvalume Canopy Roof Panel over 200Z1.8 Purlins (1:10 Slope, Grids 1 to 11)',
    gridLocation: 'Sidewall Canopy (Grids 1 to 11)',
    drawingRef: 'J-100A246-GA-02 & GA-03',
  };
  interactables.push(canopyRoofMesh);
  groups.roofSheeting.add(canopyRoofMesh);

  // Two 3,000 mm Wide Endwall Canopies (Grid A to Grid B) at LEW (@GL-01) and REW (@GL-12)
  // Fully covered with solid PPGI metal roof sheeting, underside soffit liner, vertical fascia cladding, closed side cheeks & royal blue trims
  const ewCanZ1 = zOuterA;        // -9.145 m (Grid A outer steel line)
  const ewCanZ2 = zGridB + 0.18;  // +0.180 m (Grid B line)
  const ewCanLenZ = ewCanZ2 - ewCanZ1;
  const ewCanMidZ = (ewCanZ1 + ewCanZ2) / 2;
  const ewCanSlopeW = Math.hypot(endwallCanopyWidthM, 0.30);
  const ewWallTopY = 5.68;        // Canopy roof height at endwall
  const ewTipTopY = 5.38;         // Canopy roof height at 3.0m outer tip (1:10 slope)
  const ewFasciaBotY = 4.55;      // Bottom of vertical PPGI fascia & side cheeks
  const ewFasciaH = ewTipTopY - ewFasciaBotY;

  [
    { xWall: xOuterLeft, dirSign: -1, label: 'Left Endwall 3,000 mm Canopy (@GL-01, Grid A to B)' },
    { xWall: xOuterRight, dirSign: 1, label: 'Right Endwall 3,000 mm Canopy (@GL-12, Grid A to B)' },
  ].forEach(({ xWall, dirSign, label }) => {
    const midX = xWall + dirSign * (endwallCanopyWidthM / 2);
    const tipX = xWall + dirSign * endwallCanopyWidthM;

    // 1. Solid Metal Deck Roof Sheeting (Top) + PPGI Soffit Cladding (Underside)
    const ewRoof = new THREE.Mesh(
      new THREE.BoxGeometry(ewCanSlopeW, 0.055, ewCanLenZ),
      materials.roofGalvalume,
    );
    // Note: -dirSign * slopeAngle tilts the outer tip downward away from the wall
    ewRoof.position.set(midX, (ewWallTopY + ewTipTopY) / 2 + 0.03, ewCanMidZ);
    ewRoof.rotation.z = -dirSign * slopeAngle;
    ewRoof.castShadow = true;
    ewRoof.receiveShadow = true;
    ewRoof.userData.memberInfo = {
      name: label,
      category: 'Endwall Canopy Sheeting & Trim (Grid A to B)',
      spec: '3,000 mm Wide × 9,145 mm Long Fully Clad PPGI Canopy | 5,000 mm Clear Height | 1:10 Slope + Royal Blue Trim',
      gridLocation: label.includes('Left') ? 'Left Endwall @GL-01 (Grid A to B)' : 'Right Endwall @GL-12 (Grid A to B)',
      drawingRef: 'J-100A246-GA-02, GA-03 & GA-04',
    };
    interactables.push(ewRoof);
    groups.roofSheeting.add(ewRoof);

    const ewSoffit = new THREE.Mesh(
      new THREE.BoxGeometry(ewCanSlopeW - 0.04, 0.03, ewCanLenZ - 0.04),
      materials.wallCladdingPpgi,
    );
    ewSoffit.position.set(midX, (ewWallTopY + ewTipTopY) / 2 - 0.04, ewCanMidZ);
    ewSoffit.rotation.z = -dirSign * slopeAngle;
    groups.cladding.add(ewSoffit);

    // 2. Full PPGI Vertical Front Fascia Sheeting along outer 3.0m edge
    const ewFasciaClad = new THREE.Mesh(
      new THREE.BoxGeometry(0.045, ewFasciaH, ewCanLenZ),
      materials.wallCladdingPpgi,
    );
    ewFasciaClad.position.set(tipX, ewFasciaBotY + ewFasciaH / 2, ewCanMidZ);
    ewFasciaClad.castShadow = true;
    groups.cladding.add(ewFasciaClad);

    // 3. Closed PPGI Side Cheek Panels at BOTH Grid A (ewCanZ1) and Grid B (ewCanZ2)
    [ewCanZ1 + 0.02, ewCanZ2 - 0.02].forEach((cz) => {
      const cheekVerts = new Float32Array([
        xWall, ewFasciaBotY, cz,
        tipX,  ewFasciaBotY, cz,
        tipX,  ewTipTopY,    cz,
        xWall, ewWallTopY,   cz,
      ]);
      const cheekGeo = new THREE.BufferGeometry();
      cheekGeo.setAttribute('position', new THREE.BufferAttribute(cheekVerts, 3));
      cheekGeo.setIndex([0, 1, 2, 0, 2, 3]);
      cheekGeo.computeVertexNormals();
      const cheekMesh = new THREE.Mesh(cheekGeo, materials.wallCladdingPpgi);
      cheekMesh.castShadow = true;
      groups.cladding.add(cheekMesh);

      // Sloped Royal Blue Rake Trim & Bottom Cheek Trim along both Grid A and Grid B edges
      const sideRake = new THREE.Mesh(
        new THREE.BoxGeometry(ewCanSlopeW + 0.12, 0.16, 0.14),
        materials.trimRoyalBlue,
      );
      sideRake.position.set(midX, (ewWallTopY + ewTipTopY) / 2 + 0.03, cz);
      sideRake.rotation.z = -dirSign * slopeAngle;

      const sideBotTrim = new THREE.Mesh(
        new THREE.BoxGeometry(endwallCanopyWidthM + 0.10, 0.12, 0.14),
        materials.trimRoyalBlue,
      );
      sideBotTrim.position.set(midX, ewFasciaBotY, cz);
      groups.cladding.add(sideRake, sideBotTrim);
    });

    // 4. Royal Blue Top Wall Flashing Trim, Outer Eave Gutter Trim, Bottom Fascia Drip Trim & Vertical Corner Trims
    const wallFlashingTrim = new THREE.Mesh(
      new THREE.BoxGeometry(0.16, 0.16, ewCanLenZ + 0.12),
      materials.trimRoyalBlue,
    );
    wallFlashingTrim.position.set(xWall + dirSign * 0.05, ewWallTopY + 0.05, ewCanMidZ);

    const outerEaveTrim = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.18, ewCanLenZ + 0.14),
      materials.trimRoyalBlue,
    );
    outerEaveTrim.position.set(tipX + dirSign * 0.04, ewTipTopY, ewCanMidZ);

    const outerBotDripTrim = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.14, ewCanLenZ + 0.14),
      materials.trimRoyalBlue,
    );
    outerBotDripTrim.position.set(tipX + dirSign * 0.03, ewFasciaBotY, ewCanMidZ);

    [ewCanZ1, ewCanZ2].forEach((cz) => {
      const vCornerTrim = new THREE.Mesh(
        new THREE.BoxGeometry(0.16, ewFasciaH + 0.16, 0.16),
        materials.trimRoyalBlue,
      );
      vCornerTrim.position.set(tipX + dirSign * 0.02, ewFasciaBotY + ewFasciaH / 2, cz);
      groups.cladding.add(vCornerTrim);
    });

    groups.cladding.add(wallFlashingTrim, outerEaveTrim, outerBotDripTrim);
  });

  // 22 Nos. Translucent FRP Skylight Panels + 11 Nos. Ø600mm Staggered Natural Turbo Ventilators (GA-02)
  const skylightGeo = new THREE.BoxGeometry(1.0, 0.07, 3.20);

  for (let b = 0; b < 11; b++) {
    const midX = (gridsX[b].xWorldM + gridsX[b + 1].xWorldM) / 2;

    [-4.25, 4.25].forEach((sz, rowIdx) => {
      const sy = getMainRoofElevationAtZ(sz) + 0.065;
      const skyMesh = new THREE.Mesh(skylightGeo, materials.skylightFrp);
      skyMesh.position.set(midX, sy, sz);
      skyMesh.rotation.x = slopeAngle;
      skyMesh.renderOrder = 2;
      skyMesh.userData.memberInfo = {
        name: `FRP Skylight Panel #${b * 2 + rowIdx + 1} (Bay ${b + 1})`,
        category: 'Roof Daylighting (GA-02)',
        spec: 'FRP Translucent Sheet | 2.0 mm Thickness | Size: 1000 × 3200 mm LG.',
        gridLocation: `Bay ${b + 1} (Grid ${b + 1}–${b + 2})`,
        drawingRef: 'J-100A246-GA-02',
      };
      interactables.push(skyMesh);
      groups.openingsAndAccessories.add(skyMesh);
    });

    // Staggered Ø600mm Natural Turbo Ventilators across Bays 1 to 11 (matching GA-02 Roof Sheeting Plan!)
    const vz = b % 2 === 0 ? 5.20 : -2.20;
    const vy = getMainRoofElevationAtZ(vz) + 0.04;
    const ventGroup = new THREE.Group();
    ventGroup.position.set(midX, vy, vz);

    const curb = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.35, 0.85), materials.trimRoyalBlue);
    curb.position.y = 0.15;
    const throat = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.32, 0.25, 16), materials.turboVentChrome);
    throat.position.y = 0.42;

    const domeGroup = new THREE.Group();
    domeGroup.position.y = 0.65;
    const coreSphere = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 12), materials.turboVentChrome);
    coreSphere.scale.set(1, 0.72, 1);
    domeGroup.add(coreSphere);

    const vaneGeo = new THREE.BoxGeometry(0.02, 0.36, 0.12);
    for (let v = 0; v < 12; v++) {
      const angle = (v / 12) * Math.PI * 2;
      const vane = new THREE.Mesh(vaneGeo, materials.turboVentChrome);
      vane.position.set(Math.cos(angle) * 0.28, 0, Math.sin(angle) * 0.28);
      vane.rotation.y = -angle + 0.35;
      domeGroup.add(vane);
    }

    ventGroup.add(curb, throat, domeGroup);
    turboVentDomes.push(domeGroup);

    const ventMeta: InspectedMemberInfo = {
      name: `Natural Turbo Ventilator #${b + 1} (Ø600 mm — Staggered Row)`,
      category: 'Roof Ventilation System (GA-02)',
      spec: '600 mm DIA. Natural Turbo Ventilator on Roof Curb (11 Nos. Staggered across Bays 1–11 per GA-02)',
      gridLocation: `Bay ${b + 1} (Grid ${b + 1}–${b + 2})`,
      drawingRef: 'J-100A246-GA-02',
    };
    ventGroup.traverse((c) => {
      if ((c as THREE.Mesh).isMesh) {
        c.userData.memberInfo = ventMeta;
        interactables.push(c);
      }
    });
    groups.openingsAndAccessories.add(ventGroup);
  }

  function applyVisibility(vis: PebLayerVisibility) {
    groups.cladding.visible = vis.cladding;
    groups.roofSheeting.visible = vis.roofSheeting;
    groups.brickWall.visible = vis.brickWall;
    groups.mezzanine.visible = vis.mezzanineStructure;
    groups.openingsAndAccessories.visible = vis.openingsAndAccessories;
    groups.primarySteel.visible = vis.primarySteel;
    groups.secondarySteel.visible = vis.secondarySteel;
    groups.bracingAndPortals.visible = vis.bracingAndPortals;
    groups.gridAndDimensions.visible = vis.gridAndDimensions;

    materials.wallCladdingPpgi.wireframe = vis.wireframeMode;
    materials.roofGalvalume.wireframe = vis.wireframeMode;
    materials.brickMasonry.wireframe = vis.wireframeMode;
    materials.primarySteel.wireframe = vis.wireframeMode;
    materials.portalSteel.wireframe = vis.wireframeMode;
    materials.mezzanineBeamSteel.wireframe = vis.wireframeMode;
    materials.mezzanineConcreteSlab.wireframe = vis.wireframeMode;
  }

  function dispose() {
    Object.values(textures).forEach((t) => t.dispose());
    Object.values(materials).forEach((m) => m.dispose());
    rootGroup.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        (obj as THREE.Mesh).geometry.dispose();
      }
    });
  }

  return {
    rootGroup,
    groups,
    turboVentDomes,
    interactables,
    applyVisibility,
    dispose,
  };
}
